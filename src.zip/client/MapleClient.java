/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package client;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;

import javax.script.ScriptEngine;

import client.messages.MessageCallback;
import static config.configuracoes.mensagens.ShowConsole.defaultErro;
import database.DatabaseConnection;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import net.MaplePacket;
import net.channel.ChannelServer;
import net.channel.PetStorage;
import net.login.LoginServer;
import net.world.MapleMessengerCharacter;
import net.world.MapleParty;
import net.world.MaplePartyCharacter;
import net.world.PartyOperation;
import net.world.guild.MapleGuild;
import net.world.guild.MapleGuildCharacter;
import net.world.remote.WorldChannelInterface;
import scripting.npc.NPCScriptManager;
import scripting.npc.NPCConversationManager;
import scripting.quest.QuestScriptManager;
import scripting.quest.QuestActionManager;
import server.MapleInventoryManipulator;
import server.MapleTrade;
import server.PlayerInteraction.HiredMerchant;
import server.PlayerInteraction.IPlayerInteractionManager;
import server.PlayerInteraction.MaplePlayerShopItem;
import tools.MapleAESOFB;
import tools.MaplePacketCreator;
import tools.Pair;

import org.apache.mina.common.IoSession;
import org.fusesource.jansi.AnsiConsole;
import server.MapleTimer.ClientTimer;
import server.PlayerInteraction.MapleMiniGame;
import server.maps.MapleMap;
import server.quest.MapleQuest;
import tools.FilePrinter;

public class MapleClient {

	public static final int LOGIN_NOTLOGGEDIN = 0;
	public static final int LOGIN_SERVER_TRANSITION = 1;
	public static final int LOGIN_LOGGEDIN = 2;
	public static final int LOGIN_WAITING = 3;
	public static final String CLIENT_KEY = "CLIENT";
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(MapleClient.class);
	private MapleAESOFB send;
	private MapleAESOFB receive;
	private IoSession session;
	private MapleCharacter player;
	private int channel = 1;
	private int accId = 1;
        private byte gender = -1;
        private boolean guest;
	private boolean loggedIn = false;
	private boolean serverTransition = false;
	private Calendar birthday = null;
	private Calendar tempban = null;
	private String accountName;
        private String hwid = null;
	private int world;
	private long lastPong;
        private String pin = null;
        private boolean haspinturnedon;
        private boolean hasguilleader;
        private boolean hasmarriege;
	private boolean gm;
        private int gmlevel;
        private long lastNpcClick;
        private ScriptDebug scriptDebug;
        public boolean smegastarted = false; 
        public long lastsmega; 
        public long lastsmegacompare;  
	private byte greason = 1;
	private Map<Pair<MapleCharacter, Integer>, Integer> timesTalked = new HashMap<>(); //npcid, times
	private Set<String> macs = new HashSet<String>();
	private Map<String, ScriptEngine> engines = new HashMap<>();
	private ScheduledFuture<?> idleTask = null;
        private int attemptedLogins = 0;
        private long afkTimer = 0;
        private int votePoints;
	private int voteTime = -1;
        private final transient Lock mutex = new ReentrantLock(true);
        private static final Lock login_mutex = new ReentrantLock(true);
        private static final Lock dcLock = new ReentrantLock();
        private long sessionId;
 
	public MapleClient(MapleAESOFB send, MapleAESOFB receive, IoSession session) {
		this.send = send;
		this.receive = receive;
		this.session = session;
	}
        
        
        public long getSessionId() {
         return this.sessionId;
        }
        
        public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
        }  

	public final MapleAESOFB getReceiveCrypto() {
	return receive;
        }

        public final MapleAESOFB getSendCrypto() {
	return send;
        }

        public final IoSession getSession() {
	return session;
        }
        
         public void resetAfkTimer(){
         this.afkTimer = System.currentTimeMillis();
         }

         public long getAfkTimer(){
         return System.currentTimeMillis() - this.afkTimer;
         }

	public MapleCharacter getPlayer() {
		return player;
	}

	public void setPlayer(MapleCharacter player) {
		this.player = player;
	}

	public void sendCharList(int server) {
		this.session.write(MaplePacketCreator.getCharList(this, server));
	}

	public List<MapleCharacter> loadCharacters(int serverId) { // TODO make this less costly zZz
		List<MapleCharacter> chars = new LinkedList<MapleCharacter>();
		for (CharNameAndId cni : loadCharactersInternal(serverId)) {
			try {
				chars.add(MapleCharacter.loadCharFromDB(cni.id, this, false));
			} catch (SQLException e) {
				log.error("Loading characters failed", e);
			}
		}
		return chars;
	}

	public List<String> loadCharacterNames(int serverId) {
		List<String> chars = new LinkedList<String>();
		for (CharNameAndId cni : loadCharactersInternal(serverId)) {
			chars.add(cni.name);
		}
		return chars;
	}
        
        
        
      public void declare(MaplePacket packet) {
        this.session.write(packet);
    }

	private List<CharNameAndId> loadCharactersInternal(int serverId) {
		PreparedStatement ps;
		List<CharNameAndId> chars = new ArrayList<>(15);
		try {
		        ps = DatabaseConnection.getConnection().prepareStatement("SELECT id, name FROM characters WHERE accountid = ? AND world = ?");
			ps.setInt(1, this.accId);
			ps.setInt(2, serverId);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				chars.add(new CharNameAndId(rs.getString("name"), rs.getInt("id")));
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return chars;
	}

	public boolean isLoggedIn() {
          return (this.loggedIn) && (this.accId >= 0);
        }


	private Calendar getTempBanCalendar(ResultSet rs) throws SQLException {
		Calendar lTempban = Calendar.getInstance();
		long blubb = rs.getLong("tempban");
		if (blubb == 0) { // basically if timestamp in db is 0000-00-00
			lTempban.setTimeInMillis(0);
			return lTempban;
		}
		Calendar today = Calendar.getInstance();
		lTempban.setTimeInMillis(rs.getTimestamp("tempban").getTime());
		if (today.getTimeInMillis() < lTempban.getTimeInMillis()) {
			return lTempban;
		}

		lTempban.setTimeInMillis(0);
		return lTempban;
	}

	public Calendar getTempBanCalendar() {
		return tempban;
	}

	public byte getBanReason() {
		return greason;
	}

	public boolean hasBannedIP() {
               boolean ret = false;
		try {
			PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT COUNT(*) FROM ipbans WHERE ? LIKE CONCAT(ip, '%')");
			ps.setString(1, session.getRemoteAddress().toString());
			ResultSet rs = ps.executeQuery();
			rs.next();
                        if (rs.getInt(1) > 0) {
                            ret = true;
                        }
			rs.close();
			ps.close();
		} catch (SQLException ex) {
		}
		return ret;
	}
        
        public boolean hasBannedHWID() {
		if(hwid == null) {
		    return false;
                }
		boolean ret = false;
		PreparedStatement ps = null;
		try {
			ps = DatabaseConnection.getConnection().prepareStatement("SELECT COUNT(*) FROM hwidbans WHERE hwid LIKE ?");
			ps.setString(1, hwid);
			ResultSet rs = ps.executeQuery();
			if(rs != null && rs.next()) {
				if(rs.getInt(1) > 0) 
					ret = true; 
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(ps != null && !ps.isClosed()) {
					ps.close();
				} 
                                
			} catch (SQLException e){
			}
		}
		
		return ret;
	}

	public boolean hasBannedMac() {
		if (macs.isEmpty()) {
			return false;
		}
		int i = 0;
                boolean ret = false;
		try {
			StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM macbans WHERE mac IN (");
			for (i = 0; i < macs.size(); i++) {
				sql.append("?");
				if (i != macs.size() - 1) {
					sql.append(", ");
				}
			}
			sql.append(")");
			PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql.toString());
			i = 0;
			for (String mac : macs) {
				i++;
				ps.setString(i, mac);
			}
			ResultSet rs = ps.executeQuery();
			rs.next();
			if (rs.getInt(1) > 0) {
                               ret = true;
                        }
			rs.close();
			ps.close();
		} catch (Exception e) {
		}
		return ret;
	}
        
        private void loadHWIDIfNescessary() throws SQLException {
		if(hwid == null) {
			try(PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT hwid FROM accounts WHERE id = ?")) {
				ps.setInt(1, accId);
				try(ResultSet rs = ps.executeQuery()) {
					if(rs.next()) {
						hwid = rs.getString("hwid");
					}
                                       rs.close();
                                       ps.close();
				} 
		        }   
		}
	}

	private void loadMacsIfNescessary() throws SQLException {
        if (macs.isEmpty()) {
            PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT macs FROM accounts WHERE id = ?");
            ps.setInt(1, accId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                for (String mac : rs.getString("macs").split(", ")) {
                    if (!mac.equals("")) {
                        macs.add(mac);
                    }
                }
            }
            rs.close();
            ps.close();
        }
    }
        
        public void banHWID() {
		Connection con = DatabaseConnection.getConnection();
		PreparedStatement ps = null;
		try {
			loadHWIDIfNescessary();
			ps = con.prepareStatement("INSERT INTO hwidbans (hwid) VALUES (?)");
			ps.setString(1, hwid);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
			if(ps != null && !ps.isClosed())
			   ps.close();
			} catch (SQLException e) {
			}
		}
	}

     public void banMacs() {
        Connection con = DatabaseConnection.getConnection();
        try {
            loadMacsIfNescessary();
            List<String> filtered = new LinkedList<String>();
            PreparedStatement ps = con.prepareStatement("SELECT filter FROM macfilters");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                filtered.add(rs.getString("filter"));
            }
            rs.close();
            ps.close();
            ps = con.prepareStatement("INSERT INTO macbans (mac) VALUES (?)");
            for (String mac : macs) {
                boolean matched = false;
                for (String filter : filtered) {
                    if (mac.matches(filter)) {
                        matched = true;
                        break;
                    }
                }
                if (!matched) {
                    ps.setString(1, mac);
                    ps.executeUpdate();
                }
            }
            ps.close();
        } catch (SQLException e) {
        }
    }



	/**
	 * Returns 0 on success, a state to be used for
	 * {@link MaplePacketCreator#getLoginFailed(int)} otherwise.
	 * 
	 * @param success
	 * @return The state of the login.
	 */       
        public int finishLogin(boolean success) {
        login_mutex.lock();
         try {
            if (success) {
            if (getLoginState() > LOGIN_NOTLOGGEDIN && getLoginState() != LOGIN_WAITING) {
                loggedIn = false;
                return 7;
               }
            }
            updateLoginState(LOGIN_LOGGEDIN);
        } finally {
            login_mutex.unlock();
        }
        return 0;
    }
        
   
     public int login(String login, String pwd, boolean ipMacBanned) {
        int loginok = 5;
        attemptedLogins++;
        if (attemptedLogins > 5) {
            session.close();
        }
        Connection con = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT id, password, salt, tempban, banned, gm, macs, lastknownip, greason FROM accounts WHERE name = ?");
            ps.setString(1, login);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int banned = rs.getInt("banned");
                accId = rs.getInt("id");
                gm = rs.getInt("gm") > 0;
                String passhash = rs.getString("password");
                String salt = rs.getString("salt");
                greason = rs.getByte("greason");
                tempban = getTempBanCalendar(rs);
                if ((banned == 0 && !ipMacBanned) || banned == -1) {
                    PreparedStatement ips = con.prepareStatement("INSERT INTO iplog (accountid, ip) VALUES (?, ?)");
                    ips.setInt(1, accId);
                    String sockAddr = session.getRemoteAddress().toString();
                    ips.setString(2, sockAddr.substring(1, sockAddr.lastIndexOf(':')));
                    ips.executeUpdate();
                    ips.close();
                }
                if (!rs.getString("lastknownip").equals(session.getRemoteAddress().toString())) {
                    PreparedStatement lkip = con.prepareStatement("UPDATE accounts SET lastknownip = ? WHERE id = ?");
                    String sockAddr = session.getRemoteAddress().toString();
                    lkip.setString(1, sockAddr.substring(1, sockAddr.lastIndexOf(':')));
                    lkip.setInt(2, accId);
                    lkip.executeUpdate();
                    lkip.close();
                }
                ps.close();
                if (LoginServer.getInstance().isServerCheck() && !gm) {
                    return 7;
                } else if (banned == 1) {
                    loginok = 3;
                } else {
                    if (banned == -1) {
                        unban();
                    }
                   if (getLoginState() > LOGIN_NOTLOGGEDIN) {
                        loggedIn = false;
                        loginok = 7;
                    } else {
                        if (passhash.equals(pwd)) {
                            loginok = 0;
                        } else {
                            boolean updatePasswordHash = false;
                            if (LoginCrypto.isLegacyPassword(passhash) && LoginCrypto.checkPassword(pwd, passhash)) {
                                loginok = 0;
                                updatePasswordHash = true;
                            } else if (salt == null && LoginCrypto.checkSha1Hash(passhash, pwd)) {
                                loginok = 0;
                                updatePasswordHash = true;
                            } else if (LoginCrypto.checkSaltedSha512Hash(passhash, pwd, salt)) {
                                loginok = 0;
                            } else {
                                loggedIn = false;
                                loginok = 4;
                            }
                            if (updatePasswordHash) {
                                PreparedStatement pss = con.prepareStatement("UPDATE `accounts` SET `password` = ?, `salt` = ? WHERE id = ?");
                                try {
                                    String newSalt = LoginCrypto.makeSalt();
                                    pss.setString(1, LoginCrypto.makeSaltedSha512Hash(pwd, newSalt));
                                    pss.setString(2, newSalt);
                                    pss.setInt(3, accId);
                                    pss.executeUpdate();
                                } finally {
                                    pss.close();
                                }
                            }
                        }
                    }
                }
            }
            rs.close();
            ps.close();
         } catch (SQLException e) {
            log.error("ERROR", e);
         }
        return loginok;
      }
   
       private static long dottedQuadToLong(String dottedQuad) throws RuntimeException {
            String[] quads = dottedQuad.split("\\.");
            if (quads.length != 4) {
                throw new RuntimeException("Invalid IP Address format.");
            }
            long ipAddress = 0;
            for (int i = 0; i < 4; i++) {
                int quad = Integer.parseInt(quads[i]);
                ipAddress += (long) (quad % 256) * (long) Math.pow(256, (double) (4 - i));
            }
            return ipAddress;
        } 
        
	/**
	 * Gets the special server IP if the client matches a certain subnet.
	 * 
	 * @param clientIPAddress The IP address of the client as a dotted quad.
	 * @param channel The requested channel to match with the subnet.
	 * @return <code>0.0.0.0</code> if no subnet matched, or the IP if the subnet matched.
	 */
	public static String getChannelServerIPFromSubnet(String clientIPAddress, int channel) {
        long ipAddress = dottedQuadToLong(clientIPAddress);
        Properties subnetInfo = LoginServer.getInstance().getSubnetInfo();
        if (subnetInfo.contains("net.login.subnetcount")) {
            int subnetCount = Integer.parseInt(subnetInfo.getProperty("net.login.subnetcount"));
            for (int i = 0; i < subnetCount; i++) {
                String[] connectionInfo = subnetInfo.getProperty("net.login.subnet." + i).split(":");
                long subnet = dottedQuadToLong(connectionInfo[0]);
                long channelIP = dottedQuadToLong(connectionInfo[1]);
                int channelNumber = Integer.parseInt(connectionInfo[2]);
                if (((ipAddress & subnet) == (channelIP & subnet)) && (channel == channelNumber)) {
                    return connectionInfo[1];
                }
             }
          }
         return "0.0.0.0";
       }
        
	private void unban() {
		int i;
		try {
			Connection con = DatabaseConnection.getConnection();
			loadMacsIfNescessary();
			StringBuilder sql = new StringBuilder("DELETE FROM macbans WHERE mac IN (");
			for (i = 0; i < macs.size(); i++) {
				sql.append("?");
				if (i != macs.size() - 1) {
					sql.append(", ");
				}
			}
			sql.append(")");
			PreparedStatement ps = con.prepareStatement(sql.toString());
			i = 0;
			for (String mac : macs) {
				i++;
				ps.setString(i, mac);
			}
			ps.executeUpdate();
			ps.close();
			ps = con.prepareStatement("DELETE FROM ipbans WHERE ip LIKE CONCAT(?, '%')");
			ps.setString(1, getSession().getRemoteAddress().toString().split(":")[0]);
			ps.executeUpdate();
			ps.close();
			ps = con.prepareStatement("UPDATE accounts SET banned = 0 WHERE id = ?");
			ps.setInt(1, accId);
			ps.executeUpdate();
			ps.close();
		} catch (SQLException e) {
			log.error("Error while unbanning", e);
		}
	}
        
        public void updateHWID(String newHwid) {
		String[] split = newHwid.split("_");
		if(split.length > 1 && split[1].length() == 8) {
			StringBuilder hwid = new StringBuilder();
			String convert = split[1]; 
			
			int len = convert.length();
			for(int i=len-2; i>=0; i -= 2) {
				hwid.append(convert.substring(i, i + 2));
			}
			hwid.insert(4, "-");
					
			this.hwid = hwid.toString();
			
			PreparedStatement ps = null;
			try {
				ps = DatabaseConnection.getConnection().prepareStatement("UPDATE accounts SET hwid = ? WHERE id = ?");
				ps.setString(1, this.hwid);
				ps.setInt(2, accId);
				ps.executeUpdate();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					if(ps != null && !ps.isClosed()) {
						ps.close();
					}
				} catch (SQLException e) {
				}
			}
		} else {
			this.disconnect(false); // Invalid HWID...
		}
	}

      public void updateMacs(String macData) {
        for (String mac : macData.split(", ")) {
            macs.add(mac);
        }
        StringBuilder newMacData = new StringBuilder();
        Iterator<String> iter = macs.iterator();
        while (iter.hasNext()) {
            String cur = iter.next();
            newMacData.append(cur);
            if (iter.hasNext()) {
                newMacData.append(", ");
            }
        }
        try {
            PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("UPDATE accounts SET macs = ? WHERE id = ?");
            ps.setString(1, newMacData.toString());
            ps.setInt(2, accId);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
       }

	public void setAccID(int id) {
		this.accId = id;
	}

	public int getAccID() {
		return this.accId;
	}
        

     public void updateLoginState(int newstate) {
        try {
            PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("UPDATE accounts SET loggedin = ?, lastlogin = CURRENT_TIMESTAMP() WHERE id = ?");
            ps.setInt(1, newstate);
            ps.setInt(2, getAccID());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            System.out.println("ERROR " + e);
        }
        if (newstate == LOGIN_NOTLOGGEDIN) {
            loggedIn = false;
            serverTransition = false;
        } else if (newstate == LOGIN_WAITING) {
            loggedIn = false;
            serverTransition = false;
        } else {
            serverTransition = (newstate == LOGIN_SERVER_TRANSITION);
            loggedIn = !serverTransition;
        }
    }

	public int getLoginState() {  // 0 = LOGIN_NOTLOGGEDIN, 1= LOGIN_SERVER_TRANSITION, 2 = LOGIN_LOGGEDIN
		try {
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT loggedin, lastlogin, UNIX_TIMESTAMP(birthday) as birthday FROM accounts WHERE id = ?");
			ps.setInt(1, getAccID());
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				rs.close();
				ps.close();
				throw new RuntimeException("getLoginState - MapleClient");
			}
			birthday = Calendar.getInstance();
			long blubb = rs.getLong("birthday");
			if (blubb > 0) {
				birthday.setTimeInMillis(blubb * 1000);
			}
			int state = rs.getInt("loggedin");
			if (state == LOGIN_SERVER_TRANSITION) {
				if (rs.getTimestamp("lastlogin").getTime() + 30000 < System.currentTimeMillis()) {
					state = LOGIN_NOTLOGGEDIN;
					updateLoginState(LOGIN_NOTLOGGEDIN);
				}
			} else if (state == LOGIN_LOGGEDIN && player == null) {
				state = LOGIN_NOTLOGGEDIN;
				updateLoginState(LOGIN_NOTLOGGEDIN);
			}
			rs.close();
			ps.close();
			if (state == LOGIN_LOGGEDIN) {
				loggedIn = true;
			} else {
				loggedIn = false;
			}
			return state;
		} catch (SQLException e) {
			loggedIn = false;
			e.printStackTrace();
			throw new RuntimeException("login state");
		}
	}
        
        
    public int getVoteTime(){
		if (voteTime != -1){
			return voteTime;
		}
		try {
			try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT date FROM bitsite_votingrecords WHERE UPPER(account) = UPPER(?)")) {
				ps.setString(1, accountName);
				try (ResultSet rs = ps.executeQuery()) {
					if (!rs.next()) {
						return -1;
					}
					voteTime = rs.getInt("date");
				}
			}
		} catch (SQLException e) {
			FilePrinter.printError("hasVotedAlready.txt", e);
			return -1;
		}
		return voteTime;
	}
    
     public void resetVoteTime() {
            voteTime = -1;
        }
        
    public boolean hasVotedAlready(){
		Date currentDate = new Date();
		int timeNow = (int) (currentDate.getTime() / 1000);
		int difference = (timeNow - getVoteTime());
		return difference < 86400 && difference > 0;
    }    
       

    public boolean checkBirthDate(Calendar date) {
        return date.get(Calendar.YEAR) == birthday.get(Calendar.YEAR) && date.get(Calendar.MONTH) == birthday.get(Calendar.MONTH) && date.get(Calendar.DAY_OF_MONTH) == birthday.get(Calendar.DAY_OF_MONTH);
    }
    
    public boolean checkLeaderGuild(int cid) {
        return player.getGuild().getLeaderId() == cid;
    }
    
    public void disconnect(boolean close) {
        disconnect(true, false);
    }

     public void disconnect(boolean close, boolean cashshop) {
        dcLock.lock();
        try {
            MapleCharacter chr = this.getPlayer();
            final BuddyList bl = chr.getBuddylist();
            final MapleParty party = chr.getParty();
            final MapleGuild guild = chr.getGuild();
            final int messengerid = chr.getMessenger() == null ? 0 : chr.getMessenger().getId();
            final MapleMessengerCharacter chrm = new MapleMessengerCharacter(chr, 0);
            final int idz = chr.getId();
            final MaplePartyCharacter chrp = new MaplePartyCharacter(chr);
            MapleMap map = chr.getMap();
            if (chr != null && isLoggedIn() && chr.getClient() != null) {
                removalTask(chr);
                IPlayerInteractionManager interaction = chr.getInteraction();
                 if (interaction != null) {
                 if (interaction.isOwner(chr)) {
                    if (interaction.getShopType() == 1) {
                        HiredMerchant hm = (HiredMerchant) interaction;
                        hm.setOpen(true);
                    } else if (interaction.getShopType() == 2) {
                        for (MaplePlayerShopItem items : interaction.getItems()) {
                            if (items.getBundles() > 0) {
                                IItem item = items.getItem();
                                item.setQuantity(items.getBundles());
                                MapleInventoryManipulator.addFromDrop(this, item, "");
                            }
                        }
                        interaction.removeAllVisitors(3, 1);
                        interaction.closeShop(true);
                    } else if (interaction.getShopType() == 3 || interaction.getShopType() == 4) {
                        interaction.removeAllVisitors(3, 1);
                        interaction.closeShop(true);
                    }
                } else {
                    interaction.removeVisitor(chr);
                }
               }
            MapleMiniGame game = chr.getMiniGame();
            if (game != null) {
                chr.setMiniGame(null);
                if (game.isOwner(chr)) {
                    chr.getMap().broadcastMessage(MaplePacketCreator.removeCharBox(player));
                    game.broadcastToVisitor(MaplePacketCreator.getMiniGameClose((byte) 0));
                } else
                    game.removeVisitor(chr);
            } if (chr.getPets() != null) {
               PetStorage.savePetz(chr);
               chr.unequipAllPets();
               } try {
                    if (chr.getMessenger() != null) {
                        MapleMessengerCharacter messengerplayer = new MapleMessengerCharacter(chr);
                        getChannelServer().getWorldInterface().leaveMessenger(chr.getMessenger().getId(), messengerplayer);
                        chr.setMessenger(null);
                    }
                } catch (RemoteException e) {
                    getChannelServer().reconnectWorld();
                    chr.setMessenger(null);
               } if (!chr.isAlive()) {
                    chr.setHp(50, true);
               } if (chr.getEventInstance() != null) {
		chr.getEventInstance().playerDisconnected(chr);
	       } if (chr.getMonsterCarnival() != null) {
                   chr.getMonsterCarnival().playerDisconnected(getPlayer().getId());
               } if (!chr.isAlive()) {
                    if (chr.getMap().getReturnMapId() != 999999999) {
                        chr.setMap(chr.getMap().getReturnMapId());
                    }
               } if (chr.getTrade() != null) {
		     MapleTrade.cancelTrade(chr);
	        } if (NPCScriptManager.getInstance() != null) {
                     NPCScriptManager.getInstance().dispose(this);
                } if (QuestScriptManager.getInstance() != null) {
                      QuestScriptManager.getInstance().dispose(this);
                } if (chr.getMap() != null) {
		      chr.getMap().removePlayer(chr);
	        }
                chr.saveToDB(true, true);
               try {
                   WorldChannelInterface wci = getChannelServer().getWorldInterface();
                   if (!cashshop) {
                        if (!this.serverTransition) { // meaning not changing channels
                                if (messengerid > 0) {
                                        wci.leaveMessenger(messengerid, chrm);
                                }
                                if (getPlayer().getMonsterCarnival() != null) {
                                    getPlayer().getMonsterCarnival().playerDisconnected(getPlayer().getId());
                                }              
                                for (MapleQuestStatus status : chr.getStartedQuests()) { //This is for those quests that you have to stay logged in for a certain amount of time
                                        MapleQuest quest = status.getQuest();
                                        if (quest.getTimeLimit() > 0) {
                                                MapleQuestStatus newStatus = new MapleQuestStatus(quest, MapleQuestStatus.Status.NOT_STARTED);
                                                newStatus.setForfeited(chr.getQuest(quest).getForfeited() + 1);
                                                chr.updateQuest(newStatus);
                                        }
                                }	                   
                                if (guild != null) {
                                        wci.setGuildMemberOnline(chr.getMGC(), false, chr.getClient().getChannel());
                                        chr.getClient().announce(MaplePacketCreator.showGuildInfo(chr));
                                }
                                if (party != null) {
                                        chrp.setOnline(false);
                                        wci.updateParty(party.getId(), PartyOperation.LOG_ONOFF, chrp);
                                        if (map != null && party.getLeader().getId() == idz) {
                                                MaplePartyCharacter lchr = null;
                                                for (MaplePartyCharacter pchr : party.getMembers()) {
                                                        if (pchr != null && map.getCharacterById(pchr.getId()) != null && (lchr == null || lchr.getLevel() <= pchr.getLevel())) {
                                                                lchr = pchr;
                                                        }
                                                }
                                                if (lchr != null) {
                                                        wci.updateParty(party.getId(), PartyOperation.CHANGE_LEADER, lchr);
                                                }
                                        }
                                }                   
                                if (bl != null) {
                                        wci.loggedOff(chr.getName(), chr.getId(), channel, chr.getBuddylist().getBuddyIds());
                                }
                        }
                } else {
                 if (party != null) {
                    chrp.setOnline(false);
                    wci.updateParty(party.getId(), PartyOperation.LOG_ONOFF, chrp);
                    if (map != null && party.getLeader().getId() == idz) {
                            MaplePartyCharacter lchr = null;
                            for (MaplePartyCharacter pchr : party.getMembers()) {
                                    if (pchr != null && map.getCharacterById(pchr.getId()) != null && (lchr == null || lchr.getLevel() <= pchr.getLevel())) {
                                            lchr = pchr;
                                    }
                            }
                            if (lchr != null) {
                                    wci.updateParty(party.getId(), PartyOperation.CHANGE_LEADER, lchr);
                            }
                    }
                } 
                if (!this.serverTransition && isLoggedIn()) {
                     if (bl != null) {
                        wci.loggedOff(chr.getName(), chr.getId(), channel, chr.getBuddylist().getBuddyIds());
		 }
               }
                for (MapleQuestStatus status : chr.getStartedQuests()) {
		     MapleQuest quest = status.getQuest();
		   if (quest.getTimeLimit() > 0) {
                    MapleQuestStatus newStatus = new MapleQuestStatus(quest, MapleQuestStatus.Status.NOT_STARTED);
                    newStatus.setForfeited(chr.getQuest(quest).getForfeited() + 1);
                    chr.updateQuest(newStatus);
		}
	      }
	      if (guild != null) {
                        wci.setGuildMemberOnline(chr.getMGC(), false, -1);
                        int allianceId = chr.getGuild().getAllianceId();
                        if (allianceId > 0) {
                            wci.allianceMessage(allianceId, MaplePacketCreator.allianceMemberOnline(chr, false), chr.getId(), -1);
                        }
                    }
                } 
               } catch (RemoteException e) {
                    getChannelServer().reconnectWorld();
                } catch (Exception e) {
                    AnsiConsole.out.println(defaultErro + "O jogador teve problemas de disconnect. (" + chr.getName() + ")");
                    FilePrinter.printError("Error_dc.txt", e);
                } finally {
                   if (player != null) {
		       player.empty();
		    }
                    if (getChannelServer() != null) {
                        getChannelServer().removePlayer(chr);
                    } else {
                        AnsiConsole.out.println(defaultErro + "Sem channelserver para (" + chr.getName() + ")");
                    }
                    player = null;  
                }
            }
            if (close) {
                if (!serverTransition && isLoggedIn()) {
                    updateLoginState(MapleClient.LOGIN_NOTLOGGEDIN);
                    session.removeAttribute(MapleClient.CLIENT_KEY); // prevents double dcing during login
                    session.close();
                }
            }
          engines.clear();
        } finally {
            dcLock.unlock();
         }
      }
 
      public final void removalTask(MapleCharacter chr) {
	try {
            if (scriptDebug != null) {
                scriptDebug.empty();
            }
            if (this.idleTask != null) {
		this.idleTask.cancel(true);
		this.idleTask = null;
	    }
            
	} catch (final Throwable e) {
	    FilePrinter.printError("Account_RemoveTask.txt", e);
	 }
       }
    
        public final String getSessionIPAddress() {
        return session.getRemoteAddress().toString().split(":")[0];
        }

        
        public void deleteAllCharacters() {
        Connection con = DatabaseConnection.getConnection();
        try {
            int accountid = -1;
            PreparedStatement ps = con.prepareStatement("SELECT id FROM accounts WHERE name = ?");
            ps.setString(1, accountName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                accountid = rs.getInt("id");
            }
            rs.close();
            ps.close();
            if (accountid == -1) {
                return;
            }
            ps = con.prepareStatement("SELECT id FROM characters WHERE accountid = ?");
            ps.setInt(1, accountid);
            rs = ps.executeQuery();
            while (rs.next()) {
                deleteCharacter(rs.getInt("id"));
            }
            
            rs.close();
            ps.close();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            return;
        }
        return;
       }
      

        public int getGMLevel() {
            return this.gmlevel;
        }       
	
	public void disconnect() {
		disconnect(true);
	}

	public void dropDebugMessage(MessageCallback mc) {
		StringBuilder builder = new StringBuilder();
		builder.append("Connected: ");
		builder.append(getSession().isConnected());
		builder.append(" Closing: ");
		builder.append(getSession().isClosing());
		builder.append(" ClientKeySet: ");
		builder.append(getSession().getAttribute(MapleClient.CLIENT_KEY) != null);
		builder.append(" loggedin: ");
		builder.append(isLoggedIn());
		builder.append(" has char: ");
		builder.append(getPlayer() != null);
		mc.dropMessage(builder.toString());
	}
        
        public boolean smegastarted(){ 
            return smegastarted; 
        } 
        public long lastsmega(){ 
            return lastsmega; 
        } 
        public long lastsmegacompare(){ 
            return lastsmega; 
        }  

	/**
	 * Undefined when not logged to a channel
	 * 
	 * @return the channel the client is connected to
	 */
	public int getChannel() {
        return channel;
        }

        public ChannelServer getChannelServer() {
            return ChannelServer.getInstance(getChannel());
        }
	
	public int getChannelByWorld() {
		int chnl = channel;
		switch (world) {
			case 1:
				chnl += 2;
		}
		return chnl;
	}

	/**
	 * Convinence method to get the ChannelServer object this client is logged
	 * on to.
	 * 
	 * @return The ChannelServer instance of the client.
	 */

        public boolean deleteCharacter(int cid) {
        Connection con = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT id, guildid, guildrank, name, allianceRank FROM characters WHERE id = ? AND accountid = ?");
            ps.setInt(1, cid);
            ps.setInt(2, accId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                rs.close();
                ps.close();
                return false;
            }
            if (rs.getInt("guildid") > 0)  {
                MapleGuildCharacter mgc = new MapleGuildCharacter(cid, 0, rs.getString("name"), -1, 0, rs.getInt("guildrank"), rs.getInt("guildid"), false, rs.getInt("allianceRank"));
                try {
                    LoginServer.getInstance().getWorldInterface().deleteGuildCharacter(mgc);
                } catch (RemoteException re) {
                    getChannelServer().reconnectWorld();
                    rs.close();
                    ps.close();
                    return false;
                }
            }
            rs.close();
            ps.close();
            ps = con.prepareStatement("DELETE FROM characters WHERE id = ?");
            ps.setInt(1, cid);
            ps.executeUpdate();
            ps.close();
            String[] toDel = {"famelog", "inventoryitems", "keymap", "queststatus", "savedlocations", "skillmacros", "skills", "eventstats"};
			for (String s : toDel) {
				MapleCharacter.deleteWhereCharacterId(con, "DELETE FROM `" + s + "` WHERE characterid = ?", cid);
			}
			return true;
        } catch (SQLException e) {
            log.error("ERROR", e);
          }
         return false;
        }

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
        
        public void setChannel(int channel) {
            this.channel = channel;
        }

        public Calendar getBirthday() {
        return birthday;
        }  

	public int getWorld() {
		return world;
	}

	public void setWorld(int world) {
		this.world = world;
	}

	public void pongReceived() {
		lastPong = System.currentTimeMillis();
	}

        public void sendPing() {
        final long then = System.currentTimeMillis();
        announce(MaplePacketCreator.getPing());
        ClientTimer.getInstance().schedule(new Runnable() {
            @Override
            public void run() {
                try {
                    if (lastPong < then) {
                        if (getSession().isConnected()) {
                            getSession().close();
                        }
                    }
                } catch (NullPointerException e) {
                }
            }
         }, 15000);
       }

	public static String getLogMessage(MapleClient cfor, String message) {
		return getLogMessage(cfor, message, new Object[0]);
	}

	public static String getLogMessage(MapleCharacter cfor, String message) {
		return getLogMessage(cfor == null ? null : cfor.getClient(), message);
	}

	public static String getLogMessage(MapleCharacter cfor, String message, Object... parms) {
		return getLogMessage(cfor == null ? null : cfor.getClient(), message, parms);
	}

	public static String getLogMessage(MapleClient cfor, String message, Object... parms) {
		StringBuilder builder = new StringBuilder();
		if (cfor != null) {
			if (cfor.getPlayer() != null) {
				builder.append("<");
				builder.append(MapleCharacterUtil.makeMapleReadable(cfor.getPlayer().getName()));
				builder.append(" (ID: ");
				builder.append(cfor.getPlayer().getId());
				builder.append(")> ");
			}
			if (cfor.getAccountName() != null) {
				builder.append("(Conta: ");
				builder.append(MapleCharacterUtil.makeMapleReadable(cfor.getAccountName()));
				builder.append(") ");
			}
		}
		builder.append(message);
		for (Object parm : parms) {
			int start = builder.indexOf("{}");
			builder.replace(start, start + 2, parm.toString());
		}
		return builder.toString();
	}

	public static int findAccIdForCharacterName(String charName) {
        Connection con = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps = con.prepareStatement("SELECT accountid FROM characters WHERE name = ?");
            ps.setString(1, charName);
            ResultSet rs = ps.executeQuery();
            int ret = -1;
            if (rs.next()) {
                ret = rs.getInt("accountid");
            }
            rs.close();
            ps.close();
            return ret;
        } catch (SQLException e) {
            log.error("SQL THROW");
        }
        return -1;
       }
        
        public String getHWID() {
		return hwid;
	}

	public Set<String> getMacs() {
		return Collections.unmodifiableSet(macs);
	}

	public boolean isGm() {
		return gm;
	}

	public void setScriptEngine(String name, ScriptEngine e) {
		engines.put(name, e);
	}

	public ScriptEngine getScriptEngine(String name) {
		return engines.get(name);
	}

	public void removeScriptEngine(String name) {
		engines.remove(name);
	}

	public ScheduledFuture<?> getIdleTask() {
		return idleTask;
	}

	public void setIdleTask(ScheduledFuture<?> idleTask) {
		this.idleTask = idleTask;
	}
        

	public NPCConversationManager getCM() {
        return NPCScriptManager.getInstance().getCM(this);
        }

        public QuestActionManager getQM() {
        return QuestScriptManager.getInstance().getQM(this);
        }

	public void setTimesTalked(int n, int t) {
		timesTalked.remove(new Pair<MapleCharacter, Integer>(getPlayer(), n));
		timesTalked.put(new Pair<MapleCharacter, Integer>(getPlayer(), n), t);
	}

	public int getTimesTalked(int n) {
		if (timesTalked.get(new Pair<MapleCharacter, Integer>(getPlayer(), n)) == null) {
			setTimesTalked(n, 0);
		}
		return timesTalked.get(new Pair<MapleCharacter, Integer>(getPlayer(), n));
	}

        public synchronized void announce(final MaplePacket packet) {//MINA CORE IS A FUCKING BITCH AND I HATE IT <3
		session.write(packet);
        }

        public boolean isGuest() {
            return guest;
        }

        public void setGuest(boolean set) {
            this.guest = set;
        }

        public void announce(final byte[] packet) {
            session.write(packet);
        }

         public boolean hasGuildLeader() {     
            try {
                PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT guildrank FROM characters WHERE accountid = ?");
                ps.setInt(1, this.getAccID());
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    if (rs.getInt("guildrank") == 1) {
                        hasguilleader = true;
                    } else {
                        hasguilleader = false;
                    }
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return hasguilleader;
        }
     
          public boolean hasMarriage() {     
            try {
                PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT married FROM characters WHERE accountid = ?");
                ps.setInt(1, this.getAccID());
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    if (rs.getInt("married") == 1) {
                        hasmarriege = true;
                    } else {
                        hasmarriege = false;
                    }
                }
                rs.close();
                ps.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return hasmarriege;
        }
      
        public void showMessage(String string) {
            getSession().write(MaplePacketCreator.serverNotice(1, string));
        }

        public final Lock getLock() {
            return mutex;
        }

        public void setScriptDebug(ScriptDebug sd) {
            this.scriptDebug = sd;
        }

        public boolean canClickNPC(){
		return lastNpcClick + 500 < System.currentTimeMillis();
	}

	public void setClickedNPC(){
		lastNpcClick = System.currentTimeMillis();
	}

	public void removeClickedNPC(){
		lastNpcClick = 0;
	}


        public final byte getGReason() {
		final Connection con = DatabaseConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = con.prepareStatement("SELECT `greason` FROM `accounts` WHERE id = ?");
			ps.setInt(1, accId);
			rs = ps.executeQuery();
			if (rs.next()) {
				return rs.getByte("greason");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (rs != null) {
					rs.close();
				}
			} catch (SQLException e) {
			}
		}
		return 0;
	}

    	public byte getGender() {
		return gender;
	}

        public void enableActions() {
        session.write(MaplePacketCreator.enableActions());
        }

	private static class CharNameAndId {

		public String name;
		public int id;

		public CharNameAndId(String name, int id) {
			super();
			this.name = name;
			this.id = id;
		}
	}
}
