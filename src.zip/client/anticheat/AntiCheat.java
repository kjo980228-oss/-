/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package client.anticheat;

import java.awt.Point;
import java.lang.ref.WeakReference;
import java.util.List;

import java.util.concurrent.ScheduledFuture;
import client.MapleCharacter;
import server.MapleTimer.WLCTimer;
import server.movement.AbsoluteLifeMovement;
import server.movement.LifeMovementFragment;
import tools.MaplePacketCreator;

/**
 *
 * @author Fate
 */
public class AntiCheat {

    //General
    private WeakReference<MapleCharacter> chr;
    private ScheduledFuture<?> validationTask;
    private int[] reason = new int[7];
    //Speed Hack
    private int numSequentialAttacks;
    private long lastAttackTime;
    private long attackingSince;
    //Fast Hp Regen
    private int numHPRegens;
    private long regenHPSince;
    //Fast MP Regen
    private int numMPRegens;
    private long regenMPSince;
    //God Mode
    private long takingDamageSince;
    private int numSequentialDamage = 0;
    private long lastDamageTakenTime = 0;
    //Damage Hack
    private long lastDamage = 0;
    //Vac Hack
    private Point lastMonsterMove;
    private int monsterMoveCount;

    public AntiCheat(MapleCharacter chr) {
        this.chr = new WeakReference<MapleCharacter>(chr);
        validationTask = WLCTimer.getInstance().register(new ValidationTask(), 60000);
        attackingSince = regenMPSince = regenHPSince = System.currentTimeMillis();
        for (int i = 0; i < reason.length; i++) {
            reason[i] = 0;
        }
    }

    /**
     * Gets the total reasonpoint for the player.
     *
     * @param null
     * @return reasonpoint
     */
    private int getTotalPoints() {
        int ret = 0;
        for (int i = 0; i < reason.length; i++) {
            ret += reason[i];
        }
        return ret;
    }

    /**
     * Reason:
     * 0: Fast Attack
     * 1: Fast Hp Regen
     * 2: Fast Mp Regen
     * 3: God Mode
     * 4: Same Damage
     * 5: Vac Hack
     * 6: Fast Move
     *
     * @param reasonid
     * @return void
     */
    public void increaseReason(int reasonid) {
        if (getTotalPoints() == 0) {
            chr.get().setHasCheat(true);
        }
        reason[reasonid]++;
    }

    /**
     * Speed Hack Checker
     *
     * @param skillId
     * @return speedhacking or not
     */
    public boolean checkAttack(int skillId) {
        numSequentialAttacks++;
        long oldLastAttackTime = lastAttackTime;
        lastAttackTime = System.currentTimeMillis();
        long attackTime = lastAttackTime - attackingSince;
        if (numSequentialAttacks > 3) {
            final int divisor;
            if (skillId != 3121004) { // hurricane
                divisor = 150;
            } else {
                divisor = 400;
            }
            if (attackTime / divisor < numSequentialAttacks) {
                increaseReason(0);
                return false;
            }
        }
        if (lastAttackTime - oldLastAttackTime > 1500) {
            attackingSince = lastAttackTime;
            numSequentialAttacks = 0;
        }
        return true;
    }

    /**
     * Resets HP Regen handler if Hp is full
     *
     * @return void
     */
    private void resetHPRegen() {
        regenHPSince = System.currentTimeMillis();
        numHPRegens = 0;
    }

    /**
     * Checks HP Regen speed
     *
     * @return Fast HP Regen or not
     */
    public boolean checkHPRegen() {
        if (chr.get().getHp() == chr.get().getMaxHp()) {
            resetHPRegen();
            return true;
        }
        numHPRegens++;
        if ((System.currentTimeMillis() - regenHPSince) / 10000 < numHPRegens) {
            increaseReason(1);
            return false;
        }
        return true;
    }

    /**
     * Resets MP Regen handler if Mp is full
     *
     * @return void
     */
    private void resetMPRegen() {
        regenMPSince = System.currentTimeMillis();
        numMPRegens = 0;
    }

    /**
     * Checks MP Regen speed
     *
     * @return Fast MP Regen or not
     */
    public boolean checkMPRegen() {
        if (chr.get().getMp() == chr.get().getMaxMp()) {
            resetMPRegen();
            return true;
        }
        numMPRegens++;
        long allowedRegens = (System.currentTimeMillis() - regenMPSince) / 10000;
        if (allowedRegens < numMPRegens) {
            increaseReason(2);
            return false;
        }
        return true;
    }

    /**
     * Checks God Mode
     *
     * @return void
     */
    public void checkTakeDamage() {
        numSequentialDamage++;
        long oldLastDamageTakenTime = lastDamageTakenTime;
        lastDamageTakenTime = System.currentTimeMillis();

        long timeBetweenDamage = lastDamageTakenTime - takingDamageSince;

        if (timeBetweenDamage / 1000 < numSequentialDamage) {
            increaseReason(3);
        }
        if (lastDamageTakenTime - oldLastDamageTakenTime > 4500) {
            takingDamageSince = lastDamageTakenTime;
            numSequentialDamage = 0;
        }
    }

    /**
     * Checks Same Damage
     *
     * @return void
     */
    public void checkSameDamage(long dmg) {
        if (lastDamage == dmg) {
            increaseReason(4);
        } else {
            lastDamage = dmg;
            reason[4] = 0;
        }
    }

    /**
     * Checks Vac Hack
     *
     * @return void
     */
    public void checkMoveMonster(Point pos) {
        if (pos.equals(lastMonsterMove)) {
            monsterMoveCount++;
            if (monsterMoveCount > 3) {
                increaseReason(5);
            }
        } else {
            lastMonsterMove = pos;
            monsterMoveCount = 1;
        }
    }

    /**
     * Checks Fast Walk
     *
     * @return void
     */
    public void checkMovementSpeed(MapleCharacter chr, List<LifeMovementFragment> moves) {
        double playerSpeedMod = chr.getSpeedMod() + 0.005;
        boolean encounteredUnk0 = false;
        for (LifeMovementFragment lmf : moves) {
            if (lmf.getClass() == AbsoluteLifeMovement.class) {
                final AbsoluteLifeMovement alm = (AbsoluteLifeMovement) lmf;
                double speedMod = Math.abs(alm.getPixelsPerSecond().x) / 125.0;
                if (speedMod > playerSpeedMod) {
                    if (alm.getUnk() == 0) {
                        encounteredUnk0 = true;
                    }
                    if (!encounteredUnk0) {
                        if (speedMod > playerSpeedMod) {
                            increaseReason(6);
                        }
                    }
                }
            }
        }
    }

    /**
     * Gets the cheat reason and points
     *
     * @return cheat reason in a neat string
     */
    public String getCheats() {
        String reasons = null;
        if (reason[0] != 0) {
            if (reasons != null) {
                reasons += ", Fast Attack x " + reason[0];
            } else {
                reasons = "Fast Attack x " + reason[0];
            }
        }
        if (reason[1] != 0) {
            if (reasons != null) {
                reasons += ", Fast HP Regen x " + reason[1];
            } else {
                reasons = "Fast HP Regen x " + reason[1];
            }
        }
        if (reason[2] != 0) {
            if (reasons != null) {
                reasons += ", Fast MP Regen x " + reason[2];
            } else {
                reasons = "Fast MP Regen x " + reason[2];
            }
        }
        if (reason[3] != 0) {
            if (reasons != null) {
                reasons += ", God Mode x " + reason[3];
            } else {
                reasons = "God Mode x " + reason[3];
            }
        }
        if (reason[4] != 0) {
            if (reasons != null) {
                reasons += ", Same Damage x " + reason[3];
            } else {
                reasons = "Same Damage x " + reason[3];
            }
        }
        if (reason[5] != 0) {
            if (reasons != null) {
                reasons += ", Vac Hack x " + reason[5];
            } else {
                reasons = "Vac Hack x " + reason[5];
            }
        }
        if (reason[6] != 0) {
            if (reasons != null) {
                reasons += ", Fast Move x " + reason[6];
            } else {
                reasons = "Fast Move x " + reason[6];
            }
        }
        return reasons;
    }

    /**
     * Disposes the cheat tracker
     *
     * @return void
     */
    public void dispose() {
        chr = null;
        for (int i = 0; i < reason.length; i++) {
            reason[i] = 0;
        }
        validationTask.cancel(false);
    }

    private class ValidationTask implements Runnable {

        @Override
        public void run() {
            if (chr.get() != null) {
                if (getTotalPoints() > 750) {
                    chr.get().ban("Autoban system banned " + chr.get().getName() + ": " + getCheats(), true);
                    chr.get().announce(MaplePacketCreator.serverNotice(6, chr.get().getName() + " has been permanently banned."));
                    chr.get().announce(MaplePacketCreator.serverNotice(6, "Reason: " + getCheats()));
                    dispose();
                } else {
                    for (int i = 0; i < reason.length; i++) {
                        reason[i] = 0;
                    }
                    chr.get().setHasCheat(false);
                }
            } else {
                dispose();
            }
        }
    }
}