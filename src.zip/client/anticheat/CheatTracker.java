package client.anticheat;

import client.MapleCharacter;
import java.awt.Point;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import java.util.concurrent.ScheduledFuture;
import server.AutobanManager;
import server.MapleTimer.WLCTimer;
import tools.StringUtil;

public class CheatTracker {

    private Map<CheatingOffense, CheatingOffenseEntry> offenses = Collections.synchronizedMap(new LinkedHashMap<CheatingOffense, CheatingOffenseEntry>());
    private WeakReference<MapleCharacter> chr;
    private long regenHPSince;
    private long regenMPSince;
    private int numHPRegens;
    private int numMPRegens;
    private int numSequentialAttacks;
    private long lastAttackTime;
    private long lastDamage = 0;
    private long takingDamageSince;
    private int numSequentialDamage = 0;
    private long lastDamageTakenTime = 0;
    private int numSequentialSummonAttack = 0;
    private long summonSummonTime = 0;
    private int numSameDamage = 0;
    private long attackingSince;
    private Point lastMonsterMove;
    private int monsterMoveCount;
    private int attacksWithoutHit = 0;
    private long[] lastTime = new long[6];
    private Boolean pickupComplete = Boolean.TRUE;
    private ScheduledFuture<?> invalidationTask;

    public CheatTracker(MapleCharacter chr) {
        this.chr = new WeakReference<MapleCharacter>(chr);
        invalidationTask = WLCTimer.getInstance().register(new InvalidationTask(), 60000);
        takingDamageSince = attackingSince = regenMPSince = regenHPSince = System.currentTimeMillis();
    }

    /**
     * Checks Fast Walk
     *
     * @return void
     */
    /*    public void checkMovementSpeed(MapleCharacter chr, List<LifeMovementFragment> moves) {
    double playerSpeedMod = chr.getSpeedMod() + 0.005;
    boolean encounteredUnk0 = false;
    for (LifeMovementFragment lmf : moves) {
    if (lmf.getClass() == AbsoluteLifeMovement.class) {
    final AbsoluteLifeMovement alm = (AbsoluteLifeMovement) lmf;
    double speedMod = Math.abs(alm.getPixelsPerSecond().x) / 125.0;
    if (speedMod > playerSpeedMod) {
    if (alm.getUnk() == 0) {
    encounteredUnk0 = true;
    }
    if (!encounteredUnk0) {
    if (speedMod > playerSpeedMod) {
    registerOffense(CheatingOffense.FAST_MOVE);
    }
    }
    }
    }
    }
    }*/
    /**
     * Speed Hack Checker
     *
     * @param skillId
     * @return speedhacking or not
     */
    public boolean checkAttack(int skillId) {
        numSequentialAttacks++;
        long oldLastAttackTime = lastAttackTime;
        lastAttackTime = System.currentTimeMillis();
        long attackTime = lastAttackTime - attackingSince;
        if (numSequentialAttacks > 3) {
            final int divisor;
            if (skillId != 3121004) { // hurricane
                divisor = 50;
            } else {
                divisor = 350;
            }
            if (attackTime / divisor < numSequentialAttacks) {
                registerOffense(CheatingOffense.FASTATTACK);
                return false;
            }
        }
        if (lastAttackTime - oldLastAttackTime > 1500) {
            attackingSince = lastAttackTime;
            numSequentialAttacks = 0;
        }
        return true;
    }

    /**
     * Checks Vac Hack
     *
     * @return void
     */
//    public void checkMoveMonster(Point pos) {
//        if (pos.equals(lastMonsterMove)) {
//            monsterMoveCount++;
//            if (monsterMoveCount > 50) {
//                registerOffense(CheatingOffense.POSSIBLE_VAC);
//            }
//        } else {
//            lastMonsterMove = pos;
//            monsterMoveCount = 1;
//        }
//    }
    
    public void checkMoveMonster(Point pos) {
		if (pos.equals(lastMonsterMove)) {
			monsterMoveCount++;
			if (monsterMoveCount > 3) {
				registerOffense(CheatingOffense.MOVE_MONSTERS);
			}
		} else {
			lastMonsterMove = pos;
			monsterMoveCount = 1;
		}
	}

    /**
     * Checks God Mode
     *
     * @return void
     */
    public void checkTakeDamage() {
        numSequentialDamage++;
        long oldLastDamageTakenTime = lastDamageTakenTime;
        lastDamageTakenTime = System.currentTimeMillis();

        long timeBetweenDamage = lastDamageTakenTime - takingDamageSince;

        if (timeBetweenDamage / 1000 < numSequentialDamage) {
            registerOffense(CheatingOffense.FAST_TAKE_DAMAGE);
        }
        if (lastDamageTakenTime - oldLastDamageTakenTime > 4500) {
            takingDamageSince = lastDamageTakenTime;
            numSequentialDamage = 0;
        }
    }

    public int checkDamage(long dmg) {
        if (lastDamage == dmg) {
            numSameDamage++;
        } else {
            lastDamage = dmg;
            numSameDamage = 0;
        }
        return numSameDamage;
    }

    public synchronized boolean Spam(int limit, int type) {
        if (type < 0 || lastTime.length < type) {
            type = 1; // default xD
        }
        if (System.currentTimeMillis() < limit + lastTime[type]) {
            return true;
        }
        lastTime[type] = System.currentTimeMillis();
        return false;
    }

    /**
     * Resets HP Regen handler if Hp is full
     *
     * @return void
     */
    public void resetHPRegen() {
        regenHPSince = System.currentTimeMillis();
        numHPRegens = 0;
    }

    /**
     * Checks HP Regen speed
     *
     * @return Fast HP Regen or not
     */
    public boolean checkHPRegen() {
        if (chr.get().getHp() == chr.get().getMaxHp()) {
            resetHPRegen();
            return true;
        }
        numHPRegens++;
        if ((System.currentTimeMillis() - regenHPSince) / 10000 < numHPRegens) {
            registerOffense(CheatingOffense.FAST_HP_REGEN);
            return false;
        }
        return true;
    }

    /**
     * Resets MP Regen handler if Mp is full
     *
     * @return void
     */
    public void resetMPRegen() {
        regenMPSince = System.currentTimeMillis();
        numMPRegens = 0;
    }

    /**
     * Checks MP Regen speed
     *
     * @return Fast MP Regen or not
     */
    public boolean checkMPRegen() {
        if (chr.get().getMp() == chr.get().getMaxMp()) {
            resetMPRegen();
            return true;
        }
        numMPRegens++;
        long allowedRegens = (System.currentTimeMillis() - regenMPSince) / 10000;
        if (allowedRegens < numMPRegens) {
            registerOffense(CheatingOffense.FAST_MP_REGEN);
            return false;
        }
        return true;
    }

    public void resetSummonAttack() {
        summonSummonTime = System.currentTimeMillis();
        numSequentialSummonAttack = 0;
    }

    public boolean checkSummonAttack() {
        numSequentialSummonAttack++;
        //estimated
        long allowedAttacks = (System.currentTimeMillis() - summonSummonTime) / 2000 + 1;
        // System.out.println(numMPRegens + "/" + allowedRegens);
        if (allowedAttacks < numSequentialAttacks) {
            registerOffense(CheatingOffense.FAST_SUMMON_ATTACK);
            return false;
        }
        return true;
    }

    public void checkPickupAgain() {
        synchronized (pickupComplete) {
            if (pickupComplete) {
                pickupComplete = Boolean.FALSE;
            } else {
                registerOffense(CheatingOffense.TUBI);
            }
        }
    }

    public void pickupComplete() {
        synchronized (pickupComplete) {
            pickupComplete = Boolean.TRUE;
        }
    }

    public int getAttacksWithoutHit() {
        return attacksWithoutHit;
    }

    public void setAttacksWithoutHit(int attacksWithoutHit) {
        this.attacksWithoutHit = attacksWithoutHit;
    }

    public void registerOffense(CheatingOffense offense) {
        registerOffense(offense, null);
    }

    public void registerOffense(CheatingOffense offense, String param) {
        MapleCharacter chrhardref = chr.get();
        if (chrhardref == null || !offense.isEnabled()) {
            return;
        }

        CheatingOffenseEntry entry = offenses.get(offense);
        if (entry != null && entry.isExpired()) {
            expireEntry(entry);
            entry = null;
        }
        if (entry == null) {
            entry = new CheatingOffenseEntry(offense, chrhardref);
        }
        if (param != null) {
            entry.setParam(param);
        }
        entry.incrementCount();
        if (offense.shouldAutoban(entry.getCount())) {
            AutobanManager.getInstance().autoban(chrhardref.getClient(), StringUtil.makeEnumHumanReadable(offense.name()));
        }
        offenses.put(offense, entry);
        CheatingOffensePersister.getInstance().persistEntry(entry);
    }

    public void expireEntry(CheatingOffenseEntry coe) {
        offenses.remove(coe.getOffense());
    }

    public int getPoints() {
        int ret = 0;
        CheatingOffenseEntry[] offenses_copy;
        synchronized (offenses) {
            offenses_copy = offenses.values().toArray(new CheatingOffenseEntry[offenses.size()]);
        }
        for (CheatingOffenseEntry entry : offenses_copy) {
            if (entry.isExpired()) {
                expireEntry(entry);
            } else {
                ret += entry.getPoints();
            }
        }
        return ret;
    }

    public Map<CheatingOffense, CheatingOffenseEntry> getOffenses() {
        return Collections.unmodifiableMap(offenses);
    }

    public String getSummary() {
        StringBuilder ret = new StringBuilder();
        List<CheatingOffenseEntry> offenseList = new ArrayList<CheatingOffenseEntry>();
        synchronized (offenses) {
            for (CheatingOffenseEntry entry : offenses.values()) {
                if (!entry.isExpired()) {
                    offenseList.add(entry);
                }
            }
        }
        Collections.sort(offenseList, new Comparator<CheatingOffenseEntry>() {

            @Override
            public int compare(CheatingOffenseEntry o1, CheatingOffenseEntry o2) {
                int thisVal = o1.getPoints();
                int anotherVal = o2.getPoints();
                return (thisVal < anotherVal ? 1 : (thisVal == anotherVal ? 0 : -1));
            }
        });
        int to = Math.min(offenseList.size(), 4);
        for (int x = 0; x < to; x++) {
            ret.append(StringUtil.makeEnumHumanReadable(offenseList.get(x).getOffense().name()));
            ret.append(": ");
            ret.append(offenseList.get(x).getCount());
            if (x != to - 1) {
                ret.append(" ");
            }
        }
        return ret.toString();
    }

    public void dispose() {
        invalidationTask.cancel(false);
    }

    private class InvalidationTask implements Runnable {

        @Override
        public void run() {
            CheatingOffenseEntry[] offenses_copy;
            synchronized (offenses) {
                offenses_copy = offenses.values().toArray(new CheatingOffenseEntry[offenses.size()]);
            }
            for (CheatingOffenseEntry offense : offenses_copy) {
                if (offense.isExpired()) {
                    expireEntry(offense);
                }
            }

            if (chr.get() == null) {
                dispose();
            }
        }
    }
}