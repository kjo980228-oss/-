/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package client.messages.commands;

import java.net.InetAddress;
import java.rmi.RemoteException;
import java.util.Collection;
import client.MapleCharacter;
import client.MapleCharacterUtil;
import client.MapleClient;
import client.MapleJob;
import client.MapleStat;
import client.messages.Command;
import client.messages.CommandDefinition;
import client.messages.CommandProcessor;
import static client.messages.CommandProcessor.getNamedIntArg;
import static client.messages.CommandProcessor.getOptionalIntArg;
import static client.messages.CommandProcessor.joinAfterString;
import client.messages.IllegalCommandSyntaxException;
import client.messages.MessageCallback;
import config.configuracoes.mensagens.Mensagens;
import java.io.File;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import net.MaplePacket;
import net.channel.ChannelServer;
import net.world.remote.WorldChannelInterface;
import net.world.remote.WorldLocation;
import provider.MapleData;
import provider.MapleDataProvider;
import provider.MapleDataProviderFactory;
import provider.MapleDataTool;
import server.MapleItemInformationProvider;
import server.MaplePortal;
import server.MapleTrade;
import server.eventos.VerdadeiroFalso;
import server.life.MapleMonster;
import server.maps.MapleMap;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import tools.MaplePacketCreator;
import tools.Pair;
import tools.StringUtil;

public class HelpCommand implements Command {
     
       MapleItemInformationProvider ii = MapleItemInformationProvider.getInstance();
    
	@Override
	public void execute(MapleClient c, MessageCallback mc, String[] splittedLineLineLine) throws Exception,
		IllegalCommandSyntaxException {
            	MapleCharacter player = c.getPlayer();	
                ChannelServer cserv = c.getChannelServer();
                if (splittedLineLineLine[0].equals("!evento")) {
                int mapid = getOptionalIntArg(splittedLineLineLine, 1, c.getPlayer().getMapId());
                if (player.getClient().getChannelServer().eventOn == false) {
                player.getClient().getChannelServer().eventOn = true;
                player.getClient().getChannelServer().eventMap = mapid;
                try {
                    ChannelServer.getInstance(c.getChannel()).getWorldInterface().broadcastMessage(null, MaplePacketCreator.serverNotice(6, c.getChannel(), "[Evento] O evento foi iniciado no canal (" + c.getChannel() + "). Use @evento para participar.").getBytes()); 
                } catch (RemoteException e) {
                    ChannelServer.getInstance(c.getChannel()).reconnectWorld();
                }
            } else {
                player.getClient().getChannelServer().eventOn = false;
                try {
                     ChannelServer.getInstance(c.getChannel()).getWorldInterface().broadcastMessage(null, MaplePacketCreator.serverNotice(6, c.getChannel(), "[Evento] O evento terminou, obrigado aqueles que participaram.").getBytes());  
                } catch (RemoteException e) {
                    ChannelServer.getInstance(c.getChannel()).reconnectWorld();
                }
            }
        } else if (splittedLineLineLine[0].equals("setall")) {
            final int x = Short.parseShort(splittedLineLineLine[1]);
            player.setStr(x);
            player.setDex(x);
            player.setInt(x);
            player.setLuk(x);
            player.updateSingleStat(MapleStat.STR, x);
            player.updateSingleStat(MapleStat.DEX, x);
            player.updateSingleStat(MapleStat.INT, x);
            player.updateSingleStat(MapleStat.LUK, x);
        } else if (splittedLineLineLine[0].equals("!online")) {
			mc.dropMessage("Total de jogadores no canal  " + c.getChannel() + ":");
			Collection<MapleCharacter> chrs = c.getChannelServer().getInstance(c.getChannel()).getPlayerStorage().getAllCharacters();
			for (MapleCharacter chr : chrs) {
				mc.dropMessage(chr.getName() + " no mapa ID: " + chr.getMapId());
			}
			mc.dropMessage("Total de jogadores no canal " + c.getChannel() + ": " + chrs.size());
                        player.dropOverheadMessage("Servidor online desde o dia " + ChannelServer.getInstance(player.getClient().getChannel()).getOnlineServerDias() + "\r\nas " + ChannelServer.getInstance(player.getClient().getChannel()).getOnlineServerHora() + " horas e "  + ChannelServer.getInstance(player.getClient().getChannel()).getOnlineServerMinuto() + " minutos e\r\n" + ChannelServer.getInstance(player.getClient().getChannel()).getOnlineServerSegundos() + " segundo(s).");
	} else if (splittedLineLineLine[0].equals("!job")) {
			int jobId = Integer.parseInt(splittedLineLineLine[1]);
			if (MapleJob.getById(jobId) != null) {
			player.changeJob(MapleJob.getById(jobId));
                        }
		} else if (splittedLineLineLine[0].equals("!ban")) {
			if (splittedLineLineLine.length < 3) {
				throw new IllegalCommandSyntaxException(3);
			}
			String originalReason = StringUtil.joinStringFrom(splittedLineLineLine, 2);
			String reason = c.getPlayer().getName() + " bloqueado " + splittedLineLineLine[1] + ": " + originalReason;
			MapleCharacter target = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);
			if (target != null) {
				String readableTargetName = MapleCharacterUtil.makeMapleReadable(target.getName());
				String ip = target.getClient().getSession().getRemoteAddress().toString().split(":")[0];
				reason += " (IP: " + ip + ")";
				target.ban(reason);
				cserv.broadcastPacket(MaplePacketCreator.serverNotice(6, readableTargetName + " foi bloqueado por " + originalReason));

				mc.dropMessage(readableTargetName + "'s IP: " + ip + "!");
                        }
                } else if (splittedLineLineLine[0].equals("!warp")) {
			MapleCharacter victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);
			if (victim != null) {
				if (splittedLineLineLine.length == 2) {
					MapleMap target = victim.getMap();
					c.getPlayer().changeMap(target, target.findClosestSpawnpoint(victim.getPosition()));

				} else {
					int mapid = Integer.parseInt(splittedLineLineLine[2]);
					MapleMap target = ChannelServer.getInstance(c.getChannel()).getMapFactory().getMap(mapid);
					victim.changeMap(target, target.getPortal(0));
				}
			} else {
				try {
					victim = c.getPlayer();
					WorldLocation loc = c.getChannelServer().getWorldInterface().getLocation(splittedLineLineLine[1]);
					if (loc != null) {
						mc.dropMessage("Voc� ser� levado p/ o canal. Isso pode demorar alguns segundos.");
						// WorldLocation loc = new WorldLocation(40000, 2);
						MapleMap target = c.getChannelServer().getMapFactory().getMap(loc.map);
						String ip = c.getChannelServer().getIP(loc.channel);
						c.getPlayer().getMap().removePlayer(c.getPlayer());
						victim.setMap(target);
						String[] socket = ip.split(":");
						if (c.getPlayer().getTrade() != null) {
							MapleTrade.cancelTrade(c.getPlayer());
						}
						try {
							WorldChannelInterface wci = ChannelServer.getInstance(c.getChannel()).getWorldInterface();
							wci.addBuffsToStorage(c.getPlayer().getId(), c.getPlayer().getAllBuffs());
							wci.addCooldownsToStorage(c.getPlayer().getId(), c.getPlayer().getAllCooldowns());
						} catch (RemoteException e) {
							c.getChannelServer().reconnectWorld();
						}
						c.getPlayer().saveToDB(true, true);
						if (c.getPlayer().getCheatTracker() != null)
							c.getPlayer().getCheatTracker().dispose();
						ChannelServer.getInstance(c.getChannel()).removePlayer(c.getPlayer());
						c.updateLoginState(MapleClient.LOGIN_SERVER_TRANSITION);
						try {
							MaplePacket packet = MaplePacketCreator.getChannelChange(InetAddress.getByName(socket[0]), Integer.parseInt(socket[1]));
							c.getSession().write(packet);
						} catch (Exception e) {
							throw new RuntimeException(e);
						}
					} else {
						int map = Integer.parseInt(splittedLineLineLine[1]);
						MapleMap target = cserv.getMapFactory().getMap(map);
						c.getPlayer().changeMap(target, target.getPortal(0));
					}

				} catch (/* Remote */Exception e) {
					mc.dropMessage("Algo deu errado " + e.getMessage());
				}
			}
		}  else if (splittedLineLineLine[0].equals("!warphere")) {
			MapleCharacter victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);
			victim.changeMap(c.getPlayer().getMap(), c.getPlayer().getMap().findClosestSpawnpoint(c.getPlayer().getPosition()));

		} else if (splittedLineLineLine[0].equals("!dc")) {
			int level = 0;
			MapleCharacter victim;
			if (splittedLineLineLine[1].charAt(0) == '-') {
				level = StringUtil.countCharacters(splittedLineLineLine[0], 'f');
				victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[2]);
			} else {
				victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);
			}

			if (level < 2) {
				victim.getClient().getSession().close();
				if (level >= 1) {
					victim.getClient().disconnect();
				}
			} else {
				mc.dropMessage("User -f.");
                        }
            } else if (splittedLineLineLine[0].equals("!conectados")) {
            try {
                Map<Integer, Integer> connected = cserv.getWorldInterface().getConnected();
                StringBuilder conStr = new StringBuilder("Jogadores Conectados: ");
                boolean first = true;
                for (int i : connected.keySet()) {
                    if (!first) {
                        conStr.append(", ");
                    } else {
                        first = false;
                    }
                    if (i == 0) {
                        conStr.append("Total : " + connected.get(i));
                    } else {
                        conStr.append("Ch" + i + ": " + connected.get(i));
                    }
                }
                player.dropMessage(6, conStr.toString());
            } catch (RemoteException e) {
               cserv.reconnectWorld();
            }
        } else if (splittedLineLineLine[0].equals("!tempban")) {
			Calendar tempB = Calendar.getInstance();
			String originalReason = joinAfterString(splittedLineLineLine, ":");

			if (splittedLineLineLine.length < 4 || originalReason == null) {
				 mc.dropMessage("Usar: !tempban <nome> [i / m / w / d / h] <quantidade> [r [razao id] : Texto razao <Certifique-se de colocar :>");
                                 return;
				//throw new IllegalCommandSyntaxException(4);
			}

			int yChange = getNamedIntArg(splittedLineLineLine, 1, "y", 0);
			int mChange = getNamedIntArg(splittedLineLineLine, 1, "m", 0);
			int wChange = getNamedIntArg(splittedLineLineLine, 1, "w", 0);
			int dChange = getNamedIntArg(splittedLineLineLine, 1, "d", 0);
			int hChange = getNamedIntArg(splittedLineLineLine, 1, "h", 0);
			int iChange = getNamedIntArg(splittedLineLineLine, 1, "i", 0);
			int gReason = getNamedIntArg(splittedLineLineLine, 1, "r", 7);

			String reason = c.getPlayer().getName() + " bloqueado temporariamente " + splittedLineLineLine[1] + ": " + originalReason;

			if (gReason > 14) {
				mc.dropMessage("Voc� digitou um ID incorreto, por favor, tente novamente.");
				return;
			}

			DateFormat df = DateFormat.getInstance();
			tempB.set(tempB.get(Calendar.YEAR) + yChange, tempB.get(Calendar.MONTH) + mChange, tempB.get(Calendar.DATE) +
				(wChange * 7) + dChange, tempB.get(Calendar.HOUR_OF_DAY) + hChange, tempB.get(Calendar.MINUTE) +
				iChange);

			MapleCharacter victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);

			if (victim == null) {
				int accId = MapleClient.findAccIdForCharacterName(splittedLineLineLine[1]);
				if (accId >= 0 && MapleCharacter.tempban(reason, tempB, gReason, accId)) {
					String readableTargetName = MapleCharacterUtil.makeMapleReadable(victim.getName());
					cserv.broadcastPacket(MaplePacketCreator.serverNotice(6, readableTargetName + " foi bloqueado por " + originalReason));

				} else {
					mc.dropMessage("Houve um problema de personagem off-line " + splittedLineLineLine[1] + ".");
				}
			} else {
				victim.tempban(reason, tempB, gReason);
				mc.dropMessage("O personagem " + splittedLineLineLine[1] + " foi bloqueado temporariamente at� " +
					df.format(tempB.getTime()));
			}
		} else if (splittedLineLineLine[0].equals("!killall")) {
			String mapMessage = "";
			MapleMap map = c.getPlayer().getMap();
			double range = Double.POSITIVE_INFINITY;
			boolean drop = false;
			boolean diffMap = false;
			if (splittedLineLineLine.length > 1) {
				if (splittedLineLineLine[1].equalsIgnoreCase("-drop")) {
					drop = true;
				} else if (splittedLineLineLine[1].equalsIgnoreCase("-map")) {
					diffMap = true;
					map = c.getChannelServer().getMapFactory().getMap(Integer.parseInt(splittedLineLineLine[2]));
				}
			}
			if (splittedLineLineLine.length > 1 && !drop && !diffMap) {
				int irange = Integer.parseInt(splittedLineLineLine[1]);
				if (splittedLineLineLine.length <= 2)                              
				  range = irange * irange;
				else
				{
				  map = c.getChannelServer().getMapFactory().getMap(Integer.parseInt(splittedLineLineLine[2]));
				  mapMessage = " in " + map.getStreetName() + " : " + map.getMapName();
				}
			}
			List<MapleMapObject> monsters = map.getMapObjectsInRange(c.getPlayer().getPosition(), range, Arrays.asList(MapleMapObjectType.MONSTER));
			boolean kill = splittedLineLineLine[0].equals("!killall");
			for (MapleMapObject monstermo : monsters) {
				MapleMonster monster = (MapleMonster) monstermo;
				if (kill) {
					map.killMonster(monster, c.getPlayer(), drop);
				} else {
					mc.dropMessage("Monster " + monster.toString());
				}
			}
			if (kill) {
				mc.dropMessage("Killed " + monsters.size() + " monsters" + mapMessage + ".");
			}
		} else if (splittedLineLineLine[0].equals("!map")) {
			int mapid = Integer.parseInt(splittedLineLineLine[1]);
			MapleMap target = cserv.getMapFactory().getMap(mapid);
			MaplePortal targetPortal = null;
			if (splittedLineLineLine.length > 2) {
				try {
					targetPortal = target.getPortal(Integer.parseInt(splittedLineLineLine[2]));
				} catch (IndexOutOfBoundsException ioobe) {
					// noop, assume the gm didn't know how many portals there are
				} catch (NumberFormatException nfe) {
					// noop, assume that the gm is drunk
				}
			}
			if (targetPortal == null) {
				targetPortal = target.getPortal(0);
			}
			c.getPlayer().changeMap(target, targetPortal);
		} else if (splittedLineLineLine[0].equals("!procurar")) {
		     if (splittedLineLineLine.length == 1) {
	             mc.dropMessage(splittedLineLineLine[0] + ": <NPC> <MOB> <ITEM> <MAP> <SKILL>");
                } else {

                    String type = splittedLineLineLine[1];
                    String search = StringUtil.joinStringFrom(splittedLineLineLine, 2);
                    MapleData data = null;
                    MapleDataProvider dataProvider = MapleDataProviderFactory.getDataProvider(new File(System.getProperty("wzpath") + "/" + "String.wz"));
                    mc.dropMessage("<<Tipo: " + type + " | Procurar: " + search + ">>");
                    if (type.equalsIgnoreCase("NPC") || type.equalsIgnoreCase("NPCS")) {
                        List<String> retNpcs = new ArrayList<String>();
                        data = dataProvider.getData("Npc.img");
                        List<Pair<Integer, String>> npcPairList = new LinkedList<Pair<Integer, String>>();
                        for (MapleData npcIdData : data.getChildren()) {
                            int npcIdFromData = Integer.parseInt(npcIdData.getName());
                            String npcNameFromData = MapleDataTool.getString(npcIdData.getChildByPath("name"), "NO-NAME");
                            npcPairList.add(new Pair<Integer, String>(npcIdFromData, npcNameFromData));
                        }
                        for (Pair<Integer, String> npcPair : npcPairList) {
                            if (npcPair.getRight().toLowerCase().contains(search.toLowerCase())) {
                                retNpcs.add(npcPair.getLeft() + " - " + npcPair.getRight());
                            }
                        }
                        if (retNpcs != null && retNpcs.size() > 0) {
                            for (String singleRetNpc : retNpcs) {
                                mc.dropMessage(singleRetNpc);
                            }
                        } else {
                            mc.dropMessage("Nenhum NPC encontrado!");
                        }

                    } else if (type.equalsIgnoreCase("MAP") || type.equalsIgnoreCase("MAPS")) {
                        List<String> retMaps = new ArrayList<String>();
                        data = dataProvider.getData("Map.img");
                        List<Pair<Integer, String>> mapPairList = new LinkedList<Pair<Integer, String>>();
                        for (MapleData mapAreaData : data.getChildren()) {
                            for (MapleData mapIdData : mapAreaData.getChildren()) {
                                int mapIdFromData = Integer.parseInt(mapIdData.getName());
                                String mapNameFromData = MapleDataTool.getString(mapIdData.getChildByPath("streetName"), "NO-NAME") + " - " + MapleDataTool.getString(mapIdData.getChildByPath("mapName"), "NO-NAME");
                                mapPairList.add(new Pair<Integer, String>(mapIdFromData, mapNameFromData));
                            }
                        }
                        for (Pair<Integer, String> mapPair : mapPairList) {
                            if (mapPair.getRight().toLowerCase().contains(search.toLowerCase())) {
                                retMaps.add(mapPair.getLeft() + " - " + mapPair.getRight());
                            }
                        }
                        if (retMaps != null && retMaps.size() > 0) {
                            for (String singleRetMap : retMaps) {
                                mc.dropMessage(singleRetMap);
                            }
                        } else {
                            mc.dropMessage("Nenhum MAPA encontrado!");
                        }

                    } else if (type.equalsIgnoreCase("MOB") || type.equalsIgnoreCase("MOBS") || type.equalsIgnoreCase("MONSTER") || type.equalsIgnoreCase("MONSTERS")) {
                        List<String> retMobs = new ArrayList<String>();
                        data = dataProvider.getData("Mob.img");
                        List<Pair<Integer, String>> mobPairList = new LinkedList<Pair<Integer, String>>();
                        for (MapleData mobIdData : data.getChildren()) {
                            int mobIdFromData = Integer.parseInt(mobIdData.getName());
                            String mobNameFromData = MapleDataTool.getString(mobIdData.getChildByPath("name"), "NO-NAME");
                            mobPairList.add(new Pair<Integer, String>(mobIdFromData, mobNameFromData));
                        }
                        for (Pair<Integer, String> mobPair : mobPairList) {
                            if (mobPair.getRight().toLowerCase().contains(search.toLowerCase())) {
                                retMobs.add(mobPair.getLeft() + " - " + mobPair.getRight());
                            }
                        }
                        if (retMobs != null && retMobs.size() > 0) {
                            for (String singleRetMob : retMobs) {
                                mc.dropMessage(singleRetMob);
                            }
                        } else {
                            mc.dropMessage("Nenhum MONSTRO encontrado!");
                        }

                    } else if (type.equalsIgnoreCase("REACTOR") || type.equalsIgnoreCase("REACTORS")) {
                        mc.dropMessage("NOT ADDED YET");

                    } else if (type.equalsIgnoreCase("ITEM") || type.equalsIgnoreCase("ITEMS")) {
                        List<String> retItems = new ArrayList<String>();
                        for (Pair<Integer, String> itemPair : ii.getAllItems()) {
                            if (itemPair.getRight().toLowerCase().contains(search.toLowerCase())) {
                                retItems.add(itemPair.getLeft() + " - " + itemPair.getRight());
                            }
                        }
                        if (retItems != null && retItems.size() > 0) {
                            for (String singleRetItem : retItems) {
                                mc.dropMessage(singleRetItem);
                            }
                        } else {
                            mc.dropMessage("No Item's Found");
                        }

                    } else if (type.equalsIgnoreCase("SKILL") || type.equalsIgnoreCase("SKILLS")) {
                        List<String> retSkills = new ArrayList<String>();
                        data = dataProvider.getData("Skill.img");
                        List<Pair<Integer, String>> skillPairList = new LinkedList<Pair<Integer, String>>();
                        for (MapleData skillIdData : data.getChildren()) {
                            int skillIdFromData = Integer.parseInt(skillIdData.getName());
                            String skillNameFromData = MapleDataTool.getString(skillIdData.getChildByPath("name"), "NO-NAME");
                            skillPairList.add(new Pair<Integer, String>(skillIdFromData, skillNameFromData));
                        }
                        for (Pair<Integer, String> skillPair : skillPairList) {
                            if (skillPair.getRight().toLowerCase().contains(search.toLowerCase())) {
                                retSkills.add(skillPair.getLeft() + " - " + skillPair.getRight());
                            }
                        }
                        if (retSkills != null && retSkills.size() > 0) {
                            for (String singleRetSkill : retSkills) {
                                mc.dropMessage(singleRetSkill);
                            }
                        } else {
                            mc.dropMessage("No Skills Found");
                        }
                    } else {
                      mc.dropMessage("Sorry, that search call is unavailable");
                    }
                }
            } else if (splittedLineLineLine[0].equalsIgnoreCase("!maxskills")) {
            teachSkill(c, 9001000, 1, 1); //Start of max-level "1" skills
            teachSkill(c, 9001001, 1, 1);
            teachSkill(c, 9001002, 1, 1);
            teachSkill(c, 9101000, 1, 1);
            teachSkill(c, 9101001, 1, 1);
            teachSkill(c, 9101002, 1, 1);
            teachSkill(c, 9101003, 1, 1);
            teachSkill(c, 9101004, 1, 1);
            teachSkill(c, 9101005, 1, 1);
            teachSkill(c, 9101006, 1, 1);
            teachSkill(c, 9101007, 1, 1);
            teachSkill(c, 9101008, 1, 1);
            teachSkill(c, 5000000, 20, 20);//no here
            teachSkill(c, 5001001, 20, 20); //Start of Pirate Job Skills
            teachSkill(c, 5001002, 20, 20);
            teachSkill(c, 5001003, 20, 20);
            teachSkill(c, 5001005, 10, 10);
            teachSkill(c, 5100000, 10, 10);
            teachSkill(c, 5100001, 20, 20);
            teachSkill(c, 5101002, 20, 20);
            teachSkill(c, 5101003, 20, 20);
            teachSkill(c, 5101004, 20, 20);
            teachSkill(c, 5101005, 10, 10);
            teachSkill(c, 5101006, 20, 20);
            teachSkill(c, 5101007, 10, 10);
            teachSkill(c, 5200000, 20, 20);
            teachSkill(c, 5201001, 20, 20);
            teachSkill(c, 5201002, 20, 20);
            teachSkill(c, 5201003, 20, 20);
            teachSkill(c, 5201004, 20, 20);
            teachSkill(c, 5201005, 10, 10);
            teachSkill(c, 5201006, 20, 20);
            teachSkill(c, 5110000, 20, 20);
            teachSkill(c, 5110001, 40, 40);
            teachSkill(c, 5111002, 30, 30);
            teachSkill(c, 5111004, 20, 20);
            teachSkill(c, 5111005, 20, 20);
            teachSkill(c, 5111006, 30, 30);
            teachSkill(c, 5210000, 20, 20);
            teachSkill(c, 5211001, 30, 30);
            teachSkill(c, 5211002, 30, 30);
            teachSkill(c, 5211004, 30, 30);
            teachSkill(c, 5211005, 30, 30);
            teachSkill(c, 5211006, 30, 30);
            teachSkill(c, 5220001, 30, 30);
            teachSkill(c, 5220002, 20, 20);
            teachSkill(c, 5221000, 20, 20);
            teachSkill(c, 5221003, 30, 30);
            teachSkill(c, 5221004, 30, 30);
            teachSkill(c, 5221006, 10, 10);
            teachSkill(c, 5221007, 30, 30);
            teachSkill(c, 5221008, 30, 30);
            teachSkill(c, 5221009, 20, 20);
            teachSkill(c, 5221010, 1, 1);
            teachSkill(c, 5220011, 20, 20);
            teachSkill(c, 5121000, 20, 20);
            teachSkill(c, 5121001, 30, 30);
            teachSkill(c, 5121002, 30, 30);
            teachSkill(c, 5121003, 20, 20);
            teachSkill(c, 5121004, 30, 30);
            teachSkill(c, 5121005, 30, 30);
            teachSkill(c, 5121007, 30, 30);
            teachSkill(c, 5121008, 1, 1);
            teachSkill(c, 5121009, 20, 20); //End of Pirate Job Skills
            teachSkill(c, 5121010, 30, 30); //End of Pirate Job Skills
            teachSkill(c, 1003, 1, 1);
            teachSkill(c, 1004, 1, 1);
            teachSkill(c, 1121011, 1, 1);
            teachSkill(c, 1221012, 1, 1);
            teachSkill(c, 1321010, 1, 1);
            teachSkill(c, 2121008, 1, 1);
            teachSkill(c, 2221008, 1, 1);
            teachSkill(c, 2321009, 1, 1);
            teachSkill(c, 3121009, 1, 1);
            teachSkill(c, 3221008, 1, 1);
            teachSkill(c, 4121009, 1, 1);
            teachSkill(c, 4221008, 1, 1); //End of max-level "1" skills
            teachSkill(c, 1000002, 8, 8); //Start of max-level "8" skills
            teachSkill(c, 3000002, 8, 8);
            teachSkill(c, 4000001, 8, 8); //End of max-level "8" skills
            teachSkill(c, 1000001, 10, 10); //Start of max-level "10" skills
            teachSkill(c, 2000001, 10, 10); //End of max-level "10" skills
            teachSkill(c, 1000000, 16, 16); //Start of max-level "16" skills
            teachSkill(c, 2000000, 16, 16);
            teachSkill(c, 3000000, 16, 16); //End of max-level "16" skills
            teachSkill(c, 1001003, 20, 20); //Start of max-level "20" skills
            teachSkill(c, 1001004, 20, 20);
            teachSkill(c, 1001005, 20, 20);
            teachSkill(c, 2001002, 20, 20);
            teachSkill(c, 2001003, 20, 20);
            teachSkill(c, 2001004, 20, 20);
            teachSkill(c, 2001005, 20, 20);
            teachSkill(c, 3000001, 20, 20);
            teachSkill(c, 3001003, 20, 20);
            teachSkill(c, 3001004, 20, 20);
            teachSkill(c, 3001005, 20, 20);
            teachSkill(c, 4000000, 20, 20);
            teachSkill(c, 4001344, 20, 20);
            teachSkill(c, 4001334, 20, 20);
            teachSkill(c, 4001002, 20, 20);
            teachSkill(c, 4001003, 20, 20);
            teachSkill(c, 1101005, 20, 20);
            teachSkill(c, 1100001, 20, 20); //Start of mastery's
            teachSkill(c, 1100000, 20, 20);
            teachSkill(c, 1200001, 20, 20);
            teachSkill(c, 1200000, 20, 20);
            teachSkill(c, 1300000, 20, 20);
            teachSkill(c, 1300001, 20, 20);
            teachSkill(c, 3100000, 20, 20);
            teachSkill(c, 3200000, 20, 20);
            teachSkill(c, 4100000, 20, 20);
            teachSkill(c, 4200000, 20, 20); //End of mastery's
            teachSkill(c, 4201002, 20, 20);
            teachSkill(c, 4101003, 20, 20);
            teachSkill(c, 3201002, 20, 20);
            teachSkill(c, 3101002, 20, 20);
            teachSkill(c, 1301004, 20, 20);
            teachSkill(c, 1301005, 20, 20);
            teachSkill(c, 1201004, 20, 20);
            teachSkill(c, 1201005, 20, 20);
            teachSkill(c, 1101004, 20, 20); //End of boosters
            teachSkill(c, 1101006, 20, 20);
            teachSkill(c, 1201006, 20, 20);
            teachSkill(c, 1301006, 20, 20);
            teachSkill(c, 2101001, 20, 20);
            teachSkill(c, 2100000, 20, 20);
            teachSkill(c, 2101003, 20, 20);
            teachSkill(c, 2101002, 20, 20);
            teachSkill(c, 2201001, 20, 20);
            teachSkill(c, 2200000, 20, 20);
            teachSkill(c, 2201003, 20, 20);
            teachSkill(c, 2201002, 20, 20);
            teachSkill(c, 2301004, 20, 20);
            teachSkill(c, 2301003, 20, 20);
            teachSkill(c, 2300000, 20, 20);
            teachSkill(c, 2301001, 20, 20);
            teachSkill(c, 3101003, 20, 20);
            teachSkill(c, 3101004, 20, 20);
            teachSkill(c, 3201003, 20, 20);
            teachSkill(c, 3201004, 20, 20);
            teachSkill(c, 4100002, 20, 20);
            teachSkill(c, 4101004, 20, 20);
            teachSkill(c, 4200001, 20, 20);
            teachSkill(c, 4201003, 20, 20); //End of second-job skills and first-job
            teachSkill(c, 4211005, 20, 20);
            teachSkill(c, 4211003, 20, 20);
            teachSkill(c, 4210000, 20, 20);
            teachSkill(c, 4110000, 20, 20);
            teachSkill(c, 4111001, 20, 20);
            teachSkill(c, 4111003, 20, 20);
            teachSkill(c, 3210000, 20, 20);
            teachSkill(c, 3110000, 20, 20);
            teachSkill(c, 3210001, 20, 20);
            teachSkill(c, 3110001, 20, 20);
            teachSkill(c, 3211002, 20, 20);
            teachSkill(c, 3111002, 20, 20);
            teachSkill(c, 2210000, 20, 20);
            teachSkill(c, 2211004, 20, 20);
            teachSkill(c, 2211005, 20, 20);
            teachSkill(c, 2111005, 20, 20);
            teachSkill(c, 2111004, 20, 20);
            teachSkill(c, 2110000, 20, 20);
            teachSkill(c, 2311001, 20, 20);
            teachSkill(c, 2311005, 20, 20);
            teachSkill(c, 2310000, 20, 20);
            teachSkill(c, 1311007, 20, 20);
            teachSkill(c, 1310000, 20, 20);
            teachSkill(c, 1311008, 20, 20);
            teachSkill(c, 1210001, 20, 20);
            teachSkill(c, 1211009, 20, 20);
            teachSkill(c, 1210000, 20, 20);
            teachSkill(c, 1110001, 20, 20);
            teachSkill(c, 1111007, 20, 20);
            teachSkill(c, 1110000, 20, 20); //End of 3rd job skills
            teachSkill(c, 1121000, 20, 20);
            teachSkill(c, 1221000, 20, 20);
            teachSkill(c, 1321000, 20, 20);
            teachSkill(c, 2121000, 20, 20);
            teachSkill(c, 2221000, 20, 20);
            teachSkill(c, 2321000, 20, 20);
            teachSkill(c, 3121000, 20, 20);
            teachSkill(c, 3221000, 20, 20);
            teachSkill(c, 4121000, 20, 20);
            teachSkill(c, 4221000, 20, 20); //End of Maple Warrior // Also end of max-level "20" skills
            teachSkill(c, 1321007, 10, 10);
            teachSkill(c, 1320009, 25, 25);
            teachSkill(c, 1320008, 25, 25);
            teachSkill(c, 2321006, 10, 10);
            teachSkill(c, 1220010, 10, 10);
            teachSkill(c, 1221004, 19, 19);
            teachSkill(c, 1221003, 19, 19);
            teachSkill(c, 1100003, 30, 30);
            teachSkill(c, 1100002, 30, 30);
            teachSkill(c, 1101007, 30, 30);
            teachSkill(c, 1200003, 30, 30);
            teachSkill(c, 1200002, 30, 30);
            teachSkill(c, 1201007, 30, 30);
            teachSkill(c, 1300003, 30, 30);
            teachSkill(c, 1300002, 30, 30);
            teachSkill(c, 1301007, 30, 30);
            teachSkill(c, 2101004, 30, 30);
            teachSkill(c, 2101005, 30, 30);
            teachSkill(c, 2201004, 30, 30);
            teachSkill(c, 2201005, 30, 30);
            teachSkill(c, 2301002, 30, 30);
            teachSkill(c, 2301005, 30, 30);
            teachSkill(c, 3101005, 30, 30);
            teachSkill(c, 3201005, 30, 30);
            teachSkill(c, 4100001, 30, 30);
            teachSkill(c, 4101005, 30, 30);
            teachSkill(c, 4201005, 30, 30);
            teachSkill(c, 4201004, 30, 30);
            teachSkill(c, 1111006, 30, 30);
            teachSkill(c, 1111005, 30, 30);
            teachSkill(c, 1111002, 30, 30);
            teachSkill(c, 1111004, 30, 30);
            teachSkill(c, 1111003, 30, 30);
            teachSkill(c, 1111008, 30, 30);
            teachSkill(c, 1211006, 30, 30);
            teachSkill(c, 1211002, 30, 30);
            teachSkill(c, 1211004, 30, 30);
            teachSkill(c, 1211003, 30, 30);
            teachSkill(c, 1211005, 30, 30);
            teachSkill(c, 1211008, 30, 30);
            teachSkill(c, 1211007, 30, 30);
            teachSkill(c, 1311004, 30, 30);
            teachSkill(c, 1311003, 30, 30);
            teachSkill(c, 1311006, 30, 30);
            teachSkill(c, 1311002, 30, 30);
            teachSkill(c, 1311005, 30, 30);
            teachSkill(c, 1311001, 30, 30);
            teachSkill(c, 2110001, 30, 30);
            teachSkill(c, 2111006, 30, 30);
            teachSkill(c, 2111002, 30, 30);
            teachSkill(c, 2111003, 30, 30);
            teachSkill(c, 2210001, 30, 30);
            teachSkill(c, 2211006, 30, 30);
            teachSkill(c, 2211002, 30, 30);
            teachSkill(c, 2211003, 30, 30);
            teachSkill(c, 2311003, 30, 30);
            teachSkill(c, 2311002, 30, 30);
            teachSkill(c, 2311004, 30, 30);
            teachSkill(c, 2311006, 30, 30);
            teachSkill(c, 3111004, 30, 30);
            teachSkill(c, 3111003, 30, 30);
            teachSkill(c, 3111005, 30, 30);
            teachSkill(c, 3111006, 30, 30);
            teachSkill(c, 3211004, 30, 30);
            teachSkill(c, 3211003, 30, 30);
            teachSkill(c, 3211005, 30, 30);
            teachSkill(c, 3211006, 30, 30);
            teachSkill(c, 4111005, 30, 30);
            teachSkill(c, 4111006, 20, 20);
            teachSkill(c, 4111004, 30, 30);
            teachSkill(c, 4111002, 30, 30);
            teachSkill(c, 4211002, 30, 30);
            teachSkill(c, 4211004, 30, 30);
            teachSkill(c, 4211001, 30, 30);
            teachSkill(c, 4211006, 30, 30);
            teachSkill(c, 1120004, 30, 30);
            teachSkill(c, 1120003, 30, 30);
            teachSkill(c, 1121008, 30, 30);
            teachSkill(c, 1121010, 30, 30);
            teachSkill(c, 1121006, 30, 30);
            teachSkill(c, 1121002, 30, 30);
            teachSkill(c, 1220005, 30, 30);
            teachSkill(c, 1221009, 30, 30);
            teachSkill(c, 1221007, 30, 30);
            teachSkill(c, 1221011, 30, 30);
            teachSkill(c, 1221002, 30, 30);
            teachSkill(c, 1320005, 30, 30);
            teachSkill(c, 1320006, 30, 30);
            teachSkill(c, 1321003, 30, 30);
            teachSkill(c, 1321002, 30, 30);
            teachSkill(c, 2121005, 30, 30);
            teachSkill(c, 2121003, 30, 30);
            teachSkill(c, 2121004, 30, 30);
            teachSkill(c, 2121002, 30, 30);
            teachSkill(c, 2121007, 30, 30);
            teachSkill(c, 2121006, 30, 30);
            teachSkill(c, 2221007, 30, 30);
            teachSkill(c, 2221006, 30, 30);
            teachSkill(c, 2221003, 30, 30);
            teachSkill(c, 2221005, 30, 30);
            teachSkill(c, 2221004, 30, 30);
            teachSkill(c, 2221002, 30, 30);
            teachSkill(c, 2321007, 30, 30);
            teachSkill(c, 2321003, 30, 30);
            teachSkill(c, 2321008, 30, 30);
            teachSkill(c, 2321005, 30, 30);
            teachSkill(c, 2321004, 30, 30);
            teachSkill(c, 2321002, 30, 30);
            teachSkill(c, 3120005, 30, 30);
            teachSkill(c, 3121008, 30, 30);
            teachSkill(c, 3121003, 30, 30);
            teachSkill(c, 3121007, 30, 30);
            teachSkill(c, 3121006, 30, 30);
            teachSkill(c, 3121002, 30, 30);
            teachSkill(c, 3121004, 30, 30);
            teachSkill(c, 3221006, 30, 30);
            teachSkill(c, 3220004, 30, 30);
            teachSkill(c, 3221003, 30, 30);
            teachSkill(c, 3221005, 30, 30);
            teachSkill(c, 3221001, 30, 30);
            teachSkill(c, 3221002, 30, 30);
            teachSkill(c, 4121004, 30, 30);
            teachSkill(c, 4121008, 30, 30);
            teachSkill(c, 4121003, 30, 30);
            teachSkill(c, 4121006, 30, 30);
            teachSkill(c, 4121007, 30, 30);
            teachSkill(c, 4120005, 30, 30);
            teachSkill(c, 4221001, 30, 30);
            teachSkill(c, 4221007, 30, 30);
            teachSkill(c, 4221004, 30, 30);
            teachSkill(c, 4221003, 30, 30);
            teachSkill(c, 4221006, 30, 30);
            teachSkill(c, 4220005, 30, 30);
            teachSkill(c, 1221001, 30, 30);
            teachSkill(c, 1121001, 30, 30);
            teachSkill(c, 1321001, 30, 30);
            teachSkill(c, 2121001, 30, 30);
            teachSkill(c, 2221001, 30, 30);
            teachSkill(c, 2321001, 30, 30);
        } else if (splittedLineLineLine[0].equals("!mutemap")) {
           player.getMap().getProperties().setProperty("mute", Boolean.TRUE);
           player.dropMessage("O mapa [" + player.getMapName(player.getMapId()) + "] est� mudo.");
        }  else if (splittedLineLineLine[0].equals("!unmutemap")) {
           c.getPlayer().getMap().getProperties().setProperty("mute", Boolean.FALSE);
           player.dropMessage("O mapa [" + player.getMapName(player.getMapId()) + "] n�o est� mudo.");
        } else if (splittedLineLineLine[0].equals("!oxp")) { // 1 verdadeiro - 0  falso
            VerdadeiroFalso.EnviaPergunta(c, Integer.parseInt(splittedLineLineLine[1]), StringUtil.joinStringFrom(splittedLineLineLine, 2));      
        } else if (splittedLineLineLine[0].equalsIgnoreCase("!level")) {
            int level = Integer.parseInt(splittedLineLineLine[1]);
            if (level < 1 || level > 200) {
                mc.dropMessage("N�o.");
                return;
            }
            c.getPlayer().setLevel(level);
            c.getPlayer().levelUp();
        } else if (splittedLineLineLine[0].equals("!mapmsg")) {
            c.getPlayer().getMap().stopMapEffect();
            c.getPlayer().getMap().startMapEffect(StringUtil.joinStringFrom(splittedLineLineLine, 1), 5120002);
        } else if (splittedLineLineLine[0].equals("!rgm")) {
            MapleCharacter victim = cserv.getPlayerStorage().getCharacterByName(splittedLineLineLine[1]);
            if(victim == null) {
                c.getPlayer().dropMessage("N�o � possivel encontrar este personagem!");
            } else {
            victim.dropMessage("[GM-Responde]: " + StringUtil.joinStringFrom(splittedLineLineLine, 2));
           }
        } else if (splittedLineLineLine[0].equals("!say")) {
			if (splittedLineLineLine.length > 1) {
				MaplePacket packet = MaplePacketCreator.serverNotice(6, "[" + c.getPlayer().getName() + "] " + StringUtil.joinStringFrom(splittedLineLineLine, 1));
				try {
					ChannelServer.getInstance(c.getChannel()).getWorldInterface().broadcastMessage(c.getPlayer().getName(), packet.getBytes());
				} catch (RemoteException e) {
					c.getChannelServer().reconnectWorld();
				}
			} else {
				mc.dropMessage("Usar: !say <mensagem>");
			} 
		} else if (splittedLineLineLine[0].equalsIgnoreCase("!comandos")) {
			mc.dropMessage("== " + Mensagens.Nome_Server + " Comandos ==");
		int page = CommandProcessor.getOptionalIntArg(splittedLineLineLine, 1, 1);
		CommandProcessor.getInstance().dropHelp(c.getPlayer(), mc, page);
		}
		else {
			mc.dropMessage("(GM-3) Comando " + splittedLineLineLine[0] + " nao existe!");
        }
    }

        
        
        
        
	@Override
	public CommandDefinition[] getDefinition() {
		return new CommandDefinition[] {
			new CommandDefinition("evento", "Inicia evento", "", 1),
                        new CommandDefinition("setall", "", "", 1),
                        new CommandDefinition("online", "", "", 1),
                        new CommandDefinition("conectados", "", "", 1),
                        new CommandDefinition("job", "", "", 1),
                        new CommandDefinition("ban", "", "", 1),
                        new CommandDefinition("warp", "", "", 1),
                        new CommandDefinition("warphere", "", "", 1),
                        new CommandDefinition("map", "", "", 1),
                        new CommandDefinition("say", "", "", 1),
                        new CommandDefinition("dc", "", "", 1),
                        new CommandDefinition("tempban", "", "", 1),
                        new CommandDefinition("killall", "", "", 1),
                        new CommandDefinition("procurar", "", "", 1),
                        new CommandDefinition("maxskills", "", "", 1),
                        new CommandDefinition("mutemap", "", "", 1),
                        new CommandDefinition("unmutemap", "", "", 1),
                        new CommandDefinition("oxp", "", "", 1),
                        new CommandDefinition("level", "", "", 1),
                        new CommandDefinition("mapmsg", "", "", 1),
                        new CommandDefinition("evento", "", "", 1),
                        new CommandDefinition("rgm", "", "", 1),
		};
	}
        
     public void teachSkill(MapleClient c, int skill, int a, int b) {
        c.getPlayer().changeSkillLevel(client.SkillFactory.getSkill(skill), a, b);
    }
}
