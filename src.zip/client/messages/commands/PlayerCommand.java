/*
This file is part of the OdinMS Maple Story Server
Copyright (C) 2008 Patrick Huy <patrick.huy~frz.cc>
Matthias Butz <matze~odinms.de>
Jan Christian Meyer <vimes~odinms.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License version 3
as published by the Free Software Foundation. You may not use, modify
or distribute this program under any other version of the
GNU Affero General Public License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

 * JavaScriptz (javascriptz@leaderms.com.br)
 * LeaderMS 2012 ▬ 2015
 * Brasil MapleStory Server
 * CashPQ
 * www.leaderms.com.br
 */


package client.messages.commands;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import client.MapleCharacter;
import client.MapleInventoryType;
import client.MapleClient;
import client.MapleInventory;
import client.messages.Command;
import client.messages.CommandDefinition;
import client.messages.IllegalCommandSyntaxException;
import client.messages.MessageCallback;
import config.configuracoes.mensagens.Mensagens;
import database.DatabaseConnection;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import net.channel.ChannelServer;
import provider.MapleData;
import provider.MapleDataProvider;
import provider.MapleDataProviderFactory;
import provider.MapleDataTool;
import scripting.npc.NPCScriptManager;
import server.MapleItemInformationProvider;
import server.life.MapleMonster;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import server.maps.SavedLocationType;
import tools.FilePrinter;
import tools.MaplePacketCreator;
import tools.Pair;
import tools.StringUtil;

public class PlayerCommand implements Command {

    private Map<Integer, Long> gmUsages = new LinkedHashMap<Integer, Long>();
    private Map<Integer, Long> questUsages = new LinkedHashMap<Integer, Long>();
    private static final SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
    private static final SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");

    @SuppressWarnings("static-access")
    @Override
    public void execute(MapleClient c, MessageCallback mc, String[] splitted) throws Exception, IllegalCommandSyntaxException {
          MapleCharacter player = c.getPlayer();
          ChannelServer cserv = c.getChannelServer();
         if (splitted[0].equalsIgnoreCase("@gm") || splitted[0].equalsIgnoreCase("!gm")) {
            if (splitted.length == 1) {
                mc.dropMessage("Tipo: @gm <mensagem>");
                return;
            }
            if (gmUsages.get(c.getPlayer().getId()) != null) {
                long lastUse = gmUsages.get(c.getPlayer().getId());
                if (System.currentTimeMillis() - lastUse < 60 * 1000 * 2) {
                    mc.dropMessage("Voc� s� pode enviar mensagens para GM de 2 em 2 minutos.");
                    return;
                } else {
                    mc.dropMessage("Enviando mensagem ..");
                    FilePrinter.printGM("SuporteGMs.rtf", "Mensagem que foi enviada: " + StringUtil.joinStringFrom(splitted, 1) + "\r\nNo dia: " + sdf.format(Calendar.getInstance().getTime()) + " as " + sdf2.format(Calendar.getInstance().getTime()) + ".\r\nSolicitante: " + player.getName() + " (" + player.getAccountID() + ")");
                    c.getChannelServer().getWorldInterface().broadcastGMMessage(null, MaplePacketCreator.serverNotice(5, "[" + c.getPlayer().getName() + "] " + StringUtil.joinStringFrom(splitted, 1)).getBytes());
                    gmUsages.put(c.getPlayer().getId(), System.currentTimeMillis());
                    mc.dropMessage("Feito, aguarde uma resposta.");
                }
            } else {
                mc.dropMessage("Enviando mensagem ..");
                c.getChannelServer().broadcastGMPacket(MaplePacketCreator.serverNotice(5, "[" + c.getPlayer().getName() + " - GM Mensagem] " + StringUtil.joinStringFrom(splitted, 1)));
                gmUsages.put(c.getPlayer().getId(), System.currentTimeMillis());
                mc.dropMessage("Feito, aguarde uma resposta.");
            }
        }  if (splitted[0].equalsIgnoreCase("@grupoquest")) {
            if (questUsages.get(c.getPlayer().getId()) != null) {
                long lastUse = questUsages.get(c.getPlayer().getId());
                if (System.currentTimeMillis() - lastUse < 60 * 1000 * 10) {
                    mc.dropMessage("Voc� s� pode solicitar grupos de 10 em 10 minutos.");
                    return;
                } if(player.getLevel() > 70) {
                    mc.dropMessage("Voc� n�o pode enviar est� mensagem.");
                    return;
                } else {
                    mc.dropMessage("Enviada, aguarde!");
                    player.MensagemQuest(player);
                    questUsages.put(c.getPlayer().getId(), System.currentTimeMillis());
                }
            } else {
                 mc.dropMessage("Enviada, aguarde!");
                 player.MensagemQuest(player);
                questUsages.put(c.getPlayer().getId(), System.currentTimeMillis());
            }
        } if (splitted[0].equalsIgnoreCase("@bugs")) {
                  if (splitted.length == 1) {
                         mc.dropMessage("Tipo: @bug <relato>");
                          return;
                    }
                    FilePrinter.printBug("Bugs.rtf", "Bug relatado: " + StringUtil.joinStringFrom(splitted, 1) + "\r\nNo dia: " + sdf.format(Calendar.getInstance().getTime()) + " as " + sdf2.format(Calendar.getInstance().getTime()) + ".\r\nJogador: " + player.getName() + " (" + player.getAccountID() + ")");
                    mc.dropMessage("Enviando seu relat�rio...");
          } else if (splitted[0].equalsIgnoreCase("@comandos") || splitted[0].equalsIgnoreCase("!comandos")) {
            mc.dropMessage(" - " + Mensagens.Nome_Server + " v.62 -");
            for (CommandDefinition cd : getDefinition()) {
                if (!cd.getCommand().equalsIgnoreCase("ajuda")) {
                    mc.dropMessage("@" + cd.getCommand() + " - " + cd.getHelp());
                }
            }
        } else if (splitted[0].equalsIgnoreCase("@dispose")) {
                NPCScriptManager.getInstance().dispose(c);
                c.getSession().write(MaplePacketCreator.enableActions());
                mc.dropMessage("Feito!");
        } else if (splitted[0].equalsIgnoreCase("@grupofix")) {
                    if (player.getMap().inPQ() || player.getMap().isCPQMap() || player.getMap().isRichieMapa()) {
                    mc.dropMessage("Voc� nao pode usar este comando aqui!");
                    return;
                    }
                    player.setParty(null);
                    player.silentPartyUpdate();
                    player.dropMessage("Por favor, recriar o grupo.");
         } else if (splitted[0].equals("@evento")) {
            if (player.getSavedLocation(SavedLocationType.EVENTO) > 1){
                mc.dropMessage("Voc� n�o pode usar o comando 2 vezes, use @sairevento e entre novamente!");
                return;
            } 
            if (player.getMap().inPQ() || player.getMap().isCPQMap() || player.getMap().isRichieMapa()) {
                  mc.dropMessage("Voc� nao pode usar este comando aqui!");
                 return;
            }
            if (player.getEventInstance() != null) {
                mc.dropMessage("Voc� n�o pode usar o comando enquanto est� em uma Miss�o!");
                mc.dropMessage("Saia do grupo ou miss�o e tente novamente!");
                return;
            }
            if (player.getClient().getChannelServer().eventOn == true) {
                  player.changeMap(player.getClient().getChannelServer().eventMap, 0);
                  player.saveLocation(SavedLocationType.EVENTO);   
            } else {
                mc.dropMessage("N�o h� nenhum evento no momento.");
            }
         }  else if (splitted[0].equals("@sairevento")) {
            if (player.getSavedLocation(SavedLocationType.EVENTO) > 0) {
                    player.changeMap(player.getSavedLocation(SavedLocationType.EVENTO), 0);
                    player.clearSavedLocation(SavedLocationType.EVENTO);
            } else {
                c.getPlayer().dropMessage("N�o h� eventos ativos neste momento ou n�o existe mapa salvo. Por favor, tente novamente mais tarde!");
            }
        }  else if (splitted[0].equals("@monstrohp") || splitted[0].equals("bosshp") || splitted[0].equals("mobhp")) {
            List<MapleMapObject> monsters = player.getMap().getMapObjectsInRange(c.getPlayer().getPosition(), Double.POSITIVE_INFINITY, Arrays.asList(MapleMapObjectType.MONSTER));
            for (MapleMapObject curmob : monsters) {
            MapleMonster monster = (MapleMonster) curmob;
            player.dropMessage("Nome: " + monster.getName() + " - HP: " + Integer.toString(monster.getHp()) + "/" + Integer.toString(monster.getMaxHp()) + "."); // manda uma mensagem com nome, HP atual e maximo.
            }
           }
//         
//         else if (splitted[0].equals("@balrogpq")) {
//            if (player.getMap().inPQ() || player.getMap().isCPQMap() || player.getMap().isRichieMapa()) {
//                  mc.dropMessage("Voc� nao pode usar este comando aqui!");
//                 return;
//            }
//            if (player.getSavedLocation(SavedLocationType.BALROGPQ) > 1){
//                mc.dropMessage("Voc� n�o pode usar o comando 2 vezes, use @sairbalrogpq e entre novamente!");
//                return;
//            } if (player.getLevel() >= 70) {  
//                player.changeMap(105100100, 0);
//                player.saveLocation(SavedLocationType.BALROGPQ);
//            } else {
//                c.getPlayer().dropMessage("E necess�rio ter n�vel 70 ou acima para entrar!");
//            }
//         } else if (splitted[0].equals("@sairbalrogpq")) {
//            if (player.getSavedLocation(SavedLocationType.BALROGPQ) > 0) {
//                    player.changeMap(player.getSavedLocation(SavedLocationType.BALROGPQ), 0);
//                    player.clearSavedLocation(SavedLocationType.BALROGPQ);
//            } else {
//                c.getPlayer().dropMessage("N�o h� mapas salvos, tente novamente mais tarde!");
//            }
//        } 
        
        else if (splitted[0].equalsIgnoreCase("@leaderpoints")) { 
                    if (player.getCSPoints(2) > 0) {
                    player.dropMessage(".:: LeaderPoints ::.");
                    player.dropMessage("Voc� tem atualmente: " + player.getCSPoints(2) + " JS-Point(s)");
                    } else {
                    player.dropMessage("Voc� n�o tem JS-Points.");
                    player.dropMessage("Acesse " + Mensagens.Site_Server + " e saiba como obter!");
                 }

        
        } else if (splitted[0].equalsIgnoreCase("@pontos")) {
             c.getPlayer().dropMessage(".:: Pontos atuais ::.");
             c.getPlayer().dropMessage("-------------------------");  
             if(player.getCSPoints(5) > 0) {     
             c.getPlayer().dropMessage("VotePoints: " + player.getCSPoints(5));
             } else {
              player.dropMessage("Voc� n�o tem VotePoints.");
              player.dropMessage("Acesse " + Mensagens.Site_Server + " e saiba como obter!");    
             } 
             c.getPlayer().dropMessage("-------------------------");     
             if(player.getBossPoints() > 0) {    
             c.getPlayer().dropMessage("BossPoints: " + c.getPlayer().getBossPoints());
             } else {
              player.dropMessage("Voc� n�o tem BossPoints.");
              player.dropMessage("V� at� Omega e complete a miss�o.");      
             }
             c.getPlayer().dropMessage("-------------------------");     
             if (player.getCSPoints(2) > 0) {
               c.getPlayer().dropMessage("LeaderPoints: " + player.getCSPoints(2)); 
             } else {
               player.dropMessage("Voc� n�o tem LeaderPoints.");
               player.dropMessage("Acesse " + Mensagens.Site_Server + " e saiba como obter!");      
            } 
             c.getPlayer().dropMessage("-------------------------");     
             player.dropMessage("PaypalNX: " + player.getCSPoints(1) + " / CardNX: " + player.getCSPoints(4));     
          } else if (splitted[0].equalsIgnoreCase("@aondedropa")) {
			if (splitted.length < 2) {
				mc.dropMessage("@aondedropa <itemid>");
			} else {
				try {
					int searchid = Integer.parseInt(splitted[1]);
					List<String> retMobs = new ArrayList<String>();
					MapleData data = null;
					MapleDataProvider dataProvider = MapleDataProviderFactory.getDataProvider(new File(System.getProperty("wzpath") + "/" + "String.wz"));
					data = dataProvider.getData("Mob.img");
					mc.dropMessage("Item " + searchid + " � dropado pelo seguintes monstros:");
					List<Pair<Integer,String>> mobPairList = new LinkedList<Pair<Integer,String>>();
					Connection con = DatabaseConnection.getConnection();
					PreparedStatement ps = con.prepareStatement("SELECT monsterid FROM monsterdrops WHERE itemid = ?");
					ps.setInt(1, searchid);
					ResultSet rs = ps.executeQuery();
					while (rs.next()) {
						int mobn = rs.getInt("monsterid");
						for (MapleData mobIdData : data.getChildren()) {
							int mobIdFromData = Integer.parseInt(mobIdData.getName());
							String mobNameFromData = MapleDataTool.getString(mobIdData.getChildByPath("name"), "NO-NAME");
							mobPairList.add(new Pair<Integer, String>(mobIdFromData, mobNameFromData));
						}
						for (Pair<Integer, String> mobPair : mobPairList) {
							if (mobPair.getLeft() == (mobn) && !retMobs.contains(mobPair.getRight())) {
								retMobs.add(mobPair.getRight());
							}
						}
					}
					rs.close();
					ps.close();
					if (retMobs != null && retMobs.size() > 0) {
						for (String singleRetMob : retMobs) {
							mc.dropMessage(singleRetMob);
						}
					} else {
						mc.dropMessage("Nenhum monstro dropa este item.");
					}
				} catch (SQLException e) {
				}
	} 
     } else if (splitted[0].equalsIgnoreCase("@smega")) {
                if (player.getMeso() >= 10000) {
                player.setSmegaEnabled(!player.getSmegaEnabled());
                String text = (!player.getSmegaEnabled() ? "[Desativando] Os smegas foram desativados." : "[Ativando] Os smegas foram ativados.");
                mc.dropMessage(text);
                player.gainMeso(-10000, true);
                } else {
                mc.dropMessage("Para desativalos/ativalos voc� precisa de 10,000 mesos.");
            }
        } 
    }
    

    public int itemQuantity(MapleClient c, int itemid) {
        MapleInventoryType type = MapleItemInformationProvider.getInstance().getInventoryType(itemid);
        MapleInventory iv = c.getPlayer().getInventory(type);
        int possesed = iv.countById(itemid);
        return possesed;
    }
    
    

    @Override
    public CommandDefinition[] getDefinition() {
        return new CommandDefinition[]{
                        new CommandDefinition("comandos", "", "Mostra lista de ajuda.", 0),
			new CommandDefinition("gm", "", "Envia mensagem a GM online.", 0),
                        new CommandDefinition("dispose", "", "N�o consegue falar com algum NPC? Use este comando.", 0),
                        new CommandDefinition("grupofix", "", "Corrige poss�vel bug na cria��o de grupos.", 0),
                        new CommandDefinition("evento", "", "Te leva para o evento em andamento.", 0),
                        new CommandDefinition("sairevento", "", "Te leva para o mapa anterior em que voc� estava.", 0),
                        new CommandDefinition("smega", "", "Este comando Ativa/Desativa smega (Taxa 1.000 Mesos).", 0),
                        new CommandDefinition("bugs", "", "Envia relat�rios de BUGS!", 0),   
                        new CommandDefinition("grupoquest", "", "Envia uma mensagem solicitando grupo p/ PQ.", 0),  
                        new CommandDefinition("pontos", "", "Mostra a quantidade de pontos dentro do jogo.", 0),
                        new CommandDefinition("monstrohp", "", "Mostra a quantidade de LeaderPoints.", 0),
                        new CommandDefinition("aondedropa", "", "@aondedropa <itemid> procura monstro que dropa o item.", 0),
                      //  new CommandDefinition("balrogpq", "", "Te leva para mapa da BalrogPQ", 0),
                      //  new CommandDefinition("sairbalrogpq", "", "Te leva para mapa anterior da BalrogPQ", 0),
		};
    }
}