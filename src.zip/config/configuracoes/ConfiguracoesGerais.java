/*
 * JavaScriptz (javascriptz@leaderms.com.br)
 * LeaderMS 2012 ▬ 2015
 * Brasil MapleStory Server
 * Configurações Gerais
 * www.leaderms.com.br
 */


package config.configuracoes;

import client.MapleInventoryType;
import config.skills.Aran;
import java.util.Arrays;
import java.util.List;
import server.maps.MapleMapObjectType;

public class ConfiguracoesGerais {
    
    public static boolean GMS = true; 
    public static boolean NATAL = false;
    public static final int WORLDS = 1;
    public static final int PARTY_EXPERIENCE_MOD = 0; 
    public static final double PQ_BONUS_EXP_MOD = 0.5;
    public static final double BONUS_EXP_MOD = 0.5;
    public static boolean BONUS_EXP_MOD_ = false;
    public static final long EVENT_END_TIMESTAMP = 1428897600000L;
    public static boolean DDOS_PROTECTION = true;
    public static String[] PROXY_IPS = {};

    public static MapleInventoryType getInventoryType(final int itemId) {
        final byte type = (byte) (itemId / 1000000);
        if (type < 1 || type > 5) {
            return MapleInventoryType.UNDEFINED;
        }
        return MapleInventoryType.getByType(type);
    }
    
     public static boolean isBeginnerJob(final int job) {
        return job == 0 || job == 1 || job == 1000 || job == 2000 || job == 2001 || job == 3000 || job == 3001 || job == 2002;
    }
     
    public static boolean isWeapon(final int itemId) {
        return itemId >= 1300000 && itemId < 1533000;
    }
         
    public static boolean isRechargable(int itemId) {
        return itemId / 10000 == 233 || itemId / 10000 == 207;
    }
    
    public static boolean isFinisherSkill(int skillId) {
        return skillId > 1111002 && skillId < 1111007 || skillId == 11111002 || skillId == 11111003;
    }
    
    public static final boolean isThrowingStar(int itemId) {
        return itemId / 10000 == 207;
    }
    
       public static boolean isPet(int itemId) {
        return itemId / 10000 == 500;
    }

    public static final boolean isBullet(int itemId) {
        return itemId / 10000 == 233;
    }
        
     public static boolean isForceRespawn(int mapid) {
        switch (mapid) {
            case 103000800:
            case 925100100: 
                return true;
            default:
                return mapid / 100000 == 9800 && (mapid % 10 == 1 || mapid % 1000 == 100);
        }
    }

     public static final int maxViewRangeSq() {
	return 800000;
    }
     
    public static final List<MapleMapObjectType> rangedMapobjectTypes = Arrays.asList(
	    MapleMapObjectType.ITEM,
	    MapleMapObjectType.MONSTER,
	    MapleMapObjectType.DOOR,
	    MapleMapObjectType.REACTOR,
	    MapleMapObjectType.SUMMON,
	    MapleMapObjectType.NPC,
	    MapleMapObjectType.MIST); 
     
   public static boolean isHiddenSkills(final int skill) {
    	return Aran.HIDDEN_FULL_DOUBLE == skill || Aran.HIDDEN_FULL_TRIPLE == skill || Aran.HIDDEN_OVER_DOUBLE == skill || Aran.HIDDEN_OVER_TRIPLE == skill;
    }
     
}
