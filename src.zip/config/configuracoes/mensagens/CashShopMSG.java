/*
 * JavaScriptz (javascriptz@jsmaple.com.br)
 * JS Maple ▬ 2015
 * Brasil MapleStory Server
 * Configurações Gerais CashShop
 * www.jsmaple.com.br
 */


package config.configuracoes.mensagens;

public class CashShopMSG {

    public static int[] BLOQUEADO_CS = new int[]{
        1812006,
        1812007,
        5230000,
      ///  5220000,
        5400000, 
        5211048,
        5360042,
        5401000,
        5430000,
        5140000,
        5140001,
        5140002,
        5140003,
        5140004,
        1912004,
        1902009,
        1912003,
        1902008,
        5140006,
        5370000,
        5370001,
        5281000
            
    };
    
   public static final String BLOQUEADO_CS_ = "Este item esta bloqueado do CashShop!"; 
   public static final String NAO_POSSUI_NX = "Voce nao possui NX!";
   public static final String INV_CHEIO = "Seu inventario esta cheio, verifique!";
   public static final String PRESENTE_ENVIADO = "Presente enviado com sucesso!";
   public static final String NAO_ESTA_CANAL = "Nao se encontra no mesmo canal.";
   public static final String ANIVERSARIO_INCORRETO = "Aniversario esta incorreto!";
   public static final String COMPRA_COM_MESOS = "Voce nao pode comprar itens com 0 mesos!";
   public static final String JA_POSSUI_ANEL = "Voce ja tem um anel com outra pessoa!";
   public static final String PARCEIRO_NAO_ENCONTRADO = "O parceiro especificado nao pode ser encontrado.\r\nPor favor, verifique se o seu parceiro esta on-line e no mesmo canal.";
   public static final String PARCEIRO_ENCONTRADO = "Criado com sucesso um anel para voce e seu parceiro!\r\nSe voce nao pode ver o efeito, tente relogar.";
   public static final String INDISPONIVEL_PRESENTE = "Este item nao esta disponivel para presentear.";
   public static final String COMPRA_JSPOINTS = "Compra somente com LeaderPoints!";
   public static final String ITEM_NAO_EXISTE = "Comprando item que nao existe CS!";
   public static final String DONOR_PRESENTE = "Nao e possivel presentear com Donor.";
}