/*
 * JavaScriptz (javascriptz@leaderms.com.br)
 * JS Maple -- 2015
 * Brasil MapleStory Server
 * Mensagens
 * www.leaderms.com.br
 */


package config.configuracoes.mensagens;

public class Mensagens {
    
       /*    Mensagens     */
    public static final short Leader_versao = 62;
    public static String Nome_Server = "LeaderMS";
    public static String Site_Server = "www.leaderms.com.br";
    /*   Jogandor login     */
    public static final String Jogador_Logado = "Bem-vindo novamente, n�o se esque�a de votar em nosso servidor (#r#e" + Nome_Server +"#k#n).";
    public static final String Jogador_Iniciante = "Ol� iniciante, use o comando @comandos e tenha um bom jogo.";
    public static final String Jogador_Evento = "est� havendo um evento neste momento, use @evento e participe!";
    public static final String Jogador_Evento_EMD = "houve uma altera��o nas taxas <";
    public static final String Jogador_Buffado = "<Voce foi buffado pelo " + Nome_Server + "Bot>";
    public static final String Novo_Jogador = "acabou de se juntar ao nosso servidor!";
    /*     JSPoints      */
    public static int JSPoints_1 = 1;
    public static int JSPoints_2 = 2;
    public static int JSPoints_3 = 3;
    /* Sistema Donor */
    public static final String DonorTip_ = "Dicas";
    public static final String[] DonorTip = {
     "Seja bem-vindo ao melhor servidor privado do Brasil!", "Qualquer bug ou erro reportar em nossa comunidade.", 
     "Nostalgia no ar, eventos diarios participe!", "Sabe como melhorar nosso jogo? Deixe sua sugestao em nossa comunidade!"};    
}