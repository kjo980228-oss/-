/*
 * JavaScriptz (javascriptz@leaderms.com.br)
 * JS Maple 2015
 * Brasil MapleStory Server
 * Console
 * www.leaderms.com.br
 */


package config.configuracoes.mensagens;

import static net.login.LoginServer.PORT;
import org.fusesource.jansi.AnsiConsole;

public class ShowConsole {
    
      /* Cores */
        public static final String BLACK = "\u001B[0;30m";
        public static final String RED = "\u001B[0;31m";
        public static final String GREEN = "\u001B[0;32m";
        public static final String YELLOW = "\u001B[0;33m";
        public static final String BLUE = "\u001B[0;34m";
        public static final String MAGENTA = "\u001B[0;35m";
        public static final String CYAN = "\u001B[0;36m";
        public static final String WHITE = "\u001B[0;37m";
        public static final String defaultColorCh = "" + WHITE + "[INFO]" + YELLOW + "[CANAL]" + WHITE + "";
        public static final String defaultColorLgStart = "" + WHITE + "[INFO]" + YELLOW + "[LOGIN]" + WHITE + " Servidor aberto na porta (" + PORT + ").";
        public static final String defaultPacket = "" + WHITE + "[INFO]" + RED + "[PACKET]" + WHITE + " ";
        public static final String defaultDB = "" + WHITE + "[INFO]" + RED + "[DB]" + WHITE + " ";
        public static final String defaultErro = "" + WHITE + "[INFO]" + RED + "[ERRO]" + WHITE + " ";

   public static void ShowConsole () {
        AnsiConsole.out.print(WHITE + "############################ LeaderMS foi iniciado #############################");
        AnsiConsole.out.print(WHITE + "################################################################################");
        AnsiConsole.out.print(WHITE + "#                               " + RED + "Adm - JavaScriptz" + WHITE + "                              #");
        AnsiConsole.out.print(WHITE + "#                                " + RED + "LeaderMS.com.br" + WHITE + "                               #");
        AnsiConsole.out.print(WHITE + "################################################################################");
        AnsiConsole.out.print(WHITE + "##########################" + GREEN + " Carregando informacoes..." + WHITE + " ###########################");
        AnsiConsole.out.print(WHITE + "################################################################################");
   }  
   
   public static void FullyStartedConsole () {
        AnsiConsole.out.println(WHITE + "##################### " + GREEN + "Informacoes carregadas com sucesso" + WHITE + " #######################");
   }
}