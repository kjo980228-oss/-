/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package config.jogo;

import java.lang.StringBuilder;
import tools.MaplePacketCreator;
import client.MapleCharacter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import tools.FilePrinter;

/**
 *
 * @author FateJiki
 */
public class WordFilter {
        private static final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        private static final SimpleDateFormat sdf2 = new SimpleDateFormat("HH:mm");
        private final static String[] blocked = {""};
        public final static String[] blockedSites = {"dupe", "dupar", "duplicar", "dupey", "dupei", "dupliquei", "roubar", "roubei", "hacker", "hack", "rak", "raker", "rake", "cheater", "cheatengine", "cheat", "injetor", "dll", "Ganja", "trainer", "timbuspe", "timbus", "blitz", "cheatsbrasil", "webcheats", "packet", "packets", "boot", "autopot", "mula", "ddos"};

        public static String illegalArrayCheck(String text, MapleCharacter player){
            StringBuilder sb = new StringBuilder(text);
            String subString = text.toLowerCase();
            if(!containsWebsite(text, player)){
            for(int i = 0; i < blocked.length; i++){
                if(subString.contains(blocked[i].toLowerCase())){
                    
                }
              }
            }
            return text;
        }

        public static boolean containsWebsite(String text, MapleCharacter player){
            boolean yes = false;
            String subString = text.toLowerCase();
            for(int i = 0; i < blockedSites.length; i++){
                if(subString.contains(blockedSites[i].toLowerCase())){
                    yes = true;
                }
            }
            if(yes){
             player.getClient().getChannelServer().broadcastGMPacket(MaplePacketCreator.serverNotice(0, "[Aten��o GM] O player " + player.getName() + " pode estar com algo malicioso no servidor."));
                player.getClient().getChannelServer().broadcastGMPacket(MaplePacketCreator.serverNotice(0, "Acabou de usar o dialogo : " + subString.toString()));
                FilePrinter.printFilter(player.getName() + ".txt", player.getName() + " usou o texto: " + subString.toString() + "\r\nMapa: " + player.getMapId() + " || Nome: " + player.getMapName(player.getMapId()) + "\r\nLevel: " + player.getLevel() + " || Guild: " + player.getGuild().getName() + " || Mesos: " + player.getMeso() + "\r\nNo dia: " + sdf.format(Calendar.getInstance().getTime()) + " as " + sdf2.format(Calendar.getInstance().getTime()) + ".");
            }
            return true;
        }

}