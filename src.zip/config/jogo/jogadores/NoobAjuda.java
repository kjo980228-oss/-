/*
 * JavaScriptz (javascriptz@leaderms.com.br)
 * LeaderMS 2012 -- 2015
 * Brasil MapleStory Server
 * Ajuda p/ Iniciantes
 * www.leaderms.com.br
 */

package config.jogo.jogadores;

import client.MapleClient;
import config.configuracoes.mensagens.Mensagens;


public class NoobAjuda {
    
    /* Variaveis */
    private MapleClient client;
    /* Fim */
    
        public MapleClient getClient() {
        return client;
    }
    
    public static String Nivel = "Ol� #e#h ##n,\r\n" +
         "Pe�o para que leia atentamente est� mensagem!\r\n" +
         "Venho lembrar sobre os avan�os de Classes no " + Mensagens.Nome_Server + ", no servidor para avan�o de classe necess�rio seguir a tabela abaixo.\r\n" +
         "Esta mensagem mostra quais pontos devem ser destribuidos, para que, possa escolher a classe correta.\r\n\r\n" +
         "#eBruxo#n\r\nN�vel - 08\r\nInteligencia - 20\r\n\r\n" +
         "#eArqueiro#n\r\nN�vel - 10\r\nDestreza - 25\r\n\r\n" +
         "#eGatuno#n\r\nN�vel - 10\r\nDestreza - 25\r\n\r\n" +
         "#eGuerreiro#n\r\nN�vel - 10\r\nForca - 35\r\n\r\n" +
         "#ePirata#n\r\nN�vel - 10\r\nDestreza - 20\r\n\r\n" +
         "Lembrando que estes requisitos s�o obrigat�rios, o " + Mensagens.Nome_Server + " pede desculpa por qualquer inconveniente e agradece.\r\nUse @comandos para demais duvidas, bom jogo!";
   
   public static String MensagemQuest = "[Pedido de Grupo]";
   public static String MensagemAlerta_Nivel_10_30 = " diz: Preciso de grupo para <HPQ/KPQ/APQ>.";
   public static String MensagemAlerta_Nivel_30_50 = " diz: Preciso de grupo para <CPQ/LPQ>.";
   public static String MensagemAlerta_Nivel_50_70 = " diz: Preciso de grupo para <OPQ/PiratePQ>.";
   

}


