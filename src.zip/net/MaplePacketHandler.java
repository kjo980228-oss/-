package net;

import client.MapleClient;
import tools.data.LittleEndianAccessor;

public interface MaplePacketHandler {
	void handlePacket(LittleEndianAccessor slea, MapleClient c);
	boolean validateState(MapleClient c);
}
