package net;

import client.MapleClient;
import config.configuracoes.ConfiguracoesGerais;
import java.io.IOException;
import java.util.Random;
import net.channel.ChannelServer;
import net.login.LoginWorker;
import tools.MapleAESOFB;
import tools.MaplePacketCreator;
import tools.data.input.ByteArrayByteStream;
import org.apache.mina.common.IdleStatus;
import org.apache.mina.common.IoHandlerAdapter;
import org.apache.mina.common.IoSession;
import tools.FilePrinter;
import tools.data.LittleEndianAccessor;

public class MapleServerHandler extends IoHandlerAdapter {
    private final static short MAPLE_VERSION = 62;
    private PacketProcessor processor;
    private int channel = -1;
    private boolean trace = false;
    public static boolean launcher = false;
    public String laun;

    public MapleServerHandler(PacketProcessor processor) {
        this.processor = processor;
    }

    public MapleServerHandler(PacketProcessor processor, int channel) {
        this.processor = processor;
        this.channel = channel;
    }

    @Override
    public void messageSent(IoSession session, Object message) throws Exception {
        Runnable r = ((MaplePacket) message).getOnSend();
        if (r != null)
            r.run();
        super.messageSent(session, message);
    }

    @Override
    public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
        if (cause instanceof IOException || cause instanceof ClassCastException) {
            return;
        }
        MapleClient mc = (MapleClient) session.getAttribute(MapleClient.CLIENT_KEY);
        if (mc != null && mc.getPlayer() != null) {
            FilePrinter.printError(FilePrinter.EXCEPTION_CAUGHT, cause, "Excecao causada por: " + mc.getPlayer());
        }
    }

    @Override
    public void sessionOpened(IoSession session) throws Exception {
       if (channel > -1) {
	    if (ChannelServer.getInstance(channel).isShutdown() || ChannelServer.getInstance(channel) == null) {
		session.close();
		return;
	    }
	} if (ConfiguracoesGerais.DDOS_PROTECTION) {
	    for (String proxy : ConfiguracoesGerais.PROXY_IPS) {
		if (!session.getRemoteAddress().toString().contains(proxy)) {
		    System.out.println("IP nao identificado tentando ir GameServer - " + session.getRemoteAddress());
		    session.close();
		    return;
		}
	    }
	}
        byte key[] = {0x13, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x06, 0x00, 0x00, 0x00, (byte) 0xB4, 0x00, 0x00, 0x00, 0x1B, 0x00, 0x00, 0x00, 0x0F, 0x00, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x52, 0x00, 0x00, 0x00};
        byte ivRecv[] = {70, 114, 122, 82};
        byte ivSend[] = {82, 48, 120, 115};
        ivRecv[3] = (byte) (Math.random() * 255);
        ivSend[3] = (byte) (Math.random() * 255);
        MapleAESOFB sendCypher = new MapleAESOFB(key, ivSend, (short) (0xFFFF - MAPLE_VERSION));
        MapleAESOFB recvCypher = new MapleAESOFB(key, ivRecv, MAPLE_VERSION);
        MapleClient client = new MapleClient(sendCypher, recvCypher, session);
        client.setChannel(channel);
        session.write(MaplePacketCreator.getHello(MAPLE_VERSION, ivSend, ivRecv, false));
        Random r = new Random();
        client.setSessionId(r.nextLong()); // Generates a random session id.  
        session.setAttribute(MapleClient.CLIENT_KEY, client);
        session.setIdleTime(IdleStatus.READER_IDLE, 30);
        session.setIdleTime(IdleStatus.WRITER_IDLE, 30);
        FilePrinter.printIP("ListaIP.txt", "IP: " + session.getRemoteAddress());
    }
    
      @Override
    public void sessionClosed(final IoSession session) throws Exception {
	final MapleClient client = (MapleClient) session.getAttribute(MapleClient.CLIENT_KEY);
	if (client != null) {
	    try {
//                if(!client.getPlayer().LauncherOk()) {
//                   client.getPlayer().LauncherSair();
//                }
		client.disconnect(true);
	    } finally {
		session.close();
                LoginWorker.getInstance().deregisterClient(client);
		session.removeAttribute(MapleClient.CLIENT_KEY);
	    }
	}
	super.sessionClosed(session);
    }

    @Override
    public void messageReceived(IoSession session, Object message) throws Exception {
        byte[] content = (byte[]) message;
        LittleEndianAccessor slea = new LittleEndianAccessor(new ByteArrayByteStream(content));
        short packetId = slea.readShort();
        MapleClient client = (MapleClient) session.getAttribute(MapleClient.CLIENT_KEY);
        MaplePacketHandler packetHandler = processor.getHandler(packetId);
        if (packetHandler != null && packetHandler.validateState(client))
            try {
                if (trace) {
                    @SuppressWarnings("unused")
                    String from = "";
                    if (client.getPlayer() != null)
                        from = "from " + client.getPlayer().getName() + " ";
                }
                packetHandler.handlePacket(slea, client);
            } catch (Throwable t) {
            }
    }

    @Override
    public void sessionIdle(final IoSession session, final IdleStatus status) throws Exception {
        MapleClient client = (MapleClient) session.getAttribute(MapleClient.CLIENT_KEY);
        if (client != null)
            client.sendPing();
        super.sessionIdle(session, status);
    }
}
