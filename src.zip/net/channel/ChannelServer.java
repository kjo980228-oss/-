/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package net.channel;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.management.InstanceAlreadyExistsException;
import javax.management.MBeanRegistrationException;
import javax.management.MalformedObjectNameException;
import javax.management.NotCompliantMBeanException;
import javax.rmi.ssl.SslRMIClientSocketFactory;
import client.MapleCharacter;
import client.MapleClient;
import client.SkillFactory;
import static config.configuracoes.mensagens.ShowConsole.FullyStartedConsole;
import static config.configuracoes.mensagens.ShowConsole.ShowConsole;
import static config.configuracoes.mensagens.ShowConsole.defaultColorCh;
import database.DatabaseConnection;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import net.MaplePacket;
import net.MapleServerHandler;
import net.PacketProcessor;
import net.channel.remote.ChannelWorldInterface;
import net.mina.MapleCodecFactory;
import net.world.MapleParty;
import net.world.MaplePartyCharacter;
import net.world.guild.MapleGuild;
import net.world.guild.MapleGuildCharacter;
import net.world.guild.MapleGuildSummary;
import net.world.remote.WorldChannelInterface;
import net.world.remote.WorldRegistry;
import provider.MapleDataProviderFactory;
import scripting.event.EventScriptManager;
import server.MapleSquad;
import server.MapleSquadType;
import server.PlayerInteraction.HiredMerchant;
import server.ShutdownServer;
import server.maps.MapleMap;
import server.maps.MapleMapFactory;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import server.market.MarketEngine;
import tools.MaplePacketCreator;
import org.apache.mina.common.ByteBuffer;
import org.apache.mina.common.CloseFuture;
import org.apache.mina.common.IoAcceptor;
import org.apache.mina.common.SimpleByteBufferAllocator;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.SocketAcceptor;
import org.apache.mina.transport.socket.nio.SocketAcceptorConfig;
import org.fusesource.jansi.AnsiConsole;
import server.AutobanManager;
import server.MapleItemInformationProvider;
import server.MapleTrade;
import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
import server.CashItemFactory;
import server.MapleTimer;
import server.MapleTimer.AntiCheatTimer;
import server.MapleTimer.CharacterTimer;
import server.MapleTimer.ClientTimer;
import server.MapleTimer.EventTimer;
import server.MapleTimer.ItemTimer;
import server.MapleTimer.MapTimer;
import server.MapleTimer.MiscTimer;
import server.MapleTimer.MonsterTimer;
import server.MapleTimer.MountTimer;
import server.MapleTimer.NPCTimer;
import server.MapleTimer.SkillTimer;
import server.MapleTimer.WLCTimer;
import server.eventos.RoletaRussa;
import server.eventsnotscript.AutoMensagem;
import server.eventsnotscript.AutoMensagemAprendiz;
import server.eventsnotscript.Barcos;
import server.eventsnotscript.Cabine;
import server.eventsnotscript.Elevador;
import server.eventsnotscript.Genio;
import server.eventsnotscript.Trens;
import server.quest.MapleQuest;
import tools.FilePrinter;


public class ChannelServer implements Runnable, ChannelServerMBean {
        MapleClient c;
	private static int uniqueID = 1;
	private int port = 7575;
	private static Properties initialProp;
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ChannelServer.class);
	private static WorldRegistry worldRegistry;
	private PlayerStorage players = new PlayerStorage();
	private String serverMessage;
	private int expRate;
	private int mesoRate;
	private int dropRate;
	private int bossdropRate;
        private boolean MT;
	private int petExpRate;
        public boolean eventOn = false;
        public boolean doublecash = false;
        public int eventMap = 0;
        private int maxStat;
        private int mountExpRate;
        private int QuestExpRate;
	private boolean gmWhiteText;
	private boolean cashshop;
	private boolean mts;
	private boolean dropUndroppables;
	private boolean moreThanOne;
	private int channel;
        private int instanceId = 0;
        private boolean GMItems;
	private String key;
        private boolean AB;
	private Properties props = new Properties();
	private ChannelWorldInterface cwi;
	private WorldChannelInterface wci = null;
	private IoAcceptor acceptor;
	private String ip;
        private int ano, dia, hora, segundos, minutos;
	private boolean shutdown = false;
	private boolean finishedShutdown = false;
	private String arrayString = "";
	private MapleMapFactory mapFactory;
	private MapleMapFactory gmMapFactory;
	private EventScriptManager eventSM;
        private Barcos barcosnot;
        private static Map<Integer, ChannelServer> instances = new HashMap<Integer, ChannelServer>();
        private static Map<String, ChannelServer> pendingInstances = new HashMap<String, ChannelServer>();
	private Map<Integer, MapleGuildSummary> gsStore = new HashMap<Integer, MapleGuildSummary>();
	
	private Boolean worldReady = true;
        private final Map<Integer, HiredMerchant> merchants = new HashMap<Integer, HiredMerchant>();
        private final Lock merchant_mutex = new ReentrantLock();
	
	private Map<MapleSquadType, MapleSquad> mapleSquads = new HashMap<MapleSquadType, MapleSquad>();
	private MarketEngine me = new MarketEngine();
	private long lordLastUpdate = 0;
	private int lordId = 0;

        private ChannelServer(String key) {
		mapFactory = new MapleMapFactory(MapleDataProviderFactory.getDataProvider(new File(System.getProperty("wzpath") + "/Map.wz")), MapleDataProviderFactory.getDataProvider(new File(System.getProperty("wzpath") + "/String.wz")));
                this.key = key;
	}
	
	public static WorldRegistry getWorldRegistry() {
		return worldRegistry;
	}
	
	public void reconnectWorld() {
        try {
            wci.isAvailable();
        } catch (RemoteException ex) {
            synchronized (worldReady) {
                worldReady = false;
            }
            synchronized (cwi) {
                synchronized (worldReady) {
                    if (worldReady)
                        return;
                }
                System.out.println("Reconnecting to world server");
                synchronized (wci) {
                    try {
						initialProp = new Properties();
						FileReader fr = new FileReader(System.getProperty("channel.config"));
						initialProp.load(fr);
						fr.close();
						Registry registry = LocateRegistry.getRegistry(initialProp.getProperty("world.host"), Registry.REGISTRY_PORT, new SslRMIClientSocketFactory());
						worldRegistry = (WorldRegistry) registry.lookup("WorldRegistry");
						cwi = new ChannelWorldInterfaceImpl(this);
						wci = worldRegistry.registerChannelServer(key, cwi);
						props = wci.getGameProperties();
                                                expRate = Integer.parseInt(props.getProperty("world.exp"));
                                                QuestExpRate = Integer.parseInt(props.getProperty("world.questExp"));
                                                mesoRate = Integer.parseInt(props.getProperty("world.meso"));
                                                dropRate = Integer.parseInt(props.getProperty("world.drop"));
						bossdropRate = Integer.parseInt(props.getProperty("world.bossdrop"));
						petExpRate = Integer.parseInt(props.getProperty("world.petExp"));
                                                mountExpRate = Integer.parseInt(props.getProperty("world.mountExp"));
						serverMessage = props.getProperty("world.serverMessage");
						dropUndroppables = Boolean.parseBoolean(props.getProperty("world.alldrop", "false"));
						moreThanOne = Boolean.parseBoolean(props.getProperty("world.morethanone", "false"));
						gmWhiteText = Boolean.parseBoolean(props.getProperty("world.gmWhiteText", "true"));
						cashshop = Boolean.parseBoolean(props.getProperty("world.cashshop", "false"));
						mts = Boolean.parseBoolean(props.getProperty("world.mts", "false"));
                                                DatabaseConnection.getConnection();
                                                wci.serverReady();
                    } catch (Exception e) {
                        System.out.println("Reconnecting failed " + e);
                    }
                    worldReady = true;
                }
            }
            synchronized (worldReady) {
                worldReady.notifyAll();
            }
        }
    }

                        @Override
                        public void run() {
                        try {
                        cwi = new ChannelWorldInterfaceImpl(this);
                        wci = worldRegistry.registerChannelServer(key, cwi);
                        props = wci.getGameProperties();
	 		expRate = Integer.parseInt(props.getProperty("world.exp"));
                        QuestExpRate = Integer.parseInt(props.getProperty("world.questExp"));
			mesoRate = Integer.parseInt(props.getProperty("world.meso"));
			dropRate = Integer.parseInt(props.getProperty("world.drop"));
			bossdropRate = Integer.parseInt(props.getProperty("world.bossdrop"));
			petExpRate = Integer.parseInt(props.getProperty("world.petExp"));
                        mountExpRate = Integer.parseInt(props.getProperty("world.mountExp"));
			serverMessage = props.getProperty("world.serverMessage");
			dropUndroppables = Boolean.parseBoolean(props.getProperty("world.alldrop", "false"));
			moreThanOne = Boolean.parseBoolean(props.getProperty("world.morethanone", "false"));
			eventSM = new EventScriptManager(this, props.getProperty("channel.events").split(","));
                        //eventSM = new EventScriptManager(this, getEvents());
			gmWhiteText = Boolean.parseBoolean(props.getProperty("world.gmWhiteText", "false"));
			cashshop = Boolean.parseBoolean(props.getProperty("world.cashshop", "false"));
			mts = Boolean.parseBoolean(props.getProperty("world.mts", "false"));
                        maxStat = Integer.parseInt(props.getProperty("world.maxStat"));
                        DatabaseConnection.getConnection();
                        Connection c = DatabaseConnection.getConnection();
            try {
                PreparedStatement ps = c.prepareStatement("UPDATE accounts SET loggedin = 0");
                ps.executeUpdate();
                ps = c.prepareStatement("UPDATE accounts SET launcher = 0");
                ps.executeUpdate();
                ps = c.prepareStatement("UPDATE characters SET HasMerchant = 0");
                ps.executeUpdate();
                ps.close();
            } catch (SQLException ex) {
                System.out.println("Could not reset databases " + ex);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        port = Integer.parseInt(props.getProperty("channel.net.port"));
        ip = props.getProperty("channel.net.interface") + ":" + port;
        ByteBuffer.setUseDirectBuffers(false);
        ByteBuffer.setAllocator(new SimpleByteBufferAllocator());
        acceptor = new SocketAcceptor();
        SocketAcceptorConfig cfg = new SocketAcceptorConfig();
        cfg.getFilterChain().addLast("codec", new ProtocolCodecFilter(new MapleCodecFactory()));
        final WLCTimer tMan = WLCTimer.getInstance();
        /* Console */ 
        ShowConsole();
        /* Start? */ 
        tMan.start();
        LoadTimers();
        /* Conta Unstuck */
        tMan.register(new AutoUnstucker(), 5000); 
        /* AutoBan */
        AntiCheatTimer.getInstance().register(AutobanManager.getInstance(), 600);
        /* Respawns */
        MonsterTimer.getInstance().schedule(new RespawnWorker(), 10 * 1000);
        /* Close */
        MapleItemInformationProvider.getInstance().getAllItems();
        /* Quests */
        MapleQuest.loadAllQuest();
        /* Skills */
        SkillFactory.cacheSkills();
        /* CashShop */
        CashItemFactory.getInstance();
         /* Carrega Barcos */
        LoadNotEventScripts();
        /* Tempo ServerOnline */
        Calendar cal = Calendar.getInstance();
        setOnlineServer(cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
        try {
            final MapleServerHandler serverHandler = new MapleServerHandler(PacketProcessor.getProcessor(PacketProcessor.Mode.CHANNELSERVER), channel);
            acceptor.bind(new InetSocketAddress(port), serverHandler, cfg);
            AnsiConsole.out.println(defaultColorCh + " Canal (" + getChannel() + ") Aberto na porta (" + port + ").");
            wci.serverReady();
            eventSM.init();                      
        } catch (IOException e) {
            AnsiConsole.out.println(defaultColorCh + " A ligacao na porta " + port + " falhou (ch: " + getChannel() + ")" + e);
        }
        FullyStartedConsole();
        Runtime.getRuntime().addShutdownHook(new Thread(new ShutDown()));
    }                   
   
      public final int getId() {
        return channel;
    }
      
   public void setOnlineServer(int d, int h, int m, int s) {
        this.dia = d;
        this.hora = h;
        this.minutos = m;
        this.segundos = s;          
    }
   
   public int getOnlineServerHora() {
      return this.hora;
   }
   
    public int getOnlineServerMinuto() {
       return this.minutos;
    }
   
    public int getOnlineServerSegundos() {
        return this.segundos;
    }
    
    public int getOnlineServerDias() {
        return this.dia;
    }
    
    public int getMaxStat() {
        return maxStat;
    }
    
    private void LoadNotEventScripts () {
        new AutoMensagem();
        new AutoMensagemAprendiz();
        new Barcos();
        new Cabine();
        new Elevador();
        new Genio();
        new Trens();
    }
  
    private void LoadTimers () {
        MiscTimer.getInstance().start();
        ClientTimer.getInstance().start();
        MountTimer.getInstance().start();        
        MonsterTimer.getInstance().start(); 
        ItemTimer.getInstance().start();
        MapTimer.getInstance().start();
        EventTimer.getInstance().start();
        AntiCheatTimer.getInstance().start();
        NPCTimer.getInstance().start();
        CharacterTimer.getInstance().start();
        SkillTimer.getInstance().start(); 
    }  
      
      
    private static String [] getEvents(){
    	List<String> events = new ArrayList<String>();
    	for (File file : new File("scripts/event").listFiles()){
    		events.add(file.getName().substring(0, file.getName().length() - 3));
    	}
    	return events.toArray(new String[0]);
    }
      
    
                
       public List<MapleCharacter> getPartyMembers(MapleParty party) {
        List<MapleCharacter> partym = new ArrayList<>(8);
        for (MaplePartyCharacter partychar : party.getMembers()) {
            if (partychar.getChannel() == getId()) {
                MapleCharacter chr = getPlayerStorage().getCharacterByName(partychar.getName());
                if (chr != null) {
                    partym.add(chr);
                }
            }
        }
        return partym;


    }
       
    public boolean isConnected(String name) {
        return getPlayerStorage().getCharacterByName(name) != null;
    }   
       
    private class RespawnWorker implements Runnable {
        @Override
	public void run() {
	    try {
            Collection<ChannelServer> cservs = ChannelServer.getAllInstances();
	    for (ChannelServer cs : cservs) {
		if (cs.getConnectedClients() == 0) {
		    continue;
		}
		cs.getMapLock().lock();
		try {
		    for (Entry<Integer, MapleMap> map : mapFactory.getMaps().entrySet()) {
			map.getValue().respawn();
		    }
		} finally {
		    cs.getMapLock().unlock();
		}
	     }
	    } catch (Exception e) {
		System.out.println("Excecao detectada mobs de desova: " + e);
                FilePrinter.printError(FilePrinter.Timer_Log, e);
	    } finally {
		MonsterTimer.getInstance().schedule(this, 10 * 1000);
	    }
	}
    }

	
       private final class ShutDown implements Runnable {

	@Override
	public void run() {
        shutdown = true;
        List<CloseFuture> futures = new LinkedList<CloseFuture>();
        Collection<MapleCharacter> allchars = players.getAllCharacters();
        MapleCharacter chrs[] = allchars.toArray(new MapleCharacter[allchars.size()]);
        for (MapleCharacter chr : chrs) {
            if (chr.getTrade() != null) {
                MapleTrade.cancelTrade(chr);
            }
            if (chr.getEventInstance() != null) {
                chr.getEventInstance().playerDisconnected(chr);
            }
            if (!chr.getClient().isGuest()) {
                chr.saveToDB(true, true);
            }
            if (chr.getCheatTracker() != null) {
                chr.getCheatTracker().dispose();
            }
            removePlayer(chr);
        }
        for (MapleCharacter chr : chrs) {
            futures.add(chr.getClient().getSession().close());
        }
        for (CloseFuture future : futures) {
            future.join(500);
        }
        finishedShutdown = true;
        wci = null;
        cwi = null;
	}
    }
       
        public void shutdown() {
        shutdown = true;
        List<CloseFuture> futures = new LinkedList<CloseFuture>();
        Collection<MapleCharacter> allchars = players.getAllCharacters();
        MapleCharacter chrs[] = allchars.toArray(new MapleCharacter[allchars.size()]);
        for (MapleCharacter chr : chrs) {
            if (chr.getTrade() != null) {
                MapleTrade.cancelTrade(chr);
            }
            if (chr.getEventInstance() != null) {
                chr.getEventInstance().playerDisconnected(chr);
            }
            if (!chr.getClient().isGuest()) {
                chr.saveToDB(true, true);
            }
            if (chr.getCheatTracker() != null) {
                chr.getCheatTracker().dispose();
            }
            removePlayer(chr);
        }
        for (MapleCharacter chr : chrs) {
            futures.add(chr.getClient().getSession().close());
        }
        for (CloseFuture future : futures) {
            future.join(500);
        }
        finishedShutdown = true;
        wci = null;
        cwi = null;
    }
         
     public final void closeAllMerchant() {
	merchant_mutex.lock();

	final Iterator<HiredMerchant> merchants_ = merchants.values().iterator();
	try {
	    while (merchants_.hasNext()) {
		merchants_.next().closeShop(true);
		merchants_.remove();
	    }
	} finally {
	    merchant_mutex.unlock();
	}
    }
     
     public class AutoLauncherUnstucker implements Runnable {
        @Override
        public void run() {
                PreparedStatement ps;
                try {
                ps = DatabaseConnection.getConnection().prepareStatement("SELECT loggedin FROM accounts");
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {    
                if (rs.getInt("loggedin") == 2) {
                } else {
                     ps = DatabaseConnection.getConnection().prepareStatement("UPDATE accounts SET launcher = 0");
                     ps.executeUpdate();
                    }
                 }
                  rs.close();
                  ps.close();
                } catch(SQLException e) {
                   System.out.println(e);
                }
                    
           }
    } 
        
    
    public void broadcastGMPacket(MaplePacket data) {
            for (MapleCharacter chr : players.getAllCharacters()) {
                if(chr.isGM())
                    chr.getClient().getSession().write(data);
            }
	}
    
    public void broadcastQuestAlerta_10_30(MaplePacket data) {
            for (MapleCharacter chr : players.getAllCharacters()) {
                if(chr.getLevel() > 9 && chr.getLevel() < 31)
                    chr.getClient().getSession().write(data);
            }
	}
    
    public void broadcastQuestAlerta_30_50(MaplePacket data) {
            for (MapleCharacter chr : players.getAllCharacters()) {
                if(chr.getLevel() > 29 && chr.getLevel() < 51)
                    chr.getClient().getSession().write(data);
            }
	}
    
    
    public void broadcastQuestAlerta_50_70(MaplePacket data) {
            for (MapleCharacter chr : players.getAllCharacters()) {
                if(chr.getLevel() > 49 && chr.getLevel() < 71)
                    chr.getClient().getSession().write(data);
            }
	}
	
	public void unbind() {
		acceptor.unbindAll();
	}
	
	public boolean hasFinishedShutdown() {
		return finishedShutdown;
	}

	public MapleMapFactory getMapFactory() {
		return mapFactory;
	}
        
        /* Preven��o */
        public class AutoUnstucker implements Runnable {
        @Override
        public void run() {
            List<String> UnstuckedPlayers = new ArrayList<String>();
            for (MapleCharacter players : getPlayerStorage().getAllCharacters()) {
               if(players.getClient().getSession().isClosing() && players != null && players.getClient().isLoggedIn() && players.getMap() != null){
                   UnstuckedPlayers.add(players.getName() + ", ");
                   players.getClient().disconnect();
               }
            }
            if(UnstuckedPlayers.size() > 0){
            AnsiConsole.out.println(defaultColorCh + "Successo ao remover (" + UnstuckedPlayers.size() + ") jogador(es).");    
           } else {
         }
       }
    }  
        

     private static ChannelServer newInstance(String key) throws InstanceAlreadyExistsException, MalformedObjectNameException {
        ChannelServer instance = new ChannelServer(key);
        pendingInstances.put(key, instance);
        return instance;
    }
    
    
    public static ChannelServer getInstance(int channel) {
        return instances.get(channel);
    }
    
   public final void addPlayer(final MapleCharacter chr) {
	players.registerPlayer(chr);
	chr.getClient().getSession().write(MaplePacketCreator.serverMessage(serverMessage));
    }

    public final PlayerStorage getPlayerStorage() {
	return players;
    }

     public final void removePlayer(final MapleCharacter chr) {
	players.deregisterPlayer(chr);
    }

    public int getConnectedClients() {
        return players.getAllCharacters().size();
    }

	
	@Override
	public String getServerMessage() {
		return serverMessage;
	}

	@Override
	public void setServerMessage(String newMessage) {
		serverMessage = newMessage;
		broadcastPacket(MaplePacketCreator.serverMessage(serverMessage));
	}

	public void broadcastPacket(MaplePacket data) {
		for (MapleCharacter chr : players.getAllCharacters()) {
			chr.getClient().getSession().write(data);
		}
	}
        

	 @Override
    public int getExpRate() {
        return expRate;
    }

    @Override
    public void setExpRate(int expRate) {
        this.expRate = expRate;
    }
	
       public String getArrayString() {
        return arrayString;
        }
        
       public void setArrayString(String newStr) {
        arrayString = newStr;
       }

	public int getChannel() {
		return channel;
	}
        
        public boolean MTtoFM() {
        return MT;
    }

    public void setChannel(int channel) {
        if (pendingInstances.containsKey(key)) {
            pendingInstances.remove(key);
        }
        if (instances.containsKey(channel)) {
            instances.remove(channel);
        }
        instances.put(channel, this);
        this.channel = channel;
        this.mapFactory.setChannel(channel);
    }

        
	public static Collection<ChannelServer> getAllInstances() {
        return Collections.unmodifiableCollection(instances.values());
    }
	
	public String getIP() {
		return ip;
	}
	
     public String getIP(int channel) {
        try {
            return getWorldInterface().getIP(channel);
        } catch (RemoteException e) {
            System.out.println("Lost connection to world server " + e);
            reconnectWorld();
            throw new RuntimeException("Lost connection to world server");
        }
    }

   public WorldChannelInterface getWorldInterface() {
        synchronized (worldReady) {
            while (!worldReady) {
                try {
                    worldReady.wait();
                } catch (InterruptedException e) {
                }
            }
        }
        return wci;
    }
        
        
     
      public void saveAll() {
        for (int i = 0; i < ChannelServer.getAllInstances().size(); i++) { 
            for (MapleCharacter character : ChannelServer.getInstance(i).getPlayerStorage().getAllCharacters()) { 
                if (character == null) continue; 
                try { 
                    character.saveToDB(true, false);
                } catch (Exception e) { 
                    character.dropMessage("You haven't been auto-saved because of an error"); 
                } 
            } 
        } 
    } 
	
	public String getProperty(String name) {
		return props.getProperty(name);
	}

	public boolean isShutdown() {
		return shutdown;
	}
        
     public static MapleCharacter getCharacterFromAllServers(int id) {
        for (ChannelServer cserv_ : ChannelServer.getAllInstances()) {
            MapleCharacter ret = cserv_.getPlayerStorage().getCharacterById(id);
            if (ret != null) {
                return ret;
            }
        }
        return null;
     }

       public static MapleCharacter getCharacterFromAllServers(String name) {
        for (ChannelServer cserv_ : ChannelServer.getAllInstances()) {
            MapleCharacter ret = cserv_.getPlayerStorage().getCharacterByName(name);
            if (ret != null) {
                return ret;
            }
        }
        return null;
      }
       
       public static MapleClient getAccountFromAllServers(int id) {
        for (ChannelServer cserv_ : ChannelServer.getAllInstances()) {
            for (MapleCharacter chr : cserv_.getPlayerStorage().getAllCharacters()) {
                if (chr.getClient().getAccID() == id) {
                    return chr.getClient();
                }
            }
        }
        return null;
    }
	
	@Override
	public void shutdown(int time) {
		broadcastPacket(MaplePacketCreator.serverNotice(0, "O servidor vai ser desligado em " + (time / 60000) + " minuto(s), por favor, fazer logoff com seguranca."));
		WLCTimer.getInstance().schedule(new ShutdownServer(getChannel()), time);
	}
	
	@Override
	public void shutdownWorld(int time) {
		try {
			getWorldInterface().shutdown(time);
		} catch (RemoteException e) {
			reconnectWorld();
		}
	}
	
	public int getLoadedMaps() {
		return mapFactory.getLoadedMapSize();
	}
	
	public MapleMapFactory getGmMapFactory() {
		return this.gmMapFactory;
	}
	
	public EventScriptManager getEventSM() {
		return eventSM;
	}
        
        public Barcos getBarcosNotScript() {
		return barcosnot;
	}
        
	
	public void reloadEvents() {
//		eventSM.cancel();
//		eventSM = new EventScriptManager(this, props.getProperty("channel.events").split(","));
//		eventSM.init();
        eventSM.cancel();
    	eventSM = null;
    	eventSM = new EventScriptManager(this, getEvents());
    	eventSM.init();
	}
	
	 @Override
    public int getMesoRate() {
        return mesoRate;
    }

    @Override
    public void setMesoRate(int mesoRate) {
        this.mesoRate = mesoRate;
    }

    @Override
    public int getDropRate() {
        return dropRate;
    }

    @Override
    public void setDropRate(int dropRate) {
        this.dropRate = dropRate;
    }

    @Override
    public int getBossDropRate() {
        return bossdropRate;
    }

    @Override
    public void setBossDropRate(int bossdropRate) {
        this.bossdropRate = bossdropRate;
    }

    @Override
    public int getPetExpRate() {
        return petExpRate;
    }

    @Override
    public void setPetExpRate(int petExpRate) {
        this.petExpRate = petExpRate;
    }

    @Override
    public int getMountRate() {
        return mountExpRate;
    }

    @Override
    public void setMountRate(int mountExpRate) {
        this.mountExpRate = mountExpRate;
    }
	
    public boolean allowUndroppablesDrop() {
        return dropUndroppables;
    }
	
	public boolean allowMoreThanOne() {
		return moreThanOne;
	}
	public boolean allowGmWhiteText() {
		return gmWhiteText;
	}
	
	public boolean allowCashshop() {
		return cashshop;
	}
	
	public boolean characterNameExists(String name) {
		int size = 0;
		try {
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT id FROM characters WHERE name = ?");
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				size++;
			}
			ps.close();
			rs.close();
		} catch (SQLException e) {
			log.error("Error in charname check: \r\n" + e.toString());
		}
		return size >= 1;
	}
	
	public MapleGuild getGuild(MapleGuildCharacter mgc) {
		int gid = mgc.getGuildId();
		MapleGuild g = null;
		try {
			g = this.getWorldInterface().getGuild(gid, mgc);
		}
		catch (RemoteException re) {
			log.error("RemoteException while fetching MapleGuild.", re);
			return null;
		}
		
		if (gsStore.get(gid) == null)
			gsStore.put(gid, new MapleGuildSummary(g));
		
		return g;
	}
	
	public MapleGuildSummary getGuildSummary(int gid) {
		if (gsStore.containsKey(gid))
			return gsStore.get(gid);
		else {		//this shouldn't happen much, if ever, but if we're caught
			//without the summary, we'll have to do a worldop
			try {
				MapleGuild g = this.getWorldInterface().getGuild(gid, null);
				if (g != null)
					gsStore.put(gid, new MapleGuildSummary(g));
				return gsStore.get(gid);	//if g is null, we will end up returning null
			}
			catch (RemoteException re) {
				log.error("RemoteException while fetching GuildSummary.", re);
				return null;
			}
		}
	}
	
	public void updateGuildSummary(int gid, MapleGuildSummary mgs) {
		gsStore.put(gid, mgs);
	}
	
	public void reloadGuildSummary() {
		try {
			MapleGuild g;
			for (int i : gsStore.keySet())
			{
				g = this.getWorldInterface().getGuild(i, null);
				if (g != null)
					gsStore.put(i, new MapleGuildSummary(g));
				else
					gsStore.remove(i);
			}
		}
		catch (RemoteException re) {
			log.error("RemoteException while reloading GuildSummary.", re);
		}
	}

 public static void main(String args[]) throws FileNotFoundException, IOException, NotBoundException,
            InstanceAlreadyExistsException, MBeanRegistrationException,
            NotCompliantMBeanException, MalformedObjectNameException {
        initialProp = new Properties();
        initialProp.load(new FileReader(System.getProperty("channel.config")));
        Registry registry = LocateRegistry.getRegistry(initialProp.getProperty("world.host"), Registry.REGISTRY_PORT, new SslRMIClientSocketFactory());
        worldRegistry = (WorldRegistry) registry.lookup("WorldRegistry");
        for (int i = 0; i < Integer.parseInt(initialProp.getProperty("channel.count", "0")); i++) {
            newInstance(initialProp.getProperty("channel." + i + ".key")).run();
        }
        DatabaseConnection.getConnection();
        Runtime.getRuntime().addShutdownHook(new Thread() {

            @Override
            public void run() {
                for (ChannelServer channel : getAllInstances()) {
                    for (int i = 910000001; i <= 910000022; i++) {
                        if (channel.getMapFactory().isMapLoaded(i)) {
                            MapleMap m = channel.getMapFactory().getMap(i);
                            for (MapleMapObject obj : m.getMapObjectsOfType(MapleMapObjectType.HIRED_MERCHANT)) {
                                HiredMerchant hm = (HiredMerchant) obj;
                                hm.closeShop(true);
                            }
                        }
                    }

                    for (MapleCharacter mc : channel.getPlayerStorage().getAllCharacters()) {
                        mc.saveToDB(true, true);
                    }
                }
            }
        });
    }


    public void yellowWorldMessage(String msg) {
        for (MapleCharacter mc : getPlayerStorage().getAllCharacters()) {
            mc.announce(MaplePacketCreator.sendYellowTip(msg));
        }
    }
    
    public void yellowWorldMessageAprendiz(String msg) {
        for (MapleCharacter mc : getPlayerStorage().getAllCharacters()) {
            if(mc.getLevel() > 1 && mc.getLevel() < 11) {
            mc.announce(MaplePacketCreator.sendYellowTip(msg));
            }
        }
    }

    public void worldMessage(String msg) {
        for (MapleCharacter mc : getPlayerStorage().getAllCharacters()) {
            mc.dropMessage(msg);
        }
    }
	
	public MapleSquad getMapleSquad(MapleSquadType type) {
		return mapleSquads.get(type);
	}
	
	public boolean addMapleSquad(MapleSquad squad, MapleSquadType type) {
		if (mapleSquads.get(type) == null) {
			mapleSquads.remove(type);
			mapleSquads.put(type, squad);
			return true;
		} else {
			return false;
		}
	}
	
	public boolean removeMapleSquad(MapleSquad squad, MapleSquadType type) {
		if (mapleSquads.containsKey(type)) {
			if (mapleSquads.get(type) == squad) {
				mapleSquads.remove(type);
				return true;
			}
		}
		return false;
	}
        
        
   public int getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(int k) {
        instanceId = k;
    }

    public void addInstanceId() {
        instanceId++;
    }
	
	public MarketEngine getMarket() {
		return me;
	}

	public long getLordLastUpdate() {
		return lordLastUpdate;
	}

	public void setLordLastUpdate(long lordLastUpdate) {
		this.lordLastUpdate = lordLastUpdate;
	}
	
	public void saveLordLastUpdate() {
		File file = new File("lordlastupdate.txt");
		FileOutputStream o = null;
		try {
			o = new FileOutputStream(file);
		} catch (FileNotFoundException ex) {
			Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
		}
		String write = String.valueOf(lordLastUpdate);
		for (int i = 0; i < write.length(); i++) {
			try {
				o.write((int) (write.charAt(i)));
			} catch (IOException ex) {
				Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		if (o != null) {
			try {
				o.close();
			} catch (IOException ex) {
				Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	public int getLordId() {
		return lordId;
	}

	public void setLordId(int lordId) {
		this.lordId = lordId;
	}
	
	public void saveLordId() {
		File file = new File("lordid.txt");
		FileOutputStream o = null;
		try {
			o = new FileOutputStream(file);
		} catch (FileNotFoundException ex) {
			Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
		}
		String write = String.valueOf(lordId);
		for (int i = 0; i < write.length(); i++) {
			try {
				o.write((int) (write.charAt(i)));
			} catch (IOException ex) {
				Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
		if (o != null) {
			try {
				o.close();
			} catch (IOException ex) {
				Logger.getLogger(ChannelServer.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
	
 	public boolean allowMTS() {
        return mts;
    }

    public boolean CanGMItem() {
        return GMItems;
    }
    
     public void broadcastSMega(MaplePacket data) {
        for (MapleCharacter chr : players.getAllCharacters()) {
            if (chr.getSmegaEnabled()) {
                chr.getClient().getSession().write(data);
            }
        }
    }
     
    protected ReadLock getMapLock() {
	return mapFactory.getReadLock();
    }

    public boolean AutoBan() {
        return AB;
    }
    
    public int getQuestRate() {
        return QuestExpRate;
    }

        public void setQuestRate(int QuestExpRate) {
        this.QuestExpRate = QuestExpRate;
    }
}