/*
This file is part of the OdinMS Maple Story Server
Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
Matthias Butz <matze@odinms.de>
Jan Christian Meyer <vimes@odinms.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License version 3
as published by the Free Software Foundation. You may not use, modify
or distribute this program under any other version of the
GNU Affero General Public License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package net.channel.handler;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import client.ISkill;
import client.MapleBuffStat;
import client.MapleCharacter;
import client.MapleJob;
import client.SkillFactory;
import client.anticheat.CheatingOffense;
import client.autoban.AutobanFactory;
import client.status.MonsterStatus;
import client.status.MonsterStatusEffect;
import config.skills.Buccaneer;
import config.skills.ChiefBandit;
import config.skills.DragonKnight;
import config.skills.FPArchMage;
import config.skills.FPMage;
import config.skills.FPWizard;
import config.skills.Hermit;
import config.skills.ILArchMage;
import config.skills.Marksman;
import config.skills.Paladin;
import config.skills.Shadower;
import config.skills.SuperGM;
import config.skills.WhiteKnight;
import java.util.HashMap;
import java.util.Map;
import net.AbstractMaplePacketHandler;
import server.AutobanManager;
import tools.FilePrinter;
import server.MapleStatEffect;
import server.MapleTimer.ItemTimer;
import server.life.Element;
import server.life.ElementalEffectiveness;
import server.life.MapleMonster;
import server.maps.MapleMap;
import server.maps.MapleMapItem;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import tools.MaplePacketCreator;
import tools.Randomizer;
import tools.data.LittleEndianAccessor;

public abstract class AbstractDealDamageHandler extends AbstractMaplePacketHandler {

    public class AttackInfo {

        public int numAttacked,  numDamage,  numAttackedAndDamage, display;
        public int skill,  stance,  direction,  charge;
        public Map<Integer, List<Integer>> allDamage;
        public boolean isHH = false, isTempest = false, ranged, magic;
        public int speed = 4;
        public long attackTime;


        private MapleStatEffect getAttackEffect(MapleCharacter chr, ISkill theSkill) {
            ISkill mySkill = theSkill;
            if (mySkill == null) {
                mySkill = SkillFactory.getSkill(skill);
            }
            int skillLevel = chr.getSkillLevel(mySkill);
            if (skillLevel == 0) {
                return null;
            }
             return mySkill.getEffect(skillLevel);
        }

        public MapleStatEffect getAttackEffect(MapleCharacter chr) {
            return getAttackEffect(chr, null);
        }
    }

    protected synchronized void applyAttack(AttackInfo attack, MapleCharacter player, int maxDamagePerMonster, int attackCount) {
        player.getCheatTracker().resetHPRegen();
        player.getCheatTracker().checkAttack(attack.skill);

        ISkill theSkill = null;
        MapleStatEffect attackEffect = null;
        if (attack.skill != 0) {
            theSkill = SkillFactory.getSkill(attack.skill);
            attackEffect = attack.getAttackEffect(player, theSkill);
            if (attackEffect == null) {
                player.getClient().getSession().write(MaplePacketCreator.enableActions());
                return;
            }
            if (player.getMp() < attackEffect.getMpCon()) {
                    AutobanFactory.MPCON.addPoint(player.getAutobanManager(), "Skill: " + attack.skill + "; Player MP: " + player.getMp() + "; MP Needed: " + attackEffect.getMpCon());
            }
            if (attack.skill != 2301002 || attack.skill != 9101000) {
                // heal is both an attack and a special move (healing)
                // so we'll let the whole applying magic live in the special move part
                if (player.isAlive()) {
                    attackEffect.applyTo(player);
                } else {
                    player.getClient().getSession().write(MaplePacketCreator.enableActions());
                }
            } else if (SkillFactory.getSkill(attack.skill).isGMSkill() && !player.isGM()) {
                player.getClient().getSession().close();
                return;
            }
        }      
        if (!player.isAlive()) {
            player.getCheatTracker().registerOffense(CheatingOffense.ATTACKING_WHILE_DEAD);
            return;
        }
        if (attackCount != attack.numDamage && attack.skill != 4211006 && attack.numDamage != attackCount * 2) {
            player.getCheatTracker().registerOffense(CheatingOffense.MISMATCHING_BULLETCOUNT, attack.numDamage + "/" + attackCount);
        }
        int totDamage = 0;
        final MapleMap map = player.getMap();
        if (attack.skill == 4211006) { // meso explosion
            for (Integer oned : attack.allDamage.keySet()) {
                    MapleMapObject mapobject = map.getMapObject(oned.intValue());
                    if (mapobject != null && mapobject.getType() == MapleMapObjectType.ITEM) {
                        MapleMapItem mapitem = (MapleMapItem) mapobject;
                        if (mapitem.getMeso() > 0) {
                            synchronized (mapitem) {
                                if (mapitem.isPickedUp()) {
                                    return;
                                }
                                map.removeMapObject(mapitem);
                                map.broadcastMessage(MaplePacketCreator.removeItemFromMap(mapitem.getObjectId(), 4, 0), mapitem.getPosition());
                                mapitem.setPickedUp(true);
                            }
                        } else if (mapitem.getMeso() == 0) {
                            player.getCheatTracker().registerOffense(CheatingOffense.ETC_EXPLOSION);
                            return;
                        }
                    } else if (mapobject != null && mapobject.getType() != MapleMapObjectType.MONSTER) {
                        player.getCheatTracker().registerOffense(CheatingOffense.EXPLODING_NONEXISTANT);
                        return; // etc explosion, exploding nonexistant things, etc.

                    }
                }
            }
        for (Integer oned : attack.allDamage.keySet()) {
            final MapleMonster monster = map.getMonsterByOid(oned.intValue());

            if (monster != null) {
                int totDamageToOneMonster = 0;
                    List<Integer> onedList = attack.allDamage.get(oned);
                    for (Integer eachd : onedList) {
			if(eachd < 0)
			eachd += Integer.MAX_VALUE;
                        totDamageToOneMonster += eachd;
                    }
                    totDamage += totDamageToOneMonster;

                player.checkMonsterAggro(monster);
  
                // anti-hack
                
                 if (attack.skill == 2301002 && !monster.getUndead()) {
                    player.getCheatTracker().registerOffense(CheatingOffense.HEAL_ATTACKING_UNDEAD);
                    return;
                 }
                 int dmgCheck = player.getCheatTracker().checkDamage(totDamageToOneMonster);
                 if (totDamageToOneMonster > attack.numDamage + 1) {
                 if (dmgCheck > 5 && totDamageToOneMonster < 99999 && monster.getId() < 9500317 && monster.getId() > 9600066) {
                       player.getCheatTracker().registerOffense(CheatingOffense.SAME_DAMAGE, dmgCheck + " times: " + totDamageToOneMonster);
                       }
                  }
                if (totDamageToOneMonster >= 250000 && attack.skill != 3221001 && attack.skill != 4211006) {
                    AutobanManager.getInstance().autoban
                    (player.getClient(),"[AUTOBAN]" + player.getName() + " dealt " + totDamageToOneMonster + " to monster " + monster.getId() + ".");
                }
                 if (totDamageToOneMonster >= 70000 && attack.skill == 0 && player.getLevel() < 200) {
                    AutobanManager.getInstance().autoban
                    (player.getClient(),"[AUTOBAN]" + player.getName() + " dealt " + totDamageToOneMonster + " to monster " + monster.getId() + " at level " + player.getLevel() + " with only a basic attack...");
                 }
                 
                 checkHighDamage(player, monster, attack, theSkill, attackEffect, totDamageToOneMonster, maxDamagePerMonster);

                 double distance = player.getPosition().distanceSq(monster.getPosition());
                 double distanceToDetect = 200000.0;
                                
                      if(attack.ranged) {
                        distanceToDetect += 400000;
                    } if(attack.magic) {
                        distanceToDetect += 200000;
                    } if(attack.skill == 2321008 || attack.skill == ILArchMage.BLIZZARD || attack.skill == 2121007) {
                        distanceToDetect += 275000;
                    } if(attack.skill == DragonKnight.DRAGON_ROAR || attack.skill == SuperGM.SUPER_DRAGON_ROAR) {
                        distanceToDetect += 250000;
                    } if(attack.skill == Shadower.BOOMERANG_STEP) {
		        distanceToDetect += 60000;
                    }
                    if (attack.skill == 2301002 && !monster.getUndead()) {
                         player.getCheatTracker().registerOffense(CheatingOffense.HEAL_ATTACKING_UNDEAD);
                         player.getClient().getSession().close();
                         return;
                 }

                  // pickpocket
                if (player.getBuffedValue(MapleBuffStat.PICKPOCKET) != null) {
                    switch (attack.skill) {
                        case 0:
                        case 4001334:
                        case 4201005:
                        case 4211002:
                        case 4211004:
                        case 4211001:
                        case 4221003:
                        case 4221007:
                        ISkill pickpocket = SkillFactory.getSkill(ChiefBandit.PICKPOCKET);
                        int delay = 0;
                        int reqdamage = 20000;
                        final int maxmeso = player.getBuffedValue(MapleBuffStat.PICKPOCKET).intValue();
                        for (Integer eachd : onedList) {
			     eachd += Integer.MAX_VALUE;
                            if (pickpocket.getEffect(player.getSkillLevel(pickpocket)).makeChanceResult()) {
				final Integer eachdf;
				if(eachd < 0)
				 eachdf = eachd + Integer.MAX_VALUE;
				   else
				  eachdf = eachd;
				
                                double perc = (double) eachd / (double) reqdamage;
                                final int todrop = Math.min((int) Math.max(perc * (double) maxmeso, (double) 1), maxmeso);
                                final MapleMap tdmap = player.getMap();
                                final Point tdpos = new Point((int) (monster.getPosition().getX() + (Math.random() * 100) - 50), (int) (monster.getPosition().getY()));
                                final MapleMonster tdmob = monster;
                                final MapleCharacter tdchar = player;
                                
                                
                                 ItemTimer.getInstance().schedule(new Runnable() {
                                    @Override
                                    public void run() {
                                        tdmap.spawnMesoDrop(todrop, todrop, tdpos, tdmob, tdchar, false);
                                    }
                                }, delay);
                                delay += 100;
                            }
                        }
                            break;
                    }
                }

                // effects
                switch (attack.skill) {
                    case 1221011: //sanctuary
                        if (attack.isHH) {
                            // TODO min damage still needs calculated.. using -20% as mindamage in the meantime.. seems to work
                            int HHDmg = (int) (player.calculateMaxBaseDamage(player.getTotalWatk()) * (theSkill.getEffect(player.getSkillLevel(theSkill)).getDamage() / 100));
                            HHDmg = (int) (Math.floor(Math.random() * (HHDmg - HHDmg * .80) + HHDmg * .80));
                            map.damageMonster(player, monster, HHDmg);
                        }
                        break;
                    case 3221007: //snipe
                       totDamageToOneMonster = 195000 + (int) Math.random() * 4999;
                    break;    
                    case 4101005: //drain
                    case 4121003:
                        monster.setTaunted(true);
                        monster.setTaunter(player);
                    break;
                    case 5111004: // energy drain.
                        int gainhp = (int) ((double) totDamageToOneMonster * (double) SkillFactory.getSkill(attack.skill).getEffect(player.getSkillLevel(SkillFactory.getSkill(attack.skill))).getX() / 100.0);
                        gainhp = Math.min(monster.getMaxHp(), Math.min(gainhp, player.getMaxHp() / 2));
                        player.addHP(gainhp);
                        break;
                    default:
                        //passives attack bonuses
                         if (attack.skill != 0) {
                          if (attackEffect.getFixDamage() != -1) {
                            if (totDamageToOneMonster != attackEffect.getFixDamage() && totDamageToOneMonster != 0) {
                                AutobanFactory.FIX_DAMAGE.autoban(player, String.valueOf(totDamageToOneMonster) + " damage");
                             }
                           }
                        }
                        if (totDamageToOneMonster > 0 && monster.isAlive()) {
                            if (player.getBuffedValue(MapleBuffStat.BLIND) != null) {
                                if (SkillFactory.getSkill(3221006).getEffect(player.getSkillLevel(SkillFactory.getSkill(3221006))).makeChanceResult()) {
                                    MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(Collections.singletonMap(MonsterStatus.ACC, SkillFactory.getSkill(3221006).getEffect(player.getSkillLevel(SkillFactory.getSkill(3221006))).getX()), SkillFactory.getSkill(3221006), false);
                                    monster.applyStatus(player, monsterStatusEffect, false, SkillFactory.getSkill(3221006).getEffect(player.getSkillLevel(SkillFactory.getSkill(3221006))).getY() * 1000);

                                }
                            }
                            if (player.getBuffedValue(MapleBuffStat.HAMSTRING) != null) {
                                if (SkillFactory.getSkill(3121007).getEffect(player.getSkillLevel(SkillFactory.getSkill(3121007))).makeChanceResult()) {
                                    MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(Collections.singletonMap(MonsterStatus.SPEED, SkillFactory.getSkill(3121007).getEffect(player.getSkillLevel(SkillFactory.getSkill(3121007))).getX()), SkillFactory.getSkill(3121007), false);
                                    monster.applyStatus(player, monsterStatusEffect, false, SkillFactory.getSkill(3121007).getEffect(player.getSkillLevel(SkillFactory.getSkill(3121007))).getY() * 1000);
                                }
                            }
                            if (player.getJob().isA(MapleJob.WHITEKNIGHT)) {
                                int[] charges = {1211005, 1211006};
                                for (int charge : charges) {
                                    if (player.isBuffFrom(MapleBuffStat.WK_CHARGE, SkillFactory.getSkill(charge))) {
                                        final ElementalEffectiveness iceEffectiveness = monster.getEffectiveness(Element.ICE);
                                        if (iceEffectiveness == ElementalEffectiveness.NORMAL || iceEffectiveness == ElementalEffectiveness.WEAK) {
                                            MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(Collections.singletonMap(MonsterStatus.FREEZE, 1), SkillFactory.getSkill(charge), false);
                                            monster.applyStatus(player, monsterStatusEffect, false, SkillFactory.getSkill(charge).getEffect(player.getSkillLevel(SkillFactory.getSkill(charge))).getY() * 2000);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                }

                //venom
                if (player.getSkillLevel(SkillFactory.getSkill(4120005)) > 0) {
                    MapleStatEffect venomEffect = SkillFactory.getSkill(4120005).getEffect(player.getSkillLevel(SkillFactory.getSkill(4120005)));
                    for (int i = 0; i < attackCount; i++) {
                        if (venomEffect.makeChanceResult()) {
                            if (monster.getVenomMulti() < 3) {
                                monster.setVenomMulti((monster.getVenomMulti() + 1));
                                MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(Collections.singletonMap(MonsterStatus.POISON, 1), SkillFactory.getSkill(4120005), false);
                                monster.applyStatus(player, monsterStatusEffect, false, venomEffect.getDuration(), true);
                            }
                        }
                    }
                } else if (player.getSkillLevel(SkillFactory.getSkill(4220005)) > 0) {
                    MapleStatEffect venomEffect = SkillFactory.getSkill(4220005).getEffect(player.getSkillLevel(SkillFactory.getSkill(4220005)));
                    for (int i = 0; i < attackCount; i++) {
                        if (venomEffect.makeChanceResult()) {
                            if (monster.getVenomMulti() < 3) {
                                monster.setVenomMulti((monster.getVenomMulti() + 1));
                                MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(Collections.singletonMap(MonsterStatus.POISON, 1), SkillFactory.getSkill(4220005), false);
                                monster.applyStatus(player, monsterStatusEffect, false, venomEffect.getDuration(), true);
                            }
                        }
                    }
                }
                if (totDamageToOneMonster > 0 && attackEffect != null && attackEffect.getMonsterStati().size() > 0) {
                    if (attackEffect.makeChanceResult()) {
                        MonsterStatusEffect monsterStatusEffect = new MonsterStatusEffect(attackEffect.getMonsterStati(), theSkill, false);
                        monster.applyStatus(player, monsterStatusEffect, attackEffect.isPoison(), attackEffect.getDuration());
                    }
                }

                //apply attack
                if (!attack.isHH) {
                    map.damageMonster(player, monster, totDamageToOneMonster);
                }
            }
        }
        if (totDamage > 1) {
            player.getCheatTracker().setAttacksWithoutHit(player.getCheatTracker().getAttacksWithoutHit() + 1);
            final int offenseLimit;
            switch (attack.skill) {
                case 3121004:
                case 5221004:
                    offenseLimit = 100;
                    break;
                default:
                    offenseLimit = 500;
                    break;
            }
            if (player.getCheatTracker().getAttacksWithoutHit() > offenseLimit) {
                player.getCheatTracker().registerOffense(CheatingOffense.ATTACK_WITHOUT_GETTING_HIT, Integer.toString(player.getCheatTracker().getAttacksWithoutHit()));
            }
        }
    }

	 private void checkHighDamage(MapleCharacter player, MapleMonster monster, AttackInfo attack, ISkill theSkill, MapleStatEffect attackEffect, int damageToMonster, int maximumDamageToMonster) {
        if (!player.isGM()) {
            int elementalMaxDamagePerMonster;
            int multiplyer = player.getJob().isA(MapleJob.PIRATE) ? 40 : 4;
            Element element = Element.NEUTRAL;
            if (theSkill != null) {
                element = theSkill.getElement();
                int skillId = theSkill.getId();
                switch (skillId) {
                    case 3221007: // Snipe
                        maximumDamageToMonster = 99999;
                        break;
                    case 4221001:
                        maximumDamageToMonster = 400000;
                        break;
                    default:
                        break;
                }
            }
            if (player.getBuffedValue(MapleBuffStat.WK_CHARGE) != null) {
                int chargeSkillId = player.getBuffSource(MapleBuffStat.WK_CHARGE);
                switch (chargeSkillId) {
                    case 1211003:
                    case 1211004:
                        element = Element.FIRE;
                        break;
                    case 1211005:
                    case 1211006:
                        element = Element.ICE;
                        break;
                    case 1211007:
                    case 1211008:
                        element = Element.LIGHTING;
                        break;
                    case 1221003:
                    case 1221004:
                        element = Element.HOLY;
                        break;
                }
                ISkill chargeSkill = SkillFactory.getSkill(chargeSkillId);
                maximumDamageToMonster *= chargeSkill.getEffect(player.getSkillLevel(chargeSkill)).getDamage() / 100.0;
            }
            if (element != Element.NEUTRAL) {
                double elementalEffect;
                if (attack.skill == 3211003 || attack.skill == 3111003) { // inferno and blizzard
                    elementalEffect = attackEffect.getX() / 200.0;
                } else {
                    elementalEffect = 0.5;
                }
                switch (monster.getEffectiveness(element)) {
                    case IMMUNE:
                        elementalMaxDamagePerMonster = 1;
                        break;
                    case NORMAL:
                        elementalMaxDamagePerMonster = maximumDamageToMonster;
                        break;
                    case WEAK:
                        elementalMaxDamagePerMonster = (int) (maximumDamageToMonster * (1.0 + elementalEffect));
                        break;
                    case STRONG:
                        elementalMaxDamagePerMonster = (int) (maximumDamageToMonster * (1.0 - elementalEffect));
                        break;
                    default:
                        throw new RuntimeException("Unknown enum constant");
                }
            }  else {
                elementalMaxDamagePerMonster = maximumDamageToMonster;
            }
            if (damageToMonster > elementalMaxDamagePerMonster * multiplyer) {
                player.getCheatTracker().registerOffense(CheatingOffense.HIGH_DAMAGE);
                if (damageToMonster > elementalMaxDamagePerMonster * multiplyer * 1.5) { // * 3 until implementation of lagsafe pingchecks for buff expiration
                       FilePrinter.printHacker(player.getName() + ".rtf", "O jogador esta hitando " + damageToMonster + ".\r\nNome do Monstro - " + monster.getName() + "\r\nNivel do Jogador: " + player.getLevel() + "\r\nNivel do Monstro: " + monster.getLevel() + "");
                }
            }
        }
    }
                

     protected AttackInfo parseDamage(LittleEndianAccessor lea, MapleCharacter chr, boolean ranged, boolean magic) {   
        AttackInfo ret = new AttackInfo();

        lea.readByte();
        ret.numAttackedAndDamage = lea.readByte();
        ret.numAttacked = (ret.numAttackedAndDamage >>> 4) & 0xF;
        ret.numDamage = ret.numAttackedAndDamage & 0xF;
        ret.allDamage = new HashMap<>();
        ret.skill = lea.readInt();
        ret.ranged = ranged;
        ret.magic = magic;
        
        switch (ret.skill) {
            case 2121001:
            case 2221001:
            case 2321001:
            case 5101004:
            case 5201002:
                ret.charge = lea.readInt();
                break;
            default:
                ret.charge = 0;
                break;
        }
       
        if (ret.skill == 1221011) {
            ret.isHH = true;
        }
        lea.readByte(); 
        ret.stance = lea.readByte();

        if (ret.skill == 4211006) {
            return parseMesoExplosion(lea, ret);
        }

        if (ranged) {
            lea.readByte();
            ret.speed = lea.readByte();
            lea.readByte();
            ret.direction = lea.readByte(); 
            lea.skip(7);
            switch (ret.skill) {
                case 3121004:
                case 3221001:
                case 5221004:
                    lea.skip(4);
                    break;
                default:
                    break;
            }
        } else {
            lea.readByte();
            ret.speed = lea.readByte();
            ret.attackTime = lea.readInt();
           // lea.skip(4);
            long lastAttackTime = System.currentTimeMillis();
            chr.setLastHitTime(lastAttackTime);
            if (ret.skill == 0 && chr.getJob().getId() != 522 && chr.getJob().getId() != 312) {
                if ((ret.attackTime - chr.getLastAttackTime() < 110) && (ret.attackTime - chr.getLastAttackTime() >= 0)) {
                    long math = ret.attackTime - chr.getLastAttackTime();
                     FilePrinter.printError(FilePrinter.FastAttack + chr.getName() + ".txt", chr.getName() + ": attacked with a speed of " + math + " and it doesn't seem right.\n"
                     + "MapID of character was " + chr.getMapId() + ".\n" );
                } else if (ret.attackTime-chr.getLastAttackTime() < 0 ) {
                    chr.dropMessage("You seem to have a negative attack time... that's not normal! You'll need to post on forums about this and possibly check your Antivirus.");
                }
                chr.setLastAttackTime(ret.attackTime);
            }
        } 
        
        int calcDmgMax = 0;
        if(magic && ret.skill != 0) {
            calcDmgMax = (chr.getTotalMagic() * chr.getTotalMagic() / 1000 + chr.getTotalMagic()) / 30 + chr.getTotalInt() / 200;
        } else if(ret.skill == 4001344) {
            calcDmgMax = (chr.getTotalLuk() * 5) * chr.getTotalWatk() / 100;
        } else if(ret.skill == DragonKnight.DRAGON_ROAR) {
            calcDmgMax = (chr.getTotalStr() * 4 + chr.getTotalDex()) * chr.getTotalWatk() / 100;
		} else if(ret.skill == Shadower.VENOMOUS_STAB) {
			calcDmgMax = (int) (18.5 * (chr.getTotalStr() + chr.getTotalLuk()) + chr.getTotalDex() * 2) / 100 * chr.calculateMaxBaseDamage(chr.getTotalWatk());
		} else {
            calcDmgMax = chr.calculateMaxBaseDamage(chr.getTotalWatk());
        }
        
        boolean canCrit = false;
        if(chr.getJob().isA((MapleJob.BOWMAN)) || chr.getJob().isA(MapleJob.THIEF) || chr.getJob() == MapleJob.MARAUDER || chr.getJob() == MapleJob.BUCCANEER) {
		canCrit = true;
        } 
        
        
        
	if(chr.getBuffEffect(MapleBuffStat.SHARP_EYES) != null) {
	        canCrit = true;
		calcDmgMax *= 1.4;
        }
        boolean shadowPartner = false;
	if(chr.getBuffEffect(MapleBuffStat.SHADOWPARTNER) != null)
	shadowPartner = true;
        
        if(ret.skill != 0) {
            int fixed = ret.getAttackEffect(chr, SkillFactory.getSkill(ret.skill)).getFixDamage();
            if(fixed > 0)
                calcDmgMax = fixed;
        }
        
        for (int i = 0; i < ret.numAttacked; i++) {
            int oid = lea.readInt();
            lea.skip(14);
            List<Integer> allDamageNumbers = new ArrayList<Integer>();
            
             MapleMonster monster = chr.getMap().getMonsterByOid(oid);
            
            if(chr.getBuffEffect(MapleBuffStat.WK_CHARGE) != null) {
                int sourceID = chr.getBuffSource(MapleBuffStat.WK_CHARGE);
				int level = chr.getBuffedValue(MapleBuffStat.WK_CHARGE);
                if(monster != null) {
                    if(sourceID == WhiteKnight.BW_FIRE_CHARGE || sourceID == WhiteKnight.SWORD_FIRE_CHARGE) {
                        if(monster.getStats().getEffectiveness(Element.FIRE) == ElementalEffectiveness.WEAK) {
                            calcDmgMax *= 1.05 + level * 0.015;
                        }
                    } else if(sourceID == WhiteKnight.BW_ICE_CHARGE || sourceID == WhiteKnight.SWORD_ICE_CHARGE) {
                        if(monster.getStats().getEffectiveness(Element.ICE) == ElementalEffectiveness.WEAK) {
                            calcDmgMax *= 1.05 + level * 0.015;
                        }
                    } else if(sourceID == WhiteKnight.BW_LIT_CHARGE || sourceID == WhiteKnight.SWORD_LIT_CHARGE) {
                        if(monster.getStats().getEffectiveness(Element.LIGHTING) == ElementalEffectiveness.WEAK) {
                            calcDmgMax *= 1.05 + level * 0.015;
                        }
                    } else if(sourceID == Paladin.BW_HOLY_CHARGE || sourceID == Paladin.SWORD_HOLY_CHARGE) {
                        if(monster.getStats().getEffectiveness(Element.HOLY) == ElementalEffectiveness.WEAK) {
                            calcDmgMax *= 1.2 + level * 0.015;
                        }
                    }
                } else {
                    calcDmgMax *= 1.5;
                }
            }
            
            if(ret.skill != 0) {
                ISkill skill = SkillFactory.getSkill(ret.skill);
                if(skill.getElement() != Element.NEUTRAL && chr.getBuffedValue(MapleBuffStat.ELEMENTAL_RESET) == null) {
                    if(monster != null) {
                        ElementalEffectiveness eff = monster.getEffectiveness(skill.getElement());
                        if(eff == ElementalEffectiveness.WEAK) {
                            calcDmgMax *= 1.5;
                        } else if(eff == ElementalEffectiveness.STRONG) {
                            //calcDmgMax *= 0.5;
                        }
                    } else {
                        calcDmgMax *= 1.5;
                    }
                }
		if(ret.skill == FPWizard.POISON_BREATH || ret.skill == FPMage.POISON_MIST || ret.skill == FPArchMage.FIRE_DEMON || ret.skill == ILArchMage.ICE_DEMON) {
					if(monster != null) {
					}
				} else if(ret.skill == Hermit.SHADOW_WEB) {
					if(monster != null) {
						calcDmgMax = monster.getHp() / (50 - chr.getSkillLevel(skill));
					}
				}
            }
            for (int j = 0; j < ret.numDamage; j++) {
                int damage = lea.readInt();
                int hitDmgMax = calcDmgMax;
                if(ret.skill == Buccaneer.BARRAGE) {
                    if(j > 3)
                        hitDmgMax *= Math.pow(2, (j - 3));
                }
		if(shadowPartner) {
	         if(j >= ret.numDamage / 2) {
			hitDmgMax *= 0.5;
			}
		}
                if(ret.skill == Marksman.SNIPE) {
			damage = 195000 + Randomizer.nextInt(5000);
			hitDmgMax = 200000;
		}
                
                int maxWithCrit = hitDmgMax;
		if(canCrit) 
		maxWithCrit *= 2;

                if (ret.skill == Marksman.SNIPE || (canCrit && damage > hitDmgMax)) {
                    damage = -Integer.MAX_VALUE + damage - 1;
                }
                
                 if ((damage > chr.calculateWorkingDamageTotal(chr.getTotalWatk())*1.3) && ret.skill == 0 
                        && (chr.getJob().getId() == 300 || chr.getJob().getId() == 310 || chr.getJob().getId() == 320
                        || chr.getJob().getId() == 311 || chr.getJob().getId() == 321
                        || chr.getJob().getId() == 312 || chr.getJob().getId() == 322
                        || chr.getJob().getId() == 410
                        || chr.getJob().getId() == 411
                        || chr.getJob().getId() == 412
                        || chr.getJob().getId() == 500 || chr.getJob().getId() == 520
                        || chr.getJob().getId() == 521
                        || chr.getJob().getId() == 512)) {
                    FilePrinter.printError(FilePrinter.Damage + chr.getName() + chr.getJob().getId() + ".txt", "Jogador com damage " + damage + " com rangeattack de " 
                            + chr.calculateWorkingDamageTotal(chr.getTotalWatk()) + " usando um ataque b�sico. Jogador era n�vel " + chr.getLevel() 
                            + ". Com a JobID " + chr.getJob().getId() + "\n");
                } else if ((damage > chr.calculateWorkingDamageTotal(chr.getTotalWatk())) && ret.skill == 0 && chr.getJob().getId() < 300) {
                    FilePrinter.printError(FilePrinter.Damage + chr.getName() + chr.getJob().getId()+ ".txt", "Jogador com damage  " + damage + " com rangeattack de " 
                            + chr.calculateWorkingDamageTotal(chr.getTotalWatk()) + " usando um ataque b�sico. Jogador era n�vel " + chr.getLevel() 
                            + ". Com a JobID " + chr.getJob().getId() + "\n");
                }
                
                allDamageNumbers.add(damage);
            }
            if (ret.skill != 5221004) {
                lea.skip(4);
            }
            ret.allDamage.put(Integer.valueOf(oid), allDamageNumbers);
        }
        return ret;
    }
    
    public AttackInfo parseMesoExplosion(LittleEndianAccessor lea, AttackInfo ret) {

        if (ret.numAttackedAndDamage == 0) {
            lea.skip(10);

            int bullets = lea.readByte();
            for (int j = 0; j < bullets; j++) {
                int mesoid = lea.readInt();
                lea.skip(1);
                ret.allDamage.put(Integer.valueOf(mesoid), null);
            }
            return ret;

        } else {
            lea.skip(6);
        }

        for (int i = 0; i < ret.numAttacked + 1; i++) {

            int oid = lea.readInt();

            if (i < ret.numAttacked) {
                lea.skip(12);
                int bullets = lea.readByte();

                List<Integer> allDamageNumbers = new ArrayList<Integer>();
                for (int j = 0; j < bullets; j++) {
                    int damage = lea.readInt();
                    // System.out.println("Damage: " + damage);
                    allDamageNumbers.add(Integer.valueOf(damage));
                }
                ret.allDamage.put(Integer.valueOf(oid), allDamageNumbers);
                lea.skip(4);

            } else {

                int bullets = lea.readByte();
                for (int j = 0; j < bullets; j++) {
                    int mesoid = lea.readInt();
                    lea.skip(1);
                    ret.allDamage.put(Integer.valueOf(mesoid), null);
                }
            }
        }

        return ret;
    }
    
 protected boolean isFarRangedSkill(int skillID) {
			switch (skillID) {
				case 1311006: //dragon roar
				case 2121007: //metor shower
				case 2321008: //genesis
				case 2221007: //Blizzard
				case 1221011: //Heavens hammer
				case 5221003: //Aerial strike
				case 9101006: //GM roar
				case 9001001: //GM roar [2]
			}
			return false;
		}
}
