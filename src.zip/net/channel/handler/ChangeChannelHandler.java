package net.channel.handler;

import java.net.InetAddress;
import java.rmi.RemoteException;
import client.MapleBuffStat;
import client.MapleCharacter;
import client.MapleClient;
import client.autoban.AutobanFactory;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.AbstractMaplePacketHandler;
import net.MaplePacket;
import net.channel.ChannelServer;
import net.world.MapleMessengerCharacter;
import net.world.remote.WorldChannelInterface;
import server.MapleTrade;
import server.PublicChatHandler;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

public class ChangeChannelHandler extends AbstractMaplePacketHandler {

    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        int channel = slea.readByte() + 1;
         if(c.getChannel() == channel) {
            try {
                AutobanFactory.GENERAL.alert(c.getPlayer(), "CCing to same channel.");
            } catch (RemoteException ex) {
                Logger.getLogger(ChangeChannelHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
            c.disconnect(false);
            return;
         } else if (c.getPlayer().getPlayerShop() != null) {
    		return;
    	}
        changeChannel(channel, c);
    }

    public static void changeChannel(int channel, MapleClient c) {
        MapleCharacter player = c.getPlayer();
         if (!c.isLoggedIn()) {
                    c.disconnect(false);
                    System.out.println("Player: " + player + ", isLoggedin(): " + c.isLoggedIn());
                    return;
         }
        if (!player.isAlive()) {
            c.getSession().write(MaplePacketCreator.enableActions());
            return;
        }
        if (PublicChatHandler.getPublicChatHolder().containsKey(player.getId())) {
            PublicChatHandler.getPublicChatHolder().remove(player.getId());
            PublicChatHandler.getPublicChatHolder().put(player.getId(), channel);
        }
        String ip = ChannelServer.getInstance(c.getChannel()).getIP(channel);
        String[] socket = ip.split(":");
		if (c.getPlayer().getTrade() != null) {
			MapleTrade.cancelTrade(c.getPlayer());
		}
		c.getPlayer().cancelMagicDoor();
		if (c.getPlayer().getBuffedValue(MapleBuffStat.MONSTER_RIDING) != null) {
            c.getPlayer().cancelEffectFromBuffStat(MapleBuffStat.MONSTER_RIDING);
        }
        if (c.getPlayer().getBuffedValue(MapleBuffStat.PUPPET) != null) {
            c.getPlayer().cancelEffectFromBuffStat(MapleBuffStat.PUPPET);
        }
        if (c.getPlayer().getBuffedValue(MapleBuffStat.MORPH) != null) {
            c.getPlayer().cancelEffectFromBuffStat(MapleBuffStat.MORPH);
        }
        if (c.getPlayer().getBuffedValue(MapleBuffStat.COMBO) != null) {
            c.getPlayer().cancelEffectFromBuffStat(MapleBuffStat.COMBO);
        }
        if (c.getPlayer().getBuffedValue(MapleBuffStat.SUMMON) != null) {
            c.getPlayer().cancelEffectFromBuffStat(MapleBuffStat.SUMMON);
        }
        if (!c.getPlayer().getDiseases().isEmpty()) {
            c.getPlayer().dispelDebuffs();
        }
		try {
			WorldChannelInterface wci = ChannelServer.getInstance(c.getChannel()).getWorldInterface();
			wci.addBuffsToStorage(c.getPlayer().getId(), c.getPlayer().getAllBuffs());
			wci.addCooldownsToStorage(c.getPlayer().getId(), c.getPlayer().getAllCooldowns());
		} catch (RemoteException e) {
			//log.info("RemoteException: {}", e);
			c.getChannelServer().reconnectWorld();
		}
		c.getPlayer().saveToDB(true, true);
		if (c.getPlayer().getCheatTracker() != null)
			c.getPlayer().getCheatTracker().dispose();
		
		if (c.getPlayer().getMessenger() != null) {
			MapleMessengerCharacter messengerplayer = new MapleMessengerCharacter(c.getPlayer());
			try {
				WorldChannelInterface wci = ChannelServer.getInstance(c.getChannel()).getWorldInterface();
				wci.silentLeaveMessenger(c.getPlayer().getMessenger().getId(), messengerplayer);
			} catch (RemoteException e) {
				c.getChannelServer().reconnectWorld();
			}
		}
		
		c.getPlayer().getMap().removePlayer(c.getPlayer());
		ChannelServer.getInstance(c.getChannel()).removePlayer(c.getPlayer());
		c.updateLoginState(MapleClient.LOGIN_SERVER_TRANSITION);
		try {
			MaplePacket packet = MaplePacketCreator.getChannelChange(InetAddress.getByName(socket[0]), Integer.parseInt(socket[1]));
			c.getSession().write(packet);
			// c.getSession().close();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
