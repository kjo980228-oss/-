/*
This file is part of the OdinMS Maple Story Server
Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
Matthias Butz <matze@odinms.de>
Jan Christian Meyer <vimes@odinms.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License version 3
as published by the Free Software Foundation. You may not use, modify
or distribute this program under any other version of the
GNU Affero General Public License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package net.channel.handler;

import java.net.InetAddress;

import client.MapleCharacter;
import client.MapleClient;
import client.MapleInventoryType;
import static config.configuracoes.mensagens.ShowConsole.defaultErro;
import static config.configuracoes.mensagens.ShowConsole.defaultPacket;
import java.net.UnknownHostException;
import net.AbstractMaplePacketHandler;
import net.MaplePacket;
import net.channel.ChannelServer;
import org.fusesource.jansi.AnsiConsole;
import server.MaplePortal;
import server.maps.MapleMap;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import server.MapleInventoryManipulator;
import server.MapleTrade;
import tools.FilePrinter;

public class ChangeMapHandler extends AbstractMaplePacketHandler {

    private static Logger log = LoggerFactory.getLogger(ChangeMapHandler.class);

 @Override
       public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        MapleCharacter chr = c.getPlayer();          
        if (chr.getTrade() != null) {
	    MapleTrade.cancelTrade(chr);
	}  
        if (slea.available() == 0) {
            int channel = c.getChannel();
            String ip = ChannelServer.getInstance(c.getChannel()).getIP(channel);
            String[] socket = ip.split(":");
            if (c.getPlayer().inCS() || c.getPlayer().inMTS()) {
               c.getPlayer().saveToDB(true, true);
               c.getPlayer().setInCS(false);
               c.getPlayer().setInMTS(false);
               } else {
                 AnsiConsole.out.println(defaultPacket + "Jogador usando [23 00] - nome (" + chr.getName() + ")");
                 return;
               }
               ChannelServer.getInstance(c.getChannel()).removePlayer(c.getPlayer());
               c.updateLoginState(MapleClient.LOGIN_SERVER_TRANSITION);
               try {
                c.announce(MaplePacketCreator.getChannelChange(InetAddress.getByName(socket[0]), Integer.parseInt(socket[1])));
            } catch (UnknownHostException ex) {
            }
        } else {
            if(c.getPlayer().inCS()) {                 
	       c.disconnect(false, false);               
	       return;           
	    }
            slea.readByte(); 
            int targetid = slea.readInt(); 
            String startwp = slea.readMapleAsciiString();
            MaplePortal portal = c.getPlayer().getMap().getPortal(startwp);
            MapleCharacter player = c.getPlayer();
            if (targetid != -1 && !c.getPlayer().isAlive()) {
                boolean executeStandardPath = true;
                boolean wheel = false;
                if (player.getEventInstance() != null) {
                    executeStandardPath = player.getEventInstance().revivePlayer(player);
                }
                if (executeStandardPath) {
                    MapleMap too = chr.getMap();
                    player.setHp(50);
                    c.getPlayer().cancelAllBuffs();
                    if (c.getPlayer().getMap().getForcedReturnId() != 999999999) {
                        if (c.getPlayer().getMap().isCPQMap()) {
                            MapleMap to = c.getChannelServer().getMapFactory().getMap(c.getPlayer().getMap().getId() + 1);
                            MaplePortal pto = to.getPortal(0);
                            player.setStance(0);
                            player.changeMap(to, pto);

                        } else {
                            MapleMap to = c.getPlayer().getMap().getForcedReturnMap();
                            MaplePortal pto = to.getPortal(0);
                            player.setStance(0);
                            player.changeMap(to, pto);

                        }
                    } else if (player.getEventInstance() == null && c.getChannelServer().eventMap != too.getId() && !player.getMap().isTown() && chr.getItemQuantity(5510000, false) > 0) {
                        MapleInventoryManipulator.removeById(c, MapleInventoryType.CASH, 5510000, 1, true, false);
                        player.dropMessage("Foi usado a Roda do Destino, voc� ficara no mesmo mapa!");
                        wheel = true;                
                    } else {
                        if (c.getPlayer().getMap().isCPQMap()) {
                            MapleMap to = c.getChannelServer().getMapFactory().getMap(c.getPlayer().getMap().getId() + 1);
                            MaplePortal pto = to.getPortal(0);
                        } else {
                            MapleMap to = c.getPlayer().getMap().getReturnMap();
                            MaplePortal pto = to.getPortal(0);
                            player.setStance(0);
                            player.changeMap(to, pto);

                        }
                    }
                    if(wheel) {
                    chr.setHp(50);
                    chr.changeMap(too, too.getPortal(0));
                    }
                }
           } else if (targetid != -1 && c.getPlayer().isGM()) {
                MapleMap to = ChannelServer.getInstance(c.getChannel()).getMapFactory().getMap(targetid);
                MaplePortal pto = to.getPortal(0);
                player.changeMap(to, pto);
            } else if (targetid != -1 && !c.getPlayer().isGM()) {
                AnsiConsole.out.println(defaultErro + "Jogador " + c.getPlayer().getName() + " tentou Mapjumping sem ser um gm.");
                FilePrinter.printError("Jumpmap.txt", "Jogador " + c.getPlayer().getName() + " tentou Mapjumping sem ser um gm.");
                
            } else {
                if (portal != null) {
                    portal.enterPortal(c);
                } else {
                     c.announce(MaplePacketCreator.enableActions());
                }
            }
        }
    }
}

