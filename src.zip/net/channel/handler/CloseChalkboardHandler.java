package net.channel.handler;

import client.MapleClient;
import net.AbstractMaplePacketHandler;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

/**
 *
 * @author Xterminator
 */

public class CloseChalkboardHandler extends AbstractMaplePacketHandler {

	@Override
	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
		        c.getPlayer().setChalkboard(null);
                        c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.useChalkboard(c.getPlayer(), true));
	}
}