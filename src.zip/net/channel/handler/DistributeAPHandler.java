/*
        This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc>
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>
 
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as
    published by the Free Software Foundation version 3 as published by
    the Free Software Foundation. You may not use, modify or distribute
    this program under any other version of the GNU Affero General Public
    License.
 
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.
 
    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
package net.channel.handler;
 
import client.ISkill;
import client.MapleCharacter;
import client.MapleClient;
import client.MapleJob;
import client.MapleStat;
import client.SkillFactory;
import net.AbstractMaplePacketHandler;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;
 
public class DistributeAPHandler extends AbstractMaplePacketHandler {
    @Override
    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        slea.readInt();
        int update = slea.readInt();
        if (c.getPlayer().getRemainingAp() > 0) {
            int max = c.getChannelServer().getMaxStat();
            switch (update) {
                case 64: // Str
                    if (c.getPlayer().getStr() >= max)
                        return;
                    c.getPlayer().addStat(1,1);
                    break;
                case 128: // Dex
                    if (c.getPlayer().getDex() >= max)
                        return;
                    c.getPlayer().addStat(2,1);
                    break;
                case 256: // Int
                    if (c.getPlayer().getInt() >= max)
                        return;
                    c.getPlayer().addStat(3, 1);
                    break;
                case 512: // Luk
                    if (c.getPlayer().getLuk() >= max)
                        return;
                    c.getPlayer().addStat(4, 1);
                    break;
                case 2048: // HP
                    addHP(c);
                    break;
                case 8192: // MP
                    addMP(c);
                    break;
                default:
                    c.getSession().write(MaplePacketCreator.updatePlayerStats(MaplePacketCreator.EMPTY_STATUPDATE, true));
                    return;
            }
            c.getPlayer().setRemainingAp(c.getPlayer().getRemainingAp() - 1);
            c.getPlayer().updateSingleStat(MapleStat.AVAILABLEAP, c.getPlayer().getRemainingAp());
        }
        c.getSession().write(MaplePacketCreator.enableActions());
    }

    public static void addHP(MapleClient c) {
        MapleCharacter player = c.getPlayer();
        MapleJob job = player.getJob();
        int MaxHP = player.getMaxHp();
        ISkill improvingMaxHP = null;
	int improvingMaxHPLevel = 0;
        if (player.getHpMpApUsed() > 9999 || MaxHP >= 30000) {
            return;
        }
       if (job.isA(MapleJob.WARRIOR)) {
        improvingMaxHP = SkillFactory.getSkill(1000001);
        improvingMaxHPLevel = player.getSkillLevel(improvingMaxHP);
        if (improvingMaxHPLevel >= 1) {
                MaxHP += rand(20, 24) + improvingMaxHP.getEffect(improvingMaxHPLevel).getY();
        } else {
                MaxHP += rand(20, 24);
        }
        }
        if (job.isA(MapleJob.WARRIOR)) {
            MaxHP += 20;
        } else if (job.isA(MapleJob.MAGICIAN)) {
            MaxHP += 6;
        } else if (job.isA(MapleJob.BOWMAN) || job.isA(MapleJob.THIEF)) {
            MaxHP += 16;
        } else if (job.isA(MapleJob.PIRATE)) {
            MaxHP += 18;
        } else {
            MaxHP += 8;
        }
        MaxHP = Math.min(30000, MaxHP);
        c.getPlayer().setMaxHp(MaxHP);
        c.getPlayer().setHpApUsed(c.getPlayer().getHpApUsed() + 1);
        c.getPlayer().updateSingleStat(MapleStat.MAXHP, MaxHP);
    }

    public static void addMP(MapleClient c) {
        MapleCharacter player = c.getPlayer();
        int MaxMP = c.getPlayer().getMaxMp();
        MapleJob job = player.getJob();
        
        if (player.getHpMpApUsed() > 9999 || player.getMaxMp() >= 30000) {
            return;
        }
        
        if (job.isA(MapleJob.BEGINNER)) {
            MaxMP += 6;
        } else if (job.isA(MapleJob.MAGICIAN)) {
            ISkill improvingMaxMP = SkillFactory.getSkill(2000001);
            int improvingMaxMPLevel = player.getSkillLevel(improvingMaxMP);
            if (improvingMaxMPLevel >= 1) {
                    MaxMP += rand(18, 20) + improvingMaxMP.getEffect(improvingMaxMPLevel).getY();
            } else {
                    MaxMP += rand(18, 20);
            }
	} else if (job.isA(MapleJob.MAGICIAN)) {
            MaxMP += 18;
        } else if (job.isA(MapleJob.BOWMAN) || job.isA(MapleJob.THIEF)) {
            MaxMP += 10;
        } else if (job.isA(MapleJob.PIRATE)) {
             MaxMP += 14;
        }
        MaxMP = Math.min(30000, MaxMP);
        c.getPlayer().setMaxMp(MaxMP);
        c.getPlayer().setMpApUsed(c.getPlayer().getMpApUsed() + 1);
        c.getPlayer().updateSingleStat(MapleStat.MAXMP, MaxMP);
    }
    
    private static int rand(int lbound, int ubound) {
		return (int) ((Math.random() * (ubound - lbound + 1)) + lbound);
	}
}
