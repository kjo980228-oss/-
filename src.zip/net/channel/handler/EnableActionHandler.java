package net.channel.handler;

import client.MapleClient;
import static config.configuracoes.mensagens.ShowConsole.defaultErro;
import net.AbstractMaplePacketHandler;
import org.fusesource.jansi.AnsiConsole;
import tools.FilePrinter;
import tools.data.LittleEndianAccessor;

/**
 *
 * @author Mats
 */

public class EnableActionHandler extends AbstractMaplePacketHandler {

	@Override
	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
		try {
		c.getPlayer().saveToDB (true, true);
		} catch (Exception ex) {
                AnsiConsole.out.println(defaultErro + "Erro ao atualizar personagem. (" + c.getPlayer().getName() + ")");
                FilePrinter.printError("Erro_updatep.txt", ex);
		}
	}
}
