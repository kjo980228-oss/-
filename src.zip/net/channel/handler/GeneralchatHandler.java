/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package net.channel.handler;

import client.MapleCharacter;
import client.MapleClient;
import client.autoban.AutobanFactory;
import client.messages.CommandProcessor;
import config.jogo.WordFilter;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.AbstractMaplePacketHandler;
import tools.FilePrinter;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

public class GeneralchatHandler extends AbstractMaplePacketHandler {
	@Override
	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
		String text = slea.readMapleAsciiString();
                text = WordFilter.illegalArrayCheck(text, c.getPlayer());  
                MapleCharacter chr = c.getPlayer();
		int show = slea.readByte();
                if (text.length() > Byte.MAX_VALUE && !chr.isGM()) {
                    try {
                        AutobanFactory.PACKET_EDIT.alert(c.getPlayer(), c.getPlayer().getName() + " tried to packet edit in General Chat.");
                    } catch (RemoteException ex) {
                        Logger.getLogger(GeneralchatHandler.class.getName()).log(Level.SEVERE, null, ex);
                    }
        	FilePrinter.printError(FilePrinter.EXPLOITS + c.getPlayer().getName() + ".txt", c.getPlayer().getName() + " tried to send text with length of " + text.length() + "\r\n");
        	c.disconnect(true);
        	return;
                }
		if (!CommandProcessor.getInstance().processCommand(c, text)) {
                    if(c.getPlayer().getMap().getProperties().getProperty("mute").equals(Boolean.TRUE) && !c.getPlayer().isGM()) {
                         c.getPlayer().dropMessage("O GM atualmente silenciou este mapa. Por favor, aguarde ate que ele volte a ser ativado.");
                    } else { 
                    c.getPlayer().resetAfkTimer();
                    c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.getChatText(c.getPlayer().getId(), text, c.getPlayer().hasGmLevel(3) && c.getChannelServer().allowGmWhiteText(), show));
		}
	}
    }
}