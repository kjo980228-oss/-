/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.channel.handler;

import client.MapleClient;
import net.AbstractMaplePacketHandler;
import tools.data.LittleEndianAccessor;

/**
 *
 * @author David
 */
public class GrenadeHandler extends AbstractMaplePacketHandler {
	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
		//oid = 102
		//Header: 64 00 (short)
		//18 
		//00 
		//00 
		//00 
		//35 00 00 00
		//86 01 00 00
	}
}
