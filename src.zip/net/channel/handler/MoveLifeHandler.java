/*
This file is part of the OdinMS Maple Story Server
Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
Matthias Butz <matze@odinms.de>
Jan Christian Meyer <vimes@odinms.de>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License version 3
as published by the Free Software Foundation. You may not use, modify
or distribute this program under any other version of the
GNU Affero General Public License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
package net.channel.handler;

import client.IItem;
import client.Item;
import java.awt.Point;
import java.util.List;
import java.util.Random;

import client.MapleClient;
import static config.configuracoes.mensagens.ShowConsole.defaultErro;
import java.rmi.RemoteException;
import java.util.Arrays;
import net.MaplePacket;
import org.fusesource.jansi.AnsiConsole;
import server.life.MapleMonster;
import server.life.MobSkill;
import server.life.MobSkillFactory;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import server.movement.LifeMovementFragment;
import tools.MaplePacketCreator;
import tools.Pair;
import tools.data.LittleEndianAccessor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tools.FilePrinter;

public class MoveLifeHandler extends AbstractMovementPacketHandler {

    private static Logger log = LoggerFactory.getLogger(MoveLifeHandler.class);

    @Override
    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
     
        int objectid = slea.readInt();
        short moveid = slea.readShort();
        
        MapleMapObject mmo = c.getPlayer().getMap().getMapObject(objectid);
        if (mmo == null || mmo.getType() != MapleMapObjectType.MONSTER) {
           return;
	}
        final MapleMonster monster = (MapleMonster) mmo;

        List<LifeMovementFragment> res = null;
        int skillByte = slea.readByte();
        int skill = slea.readByte();
        int skill_1 = slea.readByte() & 0xFF;
        int skill_2 = slea.readByte();
        int skill_3 = slea.readByte();
        @SuppressWarnings("unused")
        int skill_4 = slea.readByte();

        MobSkill toUse = null;
        Random rand = new Random();

        if (skillByte == 1 && monster.getNoSkills() > 0) {
            int random = rand.nextInt(monster.getNoSkills());
            Pair<Integer, Integer> skillToUse = monster.getSkills().get(random);
            toUse = MobSkillFactory.getMobSkill(skillToUse.getLeft(), skillToUse.getRight());
            int percHpLeft = (int) ((monster.getHp() / monster.getMaxHp()) * 100);
            if (toUse.getHP() < percHpLeft || !monster.canUseSkill(toUse)) {
                toUse = null;
            }
        }

        if (skill_1 >= 100 && skill_1 <= 200 && monster.hasSkill(skill_1, skill_2)) {
            MobSkill skillData = MobSkillFactory.getMobSkill(skill_1, skill_2);
            if (skillData != null && monster.canUseSkill(skillData)) {
                skillData.applyEffect(c.getPlayer(), monster, true);
            }
        }

        slea.readByte();
        slea.readInt(); // whatever
        int start_x = slea.readShort(); // hmm.. startpos?
        int start_y = slea.readShort(); // hmm...
        Point startPos = new Point(start_x, start_y);

        res = parseMovement(slea);

        if (monster.getController() != c.getPlayer()) {
            if (monster.isAttackedBy(c.getPlayer())) { // aggro and controller change
                monster.switchController(c.getPlayer(), true);
            } else {
                return;
            }
        } else {
            if (skill == -1 && monster.isControllerKnowsAboutAggro() && !monster.isMobile() && !monster.isFirstAttack()) {
                monster.setControllerHasAggro(false);
                monster.setControllerKnowsAboutAggro(false);
            }
        }
        boolean aggro = monster.isControllerHasAggro();

        if (toUse != null) {
            c.getSession().write(MaplePacketCreator.moveMonsterResponse(objectid, moveid, monster.getMp(), aggro, toUse.getSkillId(), toUse.getSkillLevel()));
        } else {
            c.getSession().write(MaplePacketCreator.moveMonsterResponse(objectid, moveid, monster.getMp(), aggro));
        }

        if (aggro) {
            monster.setControllerKnowsAboutAggro(true);
        }

        if (res != null) {
            if (slea.available() != 9) {
                log.warn("slea.available != 9 (movement parsing error)");
                try {
                    c.getPlayer().getClient().getChannelServer().getWorldInterface().broadcastGMMessage("", MaplePacketCreator.serverNotice(5, c.getPlayer().getName() + " is using dupex monster vaccum.").getBytes());
                } catch (RemoteException ex) {
                    c.getPlayer().getClient().getChannelServer().reconnectWorld();
                }
                c.getSession().close();
                return;
            }
            MaplePacket packet = MaplePacketCreator.moveMonster(skillByte, skill, skill_1, skill_2, skill_3, objectid, startPos, res);
            c.getPlayer().getMap().broadcastMessage(c.getPlayer(), packet, monster.getPosition());
            updatePosition(res, monster, -1);
            c.getPlayer().getMap().moveMonster(monster, monster.getPosition());
            c.getPlayer().getCheatTracker().checkMoveMonster(monster.getPosition());
        }

        if (monster.isHypnotized() && monster.getHypnotizer() != null && monster.canDamage()) {
           final MapleMonster target = monster.getMap().findClosestMonster(monster.getPosition(), 1000);
            if (target != null) {
                monster.setCanDamage(false);
                monster.scheduleCanDamage(3000);
                int dmg = monster.getLevel() * 10 + (int) (Math.random() * 300);
                monster.getMap().damageMonster(monster.getHypnotizer(), target, dmg);
                monster.getMap().broadcastMessage(MaplePacketCreator.mobDamageMob(target, dmg, 0));
            }
        }

        if (monster.getId() == 9300061 && monster.getHp() < monster.getMaxHp() / 2 && Math.random() < 0.7) {
            if (monster.getShouldDrop() == true) {
                monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "O Coelhinho da Lua esta se sentindo doente. Por favor, protege-lo para que ele possa fazer deliciosos bolinhos de arroz!"));
                monster.setShouldDrop(false);
                monster.scheduleCanDrop(4000);
            }
        }
       

        if (monster.getId() == 9300061 && (monster.getShouldDrop() == true || monster.getJustSpawned() == true)) {
            if (monster.getJustSpawned() == true) {
                monster.setJustSpawned(false);
                monster.setDropped(1);
                monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "O Coelhinho da Lua fez 1 bolinho de arroz."));
                IItem Item = new Item(4001101, (byte) 0, (short) 1);
                try {
                    monster.getMap().spawnItemDrop(monster, monster.getEventInstance().getPlayers().get(0), Item, monster.getPosition(), false, false);
                } catch (Exception ex) {

                }
            } else {
                if (monster.getShouldDrop() == true) {
                    int d = monster.getDropped() + 1;
                    monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "O Coelhinho da Lua fez " + d + " bolinhos de arroz."));
                    monster.setDropped(d);
                    monster.setShouldDrop(false);
                    monster.scheduleCanDrop(6000);
                    IItem Item = new Item(4001101, (byte) 0, (short) 1);
                    try {
                        monster.getMap().spawnItemDrop(monster, monster.getEventInstance().getPlayers().get(0), Item, monster.getPosition(), false, false);  
                    } catch (NullPointerException ex) {

                    }
                }
                
            }
        }
        
        /* Kenta Quest */
        if (monster.getId() == 9300102 && monster.getHp() < monster.getMaxHp() && Math.random() < 0.5) {
            if (monster.getShouldDrop() == true) {
                monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "O Porco est� em perigo. Por favor, proteja-o!"));
                monster.setShouldDrop(false);
                monster.scheduleCanDrop(4000);
            }
        }
            
       if (monster.getId() == 9300102 && (monster.getShouldDrop() == true || monster.getJustSpawned() == true)) {
            if (monster.getJustSpawned() == true) {
                monster.setJustSpawned(false);
                monster.setDropped(1);
                IItem Item = new Item(4031507, (byte) 0, (short) 1);
                try {
                    monster.getMap().spawnItemDrop(monster, monster.getEventInstance().getPlayers().get(0), Item, monster.getPosition(), false, false);
                } catch (Exception ex) {

                }
            } else {
                if (monster.getShouldDrop() == true) {
                    int d = monster.getDropped() + 1;
                    monster.setDropped(d);
                    monster.setShouldDrop(false);
                    monster.scheduleCanDrop(6000);
                    IItem Item = new Item(4031507, (byte) 0, (short) 1);
                    try {
                        monster.getMap().spawnItemDrop(monster, monster.getEventInstance().getPlayers().get(0), Item, monster.getPosition(), false, false);  
                    } catch (NullPointerException ex) {

                    }
                }                
            }
        } 
       
      /* NPQ Facil 
       * MOIB - 9400322
       * MAXHP - 2000
       * LEVEL - 23
       */
       
        if (monster.getId() == 9400322 && monster.getHp() < monster.getMaxHp() && Math.random() < 0.6) {
            if (monster.getShouldDrop() == true) {
                monster.setShouldDrop(false);
                monster.scheduleCanDrop(4000);
            }
        }            
       if (monster.getId() == 9400322 && (monster.getShouldDrop() == true || monster.getJustSpawned() == true)) {
            if (monster.getJustSpawned() == true) {
                monster.setJustSpawned(false);
                monster.setDropped(1);
                try {
                    monster.gainHp((int) (Math.random() * 125 * 3));
                    monster.getMap().broadcastMessage(MaplePacketCreator.showRecovery(monster.getId(), (byte) (Math.random() * 125 * 3)));
                    monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">")); 
                } catch (Exception ex) {
                        AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Facil.");
                        FilePrinter.printError(FilePrinter.EXCEPTION, ex);
                }
            } else {
                if (monster.getShouldDrop() == true) {
                    int d = monster.getDropped() + 1;
                    monster.setDropped(d);
                    monster.setShouldDrop(false);
                    monster.scheduleCanDrop(6000);
                    try {
                           monster.gainHp((int) (Math.random() * 150 * 3));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">"));
                           double range = Double.POSITIVE_INFINITY;
                           List<MapleMapObject> items = monster.getMap().getMapObjectsInRange(c.getPlayer().getPosition(), range, Arrays.asList(MapleMapObjectType.ITEM));
                           for (MapleMapObject itemmo : items) {
                           monster.getMap().removeMapObject(itemmo);
                           monster.getMap().broadcastMessage(MaplePacketCreator.removeItemFromMap(itemmo.getObjectId(), 1, c.getPlayer().getId()));
                           } if (items.size() > 0) {
                           monster.gainHp((int) (Math.random() * 50 * items.size()));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Absorveu os Blocos de Neve!"));        
                           } if(monster.getId() == 9400322 && monster.getHp() > 4000) {
                               monster.getEventInstance().Snown();
                               monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Boneco da Neve congelou!"));
                           }
                    } catch (NullPointerException ex) {
                        AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Facil.");
                        FilePrinter.printError(FilePrinter.EXCEPTION, ex);
               }
            }                
         }
      }   
      /* NPQ Medio
       * MOIB - 9400327
       * MAXHP - 10000
       * LEVEL - 50
       */
       
        if (monster.getId() == 9400327 && monster.getHp() < monster.getMaxHp() && Math.random() < 0.6) {
            if (monster.getShouldDrop() == true) {
                monster.setShouldDrop(false);
                monster.scheduleCanDrop(4000);
            }
        }            
       if (monster.getId() == 9400327 && (monster.getShouldDrop() == true || monster.getJustSpawned() == true)) {
            if (monster.getJustSpawned() == true) {
                monster.setJustSpawned(false);
                monster.setDropped(1);
                try {
                    monster.gainHp((int) (Math.random() * 350 * 5));
                    monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">"));        
                } catch (Exception ex) {
                        AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Medio.");
                        FilePrinter.printError(FilePrinter.EXCEPTION, ex);
                }
            } else {
                if (monster.getShouldDrop() == true) {
                    int d = monster.getDropped() + 1;
                    monster.setDropped(d);
                    monster.setShouldDrop(false);
                    monster.scheduleCanDrop(6000);
                    try {
                           monster.gainHp((int) (Math.random() * 350 * 5));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">"));
                           double range = Double.POSITIVE_INFINITY;
                           List<MapleMapObject> items = monster.getMap().getMapObjectsInRange(c.getPlayer().getPosition(), range, Arrays.asList(MapleMapObjectType.ITEM));
                           for (MapleMapObject itemmo : items) {
                           monster.getMap().removeMapObject(itemmo);
                           monster.getMap().broadcastMessage(MaplePacketCreator.removeItemFromMap(itemmo.getObjectId(), 1, c.getPlayer().getId()));
                           } if (items.size() > 0) {
                           monster.gainHp((int) (Math.random() * 35 * items.size()));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Absorveu os Blocos de Neve!"));        
                           } if(monster.getId() == 9400327 && monster.getHp() > 20000) {
                               monster.getEventInstance().Snown();
                               monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Boneco da Neve congelou!"));
                           }
                    } catch (NullPointerException ex) {
                        AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Medio.");
                        FilePrinter.printError(FilePrinter.EXCEPTION, ex);
               }
            }                
         }
      } 
      /* NPQ Dificil
       * MOIB - 9400332
       * MAXHP - 15000
       * LEVEL - 80
       */
       
        if (monster.getId() == 9400332 && monster.getHp() < monster.getMaxHp() && Math.random() < 0.5) {
            if (monster.getShouldDrop() == true) {
                monster.setShouldDrop(false);
                monster.scheduleCanDrop(4000);
            }
        }       
       if (monster.getId() == 9400332 && (monster.getShouldDrop() == true || monster.getJustSpawned() == true)) {
            if (monster.getJustSpawned() == true) {
                monster.setJustSpawned(false);
                monster.setDropped(1);
                try {
                    monster.gainHp((int) (Math.random() * 600 * 6));
                    monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">"));        
                } catch (Exception ex) {
                    AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Dificil.");
                    FilePrinter.printError(FilePrinter.EXCEPTION, ex);

                }
            } else {
                if (monster.getShouldDrop() == true) {
                    int d = monster.getDropped() + 1;
                    monster.setDropped(d);
                    monster.setShouldDrop(false);
                    monster.scheduleCanDrop(6000);
                    try {
                           monster.gainHp((int) (Math.random() * 600 * 6));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Est� com HP <" + monster.getHp() + ">"));
                           double range = Double.POSITIVE_INFINITY;
                           List<MapleMapObject> items = monster.getMap().getMapObjectsInRange(c.getPlayer().getPosition(), range, Arrays.asList(MapleMapObjectType.ITEM));
                           for (MapleMapObject itemmo : items) {
                           monster.getMap().removeMapObject(itemmo);
                           monster.getMap().broadcastMessage(MaplePacketCreator.removeItemFromMap(itemmo.getObjectId(), 1, c.getPlayer().getId()));
                           } if (items.size() > 0) {
                           monster.gainHp((int) (Math.random() * 50 * items.size()));
                           monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Absorveu os Blocos de Neve!"));        
                           } if(monster.getId() == 9400332 && monster.getHp() > 30000) {
                               monster.getEventInstance().Snown();
                               monster.getMap().broadcastMessage(MaplePacketCreator.serverNotice(0, "[Boneco da Neve] Boneco da Neve congelou!"));
                           }
                    } catch (NullPointerException ex) {
                        AnsiConsole.out.println(defaultErro + "Houve um problema em NPQ Dificil.");
                        FilePrinter.printError(FilePrinter.EXCEPTION, ex);

                }
             }                
          }
       } 
    }    
}
