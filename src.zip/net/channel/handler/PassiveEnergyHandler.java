package net.channel.handler;

import client.MapleCharacter;
import client.MapleClient;
import net.channel.handler.AbstractDealDamageHandler.AttackInfo;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

/**
 *
 * @author Bassoe
 */
public class PassiveEnergyHandler extends AbstractDealDamageHandler {

    @Override
    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        MapleCharacter player = c.getPlayer();
        if (player.getEnergy() == 10000) {
            AttackInfo attack = parseDamage(slea, player, false, false);
            applyAttack(attack, player, 999999, 1);
            player.getMap().broadcastMessage(player, MaplePacketCreator.closeRangeAttack(player.getId(), attack.skill, attack.stance, attack.numAttackedAndDamage, attack.allDamage, attack.speed), false, true);
        }
    }
}