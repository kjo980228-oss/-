package net.channel.handler;

import client.MapleCharacter;
import client.MapleClient;
import client.autoban.AutobanFactory;
import java.rmi.RemoteException;
import java.util.logging.Level;
import java.util.logging.Logger;
import net.AbstractMaplePacketHandler;
import tools.FilePrinter;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

public class PetChatHandler extends AbstractMaplePacketHandler {

    @Override
    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        int petId = slea.readInt();
        slea.readInt();
        int unknownShort = slea.readShort();
        String text = slea.readMapleAsciiString();
        MapleCharacter player = c.getPlayer();
        if (text.length() > Byte.MAX_VALUE) {
            try {
                AutobanFactory.PACKET_EDIT.alert(c.getPlayer(), c.getPlayer().getName() + " tried to packet edit with pets.");
            } catch (RemoteException ex) {
                Logger.getLogger(PetChatHandler.class.getName()).log(Level.SEVERE, null, ex);
            }
        	FilePrinter.printError(FilePrinter.EXPLOITS + c.getPlayer().getName() + ".txt", c.getPlayer().getName() + " tried to send text with length of " + text.length() + "\r\n");
        	c.disconnect(true);
        	return;
        }
        player.getMap().broadcastMessage(player, MaplePacketCreator.petChat(player.getId(), unknownShort, text, c.getPlayer().getPetIndex(petId)), true);
    }
}