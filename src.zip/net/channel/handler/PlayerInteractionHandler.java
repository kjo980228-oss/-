package net.channel.handler;

import java.util.Arrays;
import client.IItem;
import client.MapleCharacter;
import client.MapleClient;
import client.MapleInventoryType;
import client.messages.CommandProcessor;
import config.configuracoes.mensagens.Mensagens;
import net.AbstractMaplePacketHandler;
import server.AutobanManager;
import server.MapleInventoryManipulator;
import server.MapleItemInformationProvider;
import server.PlayerInteraction.MapleMiniGame;
import server.PlayerInteraction.MaplePlayerShopItem;
import server.MapleTrade;
import server.maps.MapleMapObject;
import server.PlayerInteraction.PlayerInteractionManager;
import server.PlayerInteraction.HiredMerchant;
import server.PlayerInteraction.IPlayerInteractionManager;
import server.PlayerInteraction.MaplePlayerShop;
import server.maps.MapleMapObjectType;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;

public class PlayerInteractionHandler extends AbstractMaplePacketHandler {

    private enum Action {

        CREATE(0),
        INVITE(2),
        DECLINE(3),
        VISIT(4),
        CHAT(6),
        EXIT(0xA),
        OPEN(0xB),
        SET_ITEMS(0xE),
        SET_MESO(0xF),
        CONFIRM(0x10),
        ADD_ITEM(0x14),
        BUY(0x15),
        REMOVE_ITEM(0x19),
        BAN_PLAYER(0x1A),
        PUT_ITEM(0x1F),
        MERCHANT_BUY(0x20),
        TAKE_ITEM_BACK(0x24),
        MAINTENANCE_OFF(0x25),
        MERCHANT_ORGANIZE(0x26),
        CLOSE_MERCHANT(0x27),
        REQUEST_TIE(44),
        ANSWER_TIE(45),
        GIVE_UP(46),
        EXIT_AFTER_GAME(50),
        CANCEL_EXIT(51),
        READY(52),
        UN_READY(53),
        MOVE_OMOK(58),
        START(55),
        SKIP(57),
        SELECT_CARD(62);
        final byte code;

        private Action(int code) {
            this.code = (byte) code;
        }

        public byte getCode() {
            return code;
        }
    }

    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
        //System.out.println(slea);
        byte mode = slea.readByte();
        if (mode == Action.CREATE.getCode()) {
            byte createType = slea.readByte();
            if (createType == 3) { // Trade
                MapleTrade.startTrade(c.getPlayer());
            } else {
                if (c.getPlayer().getChalkboard() != null) {
                    return;
                }
                if (createType == 1) {
                    String desc = slea.readMapleAsciiString();
                    String pass = null;
                    if (slea.readByte() == 1) {
                        pass = slea.readMapleAsciiString();
                    }
                    int type = slea.readByte(); // 20 6E 4E
                    MapleMiniGame game = new MapleMiniGame(c.getPlayer(), desc);
                    c.getPlayer().setMiniGame(game);
                    game.setPieceType(type);
                    game.setGameType("omok");
                    c.getPlayer().getMap().addMapObject(game);
                    c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.addOmokBox(c.getPlayer(), 1, 0));
                    game.sendOmok(c, type);
                } else if (createType == 2) { // matchcard
                if (c.getPlayer().getChalkboard() != null)
                    return;
                String desc = slea.readMapleAsciiString();
                slea.readByte(); // 20 6E 4E
                int type = slea.readByte(); // 20 6E 4E
                MapleMiniGame game = new MapleMiniGame(c.getPlayer(), desc);
                game.setPieceType(type);
                if (type == 0)
                    game.setMatchesToWin(6);
                if (type == 1)
                    game.setMatchesToWin(10);
                if (type == 2)
                    game.setMatchesToWin(15);
                game.setGameType("matchcard");
                c.getPlayer().setMiniGame(game);
                c.getPlayer().getMap().addMapObject(game);
                c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.addMatchCardBox(c.getPlayer(), 1, 0));
                game.sendMatchCard(c, type);
            } else if (createType == 4 || createType == 5) { // Shops
                    if (!c.getPlayer().hasMerchant() && c.getPlayer().tempHasItems()) {
                        c.getPlayer().dropMessage(1, "Fale com Fredrick para recuperar os itens guardados.");
                         c.getSession().write(MaplePacketCreator.enableActions());
                        return;
                    }
                    if (c.getPlayer().getMap().getMapObjectsInRange(c.getPlayer().getPosition(), 19500, Arrays.asList(MapleMapObjectType.SHOP, MapleMapObjectType.HIRED_MERCHANT)).size() != 0 || c.getPlayer().getMapId() < 910000001 || c.getPlayer().getMapId() > 910000022) {
                        c.getPlayer().dropMessage(1, "Voce nao pode estabelecer uma loja aqui.");
                         c.getSession().write(MaplePacketCreator.enableActions());
                        return;
                    }
                    if (c.getPlayer().gmLevel() == 3) {
                        c.getPlayer().dropMessage(1, "Loja desabilitada!");
                        c.getSession().write(MaplePacketCreator.enableActions());
                        return;
                    }
                     if (c.getPlayer().haveItem(5140000) || c.getPlayer().haveItem(5140001) || c.getPlayer().haveItem(5140002) || c.getPlayer().haveItem(5140003) && c.getPlayer().haveItem(5140004) || c.getPlayer().haveItem(5140006)/* || c.getPlayer().haveItem(5030006) || c.getPlayer().haveItem(5030002) || c.getPlayer().haveItem(5030001) || c.getPlayer().haveItem(5030000)*/) {
                        c.getPlayer().dropMessage(1, "Loja desabilitada temporariamente!");
                         c.getSession().write(MaplePacketCreator.enableActions());
                        return;
                    }
                    String desc = slea.readMapleAsciiString();
                    slea.skip(3);
                    int itemId = slea.readInt();
                    IPlayerInteractionManager shop;
                    if (c.getPlayer().haveItem(itemId, 1, false, true)) {
                        if (createType == 4) {
                            shop = new MaplePlayerShop(c.getPlayer(), itemId, desc);
                        } else {
                            shop = new HiredMerchant(c.getPlayer(), itemId, desc);
                        }
                        c.getPlayer().setInteraction(shop);
                        c.getSession().write(MaplePacketCreator.getInteraction(c.getPlayer(), true));
                    } else {
                        AutobanManager.getInstance().autoban(c, "" + Mensagens.Nome_Server + " | Merchant Shop : Tente abrir uma loja sem o item.");
                        return;
                    }
                } else {
                    System.out.println("Unhandled PLAYER_INTERACTION packet: " + slea.toString());
                }
            }
        } else if (mode == Action.INVITE.getCode()) {
            int otherPlayer = slea.readInt();
            MapleCharacter otherChar = c.getPlayer().getMap().getCharacterById(otherPlayer);
            MapleTrade.inviteTrade(c.getPlayer(), otherChar);
        } else if (mode == Action.DECLINE.getCode()) {
            MapleTrade.declineTrade(c.getPlayer());
        } else if (mode == Action.VISIT.getCode()) {
            if (c.getPlayer().getTrade() != null && c.getPlayer().getTrade().getPartner() != null) {
                MapleTrade.visitTrade(c.getPlayer(), c.getPlayer().getTrade().getPartner().getChr());
            } else {
                int oid = slea.readInt();
                MapleMapObject ob = c.getPlayer().getMap().getMapObject(oid);
                if (ob instanceof IPlayerInteractionManager && c.getPlayer().getInteraction() == null) {
                    IPlayerInteractionManager ips = (IPlayerInteractionManager) ob;
                    if (ips.getShopType() == 1) {
                        HiredMerchant merchant = (HiredMerchant) ips;
                        if (merchant.isOwner(c.getPlayer())) {
                            merchant.setOpen(false);
                            merchant.broadcast(MaplePacketCreator.shopErrorMessage(0x0D, 1), false);
                            merchant.removeAllVisitors((byte) 16, (byte) 0);
                            c.getPlayer().setInteraction(ips);
                            c.getSession().write(MaplePacketCreator.getInteraction(c.getPlayer(), false));
                            return;
                        } else if (!merchant.isOpen()) {
                            c.getPlayer().dropMessage(1, "Esta loja esta em manutencao, por favor, venha mais tarde.");
                            return;
                        }
                    } else if (ips.getShopType() == 2) {
                        if (((MaplePlayerShop) ips).isBanned(c.getPlayer().getName())) {
                            c.getPlayer().dropMessage(1, "Voce foi banido desta loja.");
                            return;
                        }
                    }
                    if (ips.getFreeSlot() == -1) {
                        c.getSession().write(MaplePacketCreator.getMiniBoxFull());
                        return;
                    }
                    c.getPlayer().setInteraction(ips);
                    ips.addVisitor(c.getPlayer());
                    c.getSession().write(MaplePacketCreator.getInteraction(c.getPlayer(), false));
                } else if (ob instanceof MapleMiniGame) {
                    MapleMiniGame game = (MapleMiniGame) ob;
                    if (game.hasFreeSlot() && !game.isVisitor(c.getPlayer())) {
                        if (game.getGameType().equals("omok")) {
                            game.addVisitor(c.getPlayer());
                            c.getPlayer().setMiniGame(game);
                            game.sendOmok(c, game.getPieceType());
                        }
                        if (game.getGameType().equals("matchcard")) {
                            game.addVisitor(c.getPlayer());
                            c.getPlayer().setMiniGame(game);
                            game.sendMatchCard(c, game.getPieceType());
                        }
                    } else
                        c.getPlayer().getClient().getSession().write(MaplePacketCreator.getMiniGameFull());
                }
            }
        } else if (mode == Action.CHAT.getCode()) { // Chat
            if (c.getPlayer().getTrade() != null) {
                c.getPlayer().getTrade().chat(slea.readMapleAsciiString());
            } else if (c.getPlayer().getPlayerShop() != null) { //mini game
                MaplePlayerShop shop = c.getPlayer().getPlayerShop();
                if (shop != null) {
                    shop.chat(c, slea.readMapleAsciiString());
                }
            } else if (c.getPlayer().getMiniGame() != null) {
                MapleMiniGame game = c.getPlayer().getMiniGame();
                if (game != null) {
                    game.chat(c, slea.readMapleAsciiString());
                }
            } else if (c.getPlayer().getInteraction() != null) {
                IPlayerInteractionManager ips = c.getPlayer().getInteraction();
                String message = slea.readMapleAsciiString();
                CommandProcessor.getInstance().processCommand(c, message);
                ips.broadcast(MaplePacketCreator.shopChat(c.getPlayer().getName() + " : " + message, ips.isOwner(c.getPlayer()) ? 0 : ips.getVisitorSlot(c.getPlayer()) + 1), true);
            }
       } else if (mode == Action.EXIT.getCode()) {
            if (c.getPlayer().getTrade() != null) {
                MapleTrade.cancelTrade(c.getPlayer());
            } else {
                IPlayerInteractionManager ips = c.getPlayer().getInteraction();
                MapleMiniGame game = c.getPlayer().getMiniGame();
                c.getPlayer().setInteraction(null);
                if (ips != null) {
                    if (ips.isOwner(c.getPlayer())) {
                        if (ips.getShopType() == 2) {
                            boolean save = false;
                            for (MaplePlayerShopItem items : ips.getItems()) {
                                if (items.getBundles() > 0) {
                                    StringBuilder logInfo = new StringBuilder("Returning items not sold in ");
                                    IItem item = items.getItem();
                                    item.setQuantity(items.getBundles());
                                    if (MapleInventoryManipulator.addFromDrop(c, item, logInfo.toString(), false)) {
                                        items.setBundles((short) 0);
                                    } else {
                                        save = true;
                                        break;
                                    }
                                }
                            }
                            ips.removeAllVisitors(3, 1);
                            ips.closeShop(save);
                        } else if (ips.getShopType() == 1) {
                            c.getSession().write(MaplePacketCreator.shopVisitorLeave(0));
                        } else if (ips.getShopType() == 3 || ips.getShopType() == 4) {
                            ips.removeAllVisitors(3, 1);
                        }
                    } else {
                        ips.removeVisitor(c.getPlayer());
                    }
                }  else if (game != null) {
                    c.getPlayer().setMiniGame(null);
                    if (game.isOwner(c.getPlayer())) {
                        c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.removeCharBox(c.getPlayer()));
                        game.broadcastToVisitor(MaplePacketCreator.getMiniGameClose((byte) 0));
                    } else
                        game.removeVisitor(c.getPlayer());
                }
            }
        } else if (mode == Action.OPEN.getCode()) {
            IPlayerInteractionManager shop = c.getPlayer().getInteraction();
            if (shop != null && shop.isOwner(c.getPlayer())) {
                c.getPlayer().getMap().addMapObject((PlayerInteractionManager) shop);
                if (shop.getShopType() == 1) {
                    HiredMerchant merchant = (HiredMerchant) shop;
                    c.getPlayer().setHasMerchant(true);
                    merchant.setOpen(true);
                    c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.spawnHiredMerchant(merchant));
                    c.getPlayer().setInteraction(null);
                } else if (shop.getShopType() == 2) {
                    c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.sendInteractionBox(c.getPlayer()));
                }
                slea.readByte();
            }
        } else if (mode == Action.READY.getCode()) {
            MapleMiniGame game = c.getPlayer().getMiniGame();
            game.broadcast(MaplePacketCreator.getMiniGameReady(game));
        } else if (mode == Action.UN_READY.getCode()) {
            MapleMiniGame game = c.getPlayer().getMiniGame();
            game.broadcast(MaplePacketCreator.getMiniGameUnReady(game));
        } else if (mode == Action.START.getCode()) {
            MapleMiniGame game = c.getPlayer().getMiniGame();
            if (game.getGameType().equals("omok")) {
                game.broadcast(MaplePacketCreator.getMiniGameStart(game, game.getLoser()));
                c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.addOmokBox(game.getOwner(), 2, 1));
            }
            if (game.getGameType().equals("matchcard")) {
                game.shuffleList();
                game.broadcast(MaplePacketCreator.getMatchCardStart(game, game.getLoser()));
                c.getPlayer().getMap().broadcastMessage(MaplePacketCreator.addMatchCardBox(game.getOwner(), 2, 1));
            }
        } else if (mode == Action.GIVE_UP.getCode()) {
           MapleMiniGame game = c.getPlayer().getMiniGame();
            if (game.getGameType().equals("omok"))
                if (game.isOwner(c.getPlayer()))
                    game.broadcast(MaplePacketCreator.getMiniGameOwnerForfeit(game));
                else
                    game.broadcast(MaplePacketCreator.getMiniGameVisitorForfeit(game));
            if (game.getGameType().equals("matchcard"))
                if (game.isOwner(c.getPlayer())) {
                    game.broadcast(MaplePacketCreator.getMatchCardVisitorWin(game));
                } else {
                    game.broadcast(MaplePacketCreator.getMatchCardOwnerWin(game));
                }
        } else if (mode == Action.REQUEST_TIE.getCode()) {
             MapleMiniGame game = c.getPlayer().getMiniGame();
            if (game.isOwner(c.getPlayer())) {
                game.broadcastToVisitor(MaplePacketCreator.getMiniGameRequestTie(game));
            } else {
                game.getOwner().getClient().getSession().write(MaplePacketCreator.getMiniGameRequestTie(game));
            }
        } else if (mode == Action.ANSWER_TIE.getCode()) {
            MapleMiniGame game = c.getPlayer().getMiniGame();
            int type = slea.readByte();
            if (game.getGameType().equals("omok"))
                game.broadcast(MaplePacketCreator.getMiniGameTie(game));
            if (game.getGameType().equals("matchcard"))
                game.broadcast(MaplePacketCreator.getMatchCardTie(game));
        } else if (mode == Action.SKIP.getCode()) {
            MapleMiniGame game = c.getPlayer().getMiniGame();
            if (game.isOwner(c.getPlayer())) {
                game.broadcast(MaplePacketCreator.getMiniGameSkipOwner(game));
            } else {
                game.broadcast(MaplePacketCreator.getMiniGameSkipVisitor(game));
            }
        } else if (mode == Action.MOVE_OMOK.getCode()) {
            int x = slea.readInt(); // x point
            int y = slea.readInt(); // y point
            int type = slea.readByte(); // piece ( 1 or 2; Owner has one piece, visitor has another, it switches every game.)
            c.getPlayer().getMiniGame().setPiece(x, y, type, c.getPlayer());
        } else if (mode == Action.SELECT_CARD.getCode()) {
            int turn = slea.readByte(); // 1st turn = 1; 2nd turn = 0
            int slot = slea.readByte(); // slot
            MapleMiniGame game = c.getPlayer().getMiniGame();
            int firstslot = game.getFirstSlot();
            if (turn == 1) {
                game.setFirstSlot(slot);
                if (game.isOwner(c.getPlayer()))
                    game.broadcastToVisitor(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, turn));
                else
                    game.getOwner().getClient().getSession().write(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, turn));
            } else if ((game.getCardId(firstslot + 1)) == (game.getCardId(slot + 1)))
                if (game.isOwner(c.getPlayer())) {
                    game.broadcast(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, 2));
                    game.setOwnerPoints();
                } else {
                    game.broadcast(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, 3));
                    game.setVisitorPoints();
                }
            else if (game.isOwner(c.getPlayer()))
                game.broadcast(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, 0));
            else
                game.broadcast(MaplePacketCreator.getMatchCardSelect(game, turn, slot, firstslot, 1));
        } else if (mode == Action.SET_MESO.getCode()) {
            c.getPlayer().getTrade().setMeso(slea.readInt());
        } else if (mode == Action.SET_ITEMS.getCode()) {
            MapleItemInformationProvider ii = MapleItemInformationProvider.getInstance();
            MapleInventoryType ivType = MapleInventoryType.getByType(slea.readByte());
            IItem item = c.getPlayer().getInventory(ivType).getItem((byte) slea.readShort());
            long checkq = slea.readShort();
            short quantity = (short)(int)checkq;
            byte targetSlot = slea.readByte();
            if (c.getPlayer().getTrade() != null && item != null) {
                if (checkq > 4000) {
                    AutobanManager.getInstance().autoban(c, "" + Mensagens.Nome_Server + " | PE esta em troca.");
                }
               if ((quantity <= item.getQuantity() && quantity >= 0) || ii.isThrowingStar(item.getItemId()) || ii.isBullet(item.getItemId())) {
                    if (!c.getChannelServer().allowUndroppablesDrop() && ii.isDropRestricted(item.getItemId())) {
                        c.getSession().write(MaplePacketCreator.enableActions());
                        return;
                    }
                    IItem tradeItem = item.copy();
                    if (ii.isThrowingStar(item.getItemId()) || ii.isBullet(item.getItemId())) {
                        tradeItem.setQuantity(item.getQuantity());
                        MapleInventoryManipulator.removeFromSlot(c, ivType, item.getPosition(), item.getQuantity(), true);
                    } else {
                        tradeItem.setQuantity(quantity);
                        MapleInventoryManipulator.removeFromSlot(c, ivType, item.getPosition(), quantity, true);
                    }
                    tradeItem.setPosition(targetSlot);
                    c.getPlayer().getTrade().addItem(tradeItem);
                    return;
                }
            }
        } else if (mode == Action.CONFIRM.getCode()) {
            MapleTrade.completeTrade(c.getPlayer());
        } else if (mode == Action.ADD_ITEM.getCode() || mode == Action.PUT_ITEM.getCode()) {
            MapleInventoryType type = MapleInventoryType.getByType(slea.readByte());
            byte slot = (byte) slea.readShort();
            short bundles = slea.readShort();
            short perBundle = slea.readShort();
            int price = slea.readInt();
            IItem ivItem = c.getPlayer().getInventory(type).getItem(slot);
            IItem sellItem = ivItem.copy();
            sellItem.setQuantity(perBundle);
            MaplePlayerShopItem item = new MaplePlayerShopItem(sellItem, bundles, price);
            IPlayerInteractionManager shop = c.getPlayer().getInteraction();
            long checkquantity = bundles * perBundle;
            int checkiquantity = bundles * perBundle;
            short checksmquantity = (short)(bundles * perBundle);
            if (shop != null && shop.isOwner(c.getPlayer())) {
                if (ivItem != null && ivItem.getQuantity() >= bundles * perBundle) {
                    if (price < 0) {
                        AutobanManager.getInstance().autoban(c, "" + Mensagens.Nome_Server + " | PE Adicionar um item com preco negativo.");
                        return;
                    }
                    if (bundles <= 0 || perBundle <= 0 || checkquantity > 20000 || checksmquantity < 0 || checkiquantity < 0 || checkiquantity > 20000) {
                        AutobanManager.getInstance().autoban(c, "" + Mensagens.Nome_Server + " | PE Item de Loja : " + sellItem.getItemId());
                        return;
                    }
                    if (bundles > 10 || perBundle > 4000) return;
                    MapleItemInformationProvider ii = MapleItemInformationProvider.getInstance();
                    if (ii.isThrowingStar(ivItem.getItemId()) || ii.isBullet(ivItem.getItemId())) {
                        MapleInventoryManipulator.removeFromSlot(c, type, slot, ivItem.getQuantity(), true);
                    } else {
                        MapleInventoryManipulator.removeFromSlot(c, type, slot, (short) (bundles * perBundle), true);
                    }
                    shop.addItem(item);
                    c.getSession().write(MaplePacketCreator.shopItemUpdate(shop));
                }
            }
         } else if (mode == Action.BUY.getCode() || mode == Action.MERCHANT_BUY.getCode()) {
            int item = slea.readByte();
            short quantity = slea.readShort();
            IPlayerInteractionManager shop = c.getPlayer().getInteraction();
            shop.buy(c, item, quantity);
            shop.broadcast(MaplePacketCreator.shopItemUpdate(shop), true);
        } else if (mode == Action.TAKE_ITEM_BACK.getCode() || mode == Action.REMOVE_ITEM.getCode()) {
            int slot = slea.readShort();
            IPlayerInteractionManager shop = c.getPlayer().getInteraction();
            if (!shop.isOwner(c.getPlayer())) {
                AutobanManager.getInstance().autoban(c, "" + Mensagens.Nome_Server + " | Tentar remover item de : " + shop.getOwnerName());
                return;
            }
            if (shop != null && shop.isOwner(c.getPlayer())) {
                MaplePlayerShopItem item = shop.getItems().get(slot);
                if (item.getBundles() > 0) {
                    IItem iitem = item.getItem();
                    iitem.setQuantity(item.getBundles());
                    MapleInventoryManipulator.addFromDrop(c, iitem, "");
                }
                shop.removeFromSlot(slot);
                c.getSession().write(MaplePacketCreator.shopItemUpdate(shop));
            }
        } else if (mode == Action.CLOSE_MERCHANT.getCode()) {
            IPlayerInteractionManager merchant = c.getPlayer().getInteraction();
            if (merchant != null && merchant.getShopType() == 1 && merchant.isOwner(c.getPlayer())) {
                boolean save = false;
                for (MaplePlayerShopItem items : merchant.getItems()) {
                    if (items.getBundles() > 0) {
                        IItem item = items.getItem();
                        item.setQuantity(items.getBundles());
                        if (MapleInventoryManipulator.addFromDrop(c, item, "")) {
                            items.setBundles((short) 0);
                        } else {
                            save = true;
                            break;
                        }
                    }
                }
                c.getSession().write(MaplePacketCreator.shopErrorMessage(0x10, 0));
                merchant.closeShop(save);
                c.getPlayer().setInteraction(null);
                c.getPlayer().setHasMerchant(false);
            }
        } else if (mode == Action.MAINTENANCE_OFF.getCode()) {
            HiredMerchant merchant = (HiredMerchant) c.getPlayer().getInteraction();
            if (merchant != null && merchant.isOwner(c.getPlayer())) {
                merchant.setOpen(true);
                merchant.tempItemsUpdate();
            }
        } else if (mode == Action.BAN_PLAYER.getCode()) {
            IPlayerInteractionManager imps = c.getPlayer().getInteraction();
            if (imps != null && imps.isOwner(c.getPlayer())) {
                ((MaplePlayerShop) imps).banPlayer(slea.readMapleAsciiString());
            }
        } else if (mode == Action.MERCHANT_ORGANIZE.getCode()) {
            IPlayerInteractionManager imps = c.getPlayer().getInteraction();
            for (int i = 0; i < imps.getItems().size(); i++) {
                if (imps.getItems().get(i).getBundles() == 0) {
                    imps.removeFromSlot(i);
                }
            }
            c.getSession().write(MaplePacketCreator.shopItemUpdate(imps));
        }
    }
}