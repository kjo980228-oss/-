/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package net.channel.handler;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;

import client.BuddylistEntry;
import client.CharacterNameAndId;
import client.MapleCharacter;
import client.MapleClient;
import client.MaplePet;
import client.MapleStat;
import client.PetDataFactory;
import client.SkillFactory;
import config.configuracoes.mensagens.Mensagens;
import database.DatabaseConnection;
import java.awt.Point;
import java.util.ArrayList;
import net.AbstractMaplePacketHandler;
import net.channel.ChannelServer;
import net.channel.PetStorage;
import net.world.CharacterIdChannelPair;
import net.world.MaplePartyCharacter;
import net.world.PartyOperation;
import net.world.PlayerBuffValueHolder;
import net.world.PlayerCoolDownValueHolder;
import net.world.guild.MapleAlliance;
import net.world.remote.WorldChannelInterface;
import tools.MaplePacketCreator;
import tools.Pair;
import tools.data.LittleEndianAccessor;

public class PlayerLoggedinHandler extends AbstractMaplePacketHandler {

	@Override
	public boolean validateState(MapleClient c) {
		return !c.isLoggedIn();
	}

	@Override
	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
		int cid = slea.readInt();
		MapleCharacter player = c.getChannelServer().getPlayerStorage().getCharacterById(cid);
		if (player == null) {
                try {
                    player = MapleCharacter.loadCharFromDB(cid, c, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                } else {
                    player.channelChanged(c);
                }
                if (!hasCharOnAccount(player.getName(), c.getAccountName())) { 
                    c.getPlayer().ban("Hacker Remoto!", true); 
                    return; 
                }
                if (player == null) { 
        	c.disconnect(true, false);
        	return;
                }
                
                c.setPlayer(player);
               	c.setAccID(player.getAccountID());
                
		int state = c.getLoginState();
		boolean allowLogin = true;
		ChannelServer channelServer = c.getChannelServer();
                synchronized (this) {
                try {
                WorldChannelInterface worldInterface = channelServer.getWorldInterface();
                    if (state == MapleClient.LOGIN_SERVER_TRANSITION) {
                        for (String charName : c.loadCharacterNames(c.getWorld())) {
                            if (worldInterface.isConnected(charName)) {
                                MapleCharacter player_to_dc = player.getClient().getChannelServer().getPlayerStorage().getCharacterByName(charName);
                                player_to_dc.getClient().disconnect();
                                player_to_dc.getClient().getSession().close();
                                player_to_dc.getMap().removePlayer(player_to_dc);
                                allowLogin = false;
                                break;
                            }
                        }
                    } 
                } catch (RemoteException e) {
                    channelServer.reconnectWorld();
                    allowLogin = false;
                    e.printStackTrace();
                    System.out.println("WORLD SERVER HAS CRASHED.");
                }

                if (state != MapleClient.LOGIN_SERVER_TRANSITION || !allowLogin) {
                    c.setPlayer(null);
                    c.getSession().close();
                    return;
                }
                c.updateLoginState(MapleClient.LOGIN_LOGGEDIN);
                }
           
		ChannelServer cserv = ChannelServer.getInstance(c.getChannelByWorld());
		cserv.addPlayer(player);
		try {
			WorldChannelInterface wci = ChannelServer.getInstance(c.getChannelByWorld()).getWorldInterface();
			List<PlayerBuffValueHolder> buffs = wci.getBuffsFromStorage(cid);
			if (buffs != null) {
				c.getPlayer().silentGiveBuffs(buffs);
			}
			List<PlayerCoolDownValueHolder> cooldowns = wci.getCooldownsFromStorage(cid);
			if (cooldowns != null) {
				c.getPlayer().giveCoolDowns(cooldowns);
			}
		} catch (RemoteException e) {
			c.getChannelServer().reconnectWorld();
		}
		
               c.getSession().write(MaplePacketCreator.getCharInfo(player));
               
               if (player.isGM()) {
               player.Hide(true, true);
               SkillFactory.getSkill(9101004).getEffect(1).applyTo(player, true, true);
               player.setChatMode(1);
               }
		player.getMap().addPlayer(player);
		try {
		Collection<BuddylistEntry> buddies = player.getBuddylist().getBuddies();
		int buddyIds[] = player.getBuddylist().getBuddyIds();
                cserv.getWorldInterface().loggedOn(player.getName(), player.getId(), c.getChannel(), buddyIds);
		CharacterIdChannelPair[] onlineBuddies = cserv.getWorldInterface().multiBuddyFind(player.getId(), buddyIds);
			for (CharacterIdChannelPair onlineBuddy : onlineBuddies) {
				BuddylistEntry ble = player.getBuddylist().get(onlineBuddy.getCharacterId());
				ble.setChannel(onlineBuddy.getChannel());
				player.getBuddylist().put(ble);
		}
                c.announce(MaplePacketCreator.updateBuddylist(buddies));
                
                if (player.getParty() != null) {
                    MaplePartyCharacter pchar = player.getMPC();
                    pchar.setChannel(c.getChannel());
                    pchar.setMapId(player.getMapId());
                    pchar.setOnline(true);
                    cserv.getWorldInterface().updateParty(player.getParty().getId(), PartyOperation.LOG_ONOFF, pchar);
                }
                
                c.getPlayer().updatePartyMemberHP();
		c.getPlayer().sendMacros();
                c.getPlayer().showNote();
                
	        if (player.getGuildId() > 0) {
                c.getChannelServer().getWorldInterface().setGuildMemberOnline(player.getMGC(), true, c.getChannel());
                c.announce(MaplePacketCreator.showGuildInfo(player));
                int allianceId = player.getGuild().getAllianceId();
                if (allianceId > 0) {
                    MapleAlliance newAlliance = channelServer.getWorldInterface().getAlliance(allianceId);
                    if (newAlliance == null) {
                        newAlliance = MapleAlliance.loadAlliance(allianceId);
                        channelServer.getWorldInterface().addAlliance(allianceId, newAlliance);
                    }
                    c.announce(MaplePacketCreator.getAllianceInfo(newAlliance));
                    c.announce(MaplePacketCreator.getGuildAlliances(newAlliance, c));
                    c.getChannelServer().getWorldInterface().allianceMessage(allianceId, MaplePacketCreator.allianceMemberOnline(player, true), player.getId(), -1);
                    }
                  }
                } catch (RemoteException e) {
                  e.printStackTrace();
                  channelServer.reconnectWorld();
                }
                
		c.getPlayer().sendKeymap();
                
		CharacterNameAndId pendingBuddyRequest = player.getBuddylist().pollPendingRequest();
		if (pendingBuddyRequest != null) {
			player.getBuddylist().put(new BuddylistEntry(pendingBuddyRequest.getName(), pendingBuddyRequest.getId(), -1, false));
			c.announce(MaplePacketCreator.requestBuddylistAdd(pendingBuddyRequest.getId(), pendingBuddyRequest.getName()));
		}

                c.getPlayer().checkMessenger();
		c.getPlayer().checkBerserk();
                c.getPlayer().expirationTask();
                player.dropOverheadMessage(Mensagens.Jogador_Logado);
                
                if (player.getLevel() <= 8) {
                 c.announce(MaplePacketCreator.getWhisper("[" + Mensagens.Nome_Server +" Informa]", 1, Mensagens.Jogador_Iniciante));
                }
                if (player.getClient().getChannelServer().eventOn == true) {
                 c.announce(MaplePacketCreator.getWhisper("[" + Mensagens.Nome_Server +" Informa]", 1, player.getName() + " " + Mensagens.Jogador_Evento));
                }
                if (player.getClient().getChannelServer().getExpRate() > 2 || player.getClient().getChannelServer().getMesoRate() > 1 || player.getClient().getChannelServer().getDropRate() > 1) {
                 c.announce(MaplePacketCreator.getWhisper("[" + Mensagens.Nome_Server +" Informa]", 1, player.getName() + " " + Mensagens.Jogador_Evento_EMD + " Exp." + player.getClient().getChannelServer().getExpRate() + "x | Meso. " + player.getClient().getChannelServer().getMesoRate() + "x | Drop. " + player.getClient().getChannelServer().getDropRate() + "x>"));
                }
                if (c.getPlayer().getMapId() == 0 && c.getPlayer().getLevel() == 1) {
                c.getChannelServer().yellowWorldMessage("[Boas-vindas] O jogador <" + c.getPlayer().getName() + "> " + Mensagens.Novo_Jogador);
                }
                if (!c.hasVotedAlready()){
            	player.dropMessage("Ol�, voc� ainda n�o \"votou\" hoje? Que tal votar e receber recompensas?");
                player.dropMessage("Acesse - www.leaderms.com.br e clique em \"Votar\"!");
                }
                if (player.getLevel() <= 8) {
                        player.giveItemBuff(2022118);
                        player.giveItemBuff(4101004);
                        player.giveItemBuff(2301004);
                        c.getSession().write(MaplePacketCreator.serverNotice(5, Mensagens.Jogador_Buffado));
                }
                
                c.announce(MaplePacketCreator.updateGender(player));
                
                MaplePet[] petz = PetStorage.getPetz(player.getId());
                if (petz != null) {
                    for (int i = 0; i < 3; i++) {
                        if (petz[i] != null) {
                            MaplePet pet = petz[i];
                            if (c.getPlayer().getPetIndex(pet) != -1) {
                                c.getPlayer().unequipPet(pet, true);
                            } else {
                                if (c.getPlayer().getSkillLevel(SkillFactory.getSkill(8)) == 0 && c.getPlayer().getPet(0) != null) {
                                    c.getPlayer().unequipPet(c.getPlayer().getPet(0), false);
                                }
                                Point pos = c.getPlayer().getPosition();
                                pos.y -= 12;
                                pet.setPos(pos);
                                pet.setFh(c.getPlayer().getMap().getFootholds().findBelow(pet.getPos()).getId());
                                pet.setStance(0);
                                c.getPlayer().addPet(pet);
                                c.getPlayer().getMap().broadcastMessage(c.getPlayer(), MaplePacketCreator.showPet(c.getPlayer(), pet, false), true);
                                int uniqueid = pet.getUniqueId();
                                List<Pair<MapleStat, Integer>> stats = new ArrayList<Pair<MapleStat, Integer>>();
                                stats.add(new Pair<MapleStat, Integer>(MapleStat.PET, Integer.valueOf(uniqueid)));
                                c.getSession().write(MaplePacketCreator.petStatUpdate(c.getPlayer()));
                                c.getSession().write(MaplePacketCreator.enableActions());
                                int hunger = PetDataFactory.getHunger(pet.getItemId());
                                c.getPlayer().startFullnessSchedule(hunger, pet, c.getPlayer().getPetIndex(pet));

                            }
                        }
                    }
                }       
             }
        
            private boolean hasCharOnAccount(String name, String accountName) { 
            boolean hasChar = true; 
            int accountid = 0; 
            Connection con = DatabaseConnection.getConnection(); 
            try { 
                PreparedStatement ps = con.prepareStatement("SELECT * FROM accounts WHERE name = ?"); 
                ps.setString(1, accountName); 
                ResultSet rs = ps.executeQuery(); 
                if (rs.next()) { 
                    accountid = rs.getInt("id"); 
                    ps.close(); 
                    ps = con.prepareStatement("SELECT * FROM characters where accountid = ? && name = ?"); 
                    ps.setInt(1, accountid); 
                    ps.setString(2, name); 
                    rs = ps.executeQuery(); 
                    return rs.next(); 
                } 
                rs.close(); 
                ps.close(); 
            } catch (SQLException e) { 
                e.printStackTrace(); 
            } finally { 
                return hasChar; 
            } 
      }  
}


