package net.channel.handler;

import client.MapleClient;
import net.AbstractMaplePacketHandler;
import tools.data.LittleEndianAccessor;
import java.sql.*;
import client.MapleCharacter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


//import java.sql.PreparedStatement;
import database.DatabaseConnection;
import java.rmi.RemoteException;
import net.channel.ChannelServer;
import net.world.remote.WorldChannelInterface;
import tools.MaplePacketCreator;

public class ReportHandler extends AbstractMaplePacketHandler {
    final static int GMGuildId = 198;
    
    final String[] reasons = {
        "Hacking",
        "Botting",
        "Scamming",
        "Fake GM",
        "Harassment",
        "Advertising"
    };

	@Override public void handlePacket(LittleEndianAccessor slea, MapleClient c)  {
		int reportedCharId = slea.readInt();
        byte reason = slea.readByte();
        String chatlog = "No chatlog";
        short clogLen = slea.readShort();
        if (clogLen > 0) {
            chatlog = slea.readAsciiString(clogLen);
        }
        System.out.println(c.getPlayer().getName() + " reportou o charid - " + reportedCharId);
        int cid = reportedCharId;

        if (addReportEntry(c.getPlayer().getId(), reportedCharId, reason, chatlog)) {
            c.getSession().write(MaplePacketCreator.reportReply((byte) 0));
        } else {
            c.getSession().write(MaplePacketCreator.reportReply((byte) 4));
        }
        try {
            WorldChannelInterface wci = c.getChannelServer().getWorldInterface();
            wci.broadcastGMMessage(null, MaplePacketCreator.serverNotice(5, c.getPlayer().getName() + " reportou " + MapleCharacter.getNameById(cid) + " por " + reasons[reason] + ".").getBytes());
        } catch (RemoteException ex) {
            c.getChannelServer().reconnectWorld();
        }
    }
        
	public boolean addReportEntry(int reporterId, int victimId, byte reason, String chatlog) {
		try {
		Connection dcon = DatabaseConnection.getConnection();
		PreparedStatement ps;
		ps = dcon.prepareStatement("INSERT INTO reports VALUES (NULL, CURRENT_TIMESTAMP, ?, ?, ?, ?, 'UNHANDLED')");
		ps.setInt(1, reporterId);
		ps.setInt(2, victimId);
		ps.setInt(3, reason);
		ps.setString(4, chatlog);
		ps.executeUpdate();
		ps.close();
		} catch (Exception ex){
		   return false;
		}
	    return true;
	}
}
