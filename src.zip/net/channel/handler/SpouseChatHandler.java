package net.channel.handler;

import java.rmi.RemoteException;
import client.MapleCharacter;
import client.MapleClient;
import client.messages.CommandProcessor;
import net.AbstractMaplePacketHandler;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;


public class SpouseChatHandler extends AbstractMaplePacketHandler {
    @Override
    public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
    //    System.out.println(slea.toString());
        slea.readMapleAsciiString();//recipient
        String msg = slea.readMapleAsciiString();
        if (!CommandProcessor.getInstance().processCommand(c, msg)) 
            if (c.getPlayer().isMarried()) {
                MapleCharacter wife = c.getChannelServer().getPlayerStorage().getCharacterById(c.getPlayer().getPartnerId());
                if (wife != null) {
                    wife.getClient().getSession().write(MaplePacketCreator.OnCoupleMessage(c.getPlayer().getName(), msg, true));
                    c.getSession().write(MaplePacketCreator.OnCoupleMessage(c.getPlayer().getName(), msg, true));
                } else
                    try {
                        if (c.getChannelServer().getWorldInterface().isConnected(wife.getName())) {
                            c.getChannelServer().getWorldInterface().sendSpouseChat(c.getPlayer().getName(), wife.getName(), msg);
                            c.getSession().write(MaplePacketCreator.OnCoupleMessage(c.getPlayer().getName(), msg, true));
                        } else
                            c.getPlayer().dropMessage(6, "You are either not married or your spouse is currently offline.");
                    } catch (Exception e) {
                        c.getPlayer().dropMessage(6, "You are either not married or your spouse is currently offline.");
                        c.getChannelServer().reconnectWorld();
                    }
            }
    }
}
