package net.channel.handler;

import client.ISkill;
import java.util.ArrayList;
import java.util.List;
import client.MapleCharacter;
import client.MapleClient;
import client.SkillFactory;
import client.anticheat.CheatingOffense;
import client.status.MonsterStatusEffect;
import java.util.Collection;
import net.AbstractMaplePacketHandler;
import server.MapleStatEffect;
import server.life.MapleMonster;
import server.maps.MapleSummon;
import tools.MaplePacketCreator;
import tools.data.LittleEndianAccessor;


public final class SummonDamageHandler extends AbstractMaplePacketHandler {
    private static org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(SummonDamageHandler.class);
    
	public final class SummonAttackEntry {
		private int monsterOid;
		private int damage;

		public SummonAttackEntry(int monsterOid, int damage) {
			this.monsterOid = monsterOid;
			this.damage = damage;
		}

		public int getMonsterOid() {
			return monsterOid;
		}

		public int getDamage() {
			return damage;
		}
	}

	public void handlePacket(LittleEndianAccessor slea, MapleClient c) {
                //System.out.println(slea.toString());
		int oid = slea.readInt();
		MapleCharacter player = c.getPlayer();
		if (!player.isAlive()) {
			return;
		}
                Collection<MapleSummon> summons = player.getSummons().values();
                MapleSummon summon = null;
                for (MapleSummon sum : summons) {
                        if (sum.getObjectId() == oid) {
                                summon = sum;
                        }
                }
		if (summon == null) {
			return;
		}
		ISkill summonSkill = SkillFactory.getSkill(summon.getSkill());
		MapleStatEffect summonEffect = summonSkill.getEffect(summon.getSkillLevel());
		slea.skip(5);
		List<SummonAttackEntry> allDamage = new ArrayList<SummonAttackEntry>();
		int numAttacked = slea.readByte();
		for (int x = 0; x < numAttacked; x++) {
                        slea.skip(8);
			int monsterOid = slea.readInt(); // attacked oid
			slea.skip(14); // who knows (used to be 14 pre-83)
			int damage = slea.readInt();
			allDamage.add(new SummonAttackEntry(monsterOid, damage));
		}
		if (!player.isAlive()) {
			player.getCheatTracker().registerOffense(CheatingOffense.ATTACKING_WHILE_DEAD);
			return;
		}
		player.getMap().broadcastMessage(player, MaplePacketCreator.summonAttack(player.getId(), summon.getSkill(), 4, allDamage), summon.getPosition());
		for (SummonAttackEntry attackEntry : allDamage) {
			int damage = attackEntry.getDamage();
			MapleMonster target = player.getMap().getMonsterByOid(attackEntry.getMonsterOid());
			if (target != null) {
				if (damage > 0 && summonEffect.getMonsterStati().size() > 0) {
					if (summonEffect.makeChanceResult()) {
						target.applyStatus(player, new MonsterStatusEffect(summonEffect.getMonsterStati(), summonSkill, false), summonEffect.isPoison(), 4000);
					}
				}
				player.getMap().damageMonster(player, target, damage);
			}
		}
	}
}
