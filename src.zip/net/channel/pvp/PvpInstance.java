/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * This file is part of the "Renoria" Game.
 * Copyright (C) 2008
 * IDGames.
 */

package net.channel.pvp;

/**
 *
 * @author David
 */
public class PvpInstance {
	
}
