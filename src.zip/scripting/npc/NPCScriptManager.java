package scripting.npc;

import java.util.List;
import java.util.Map;
import javax.script.Invocable;
import client.MapleClient;
import client.MapleCharacter;
import client.ScriptDebug;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.WeakHashMap;
import net.world.MaplePartyCharacter;
import scripting.AbstractScriptManager;
import tools.FilePrinter;
import tools.MaplePacketCreator;

/**
 *
 * @author Matze
 */
public class NPCScriptManager extends AbstractScriptManager {

    private final Map<MapleClient, NPCConversationManager> cms = new WeakHashMap<>();
    private final Map<MapleClient, NPCScript> scripts = new WeakHashMap<>();
     private static final NPCScriptManager instance = new NPCScriptManager();

    public static final NPCScriptManager getInstance() {
	return instance;
    }

  public void start(String filename, MapleClient c, int npc, List<MaplePartyCharacter> chrs) {
        try {
            NPCConversationManager cm = new NPCConversationManager(c, npc, chrs, 0);
            cm.dispose();
            if (cms.containsKey(c)) {
                return;
            }
            if (c.canClickNPC()) {
            cms.put(c, cm);
            Invocable iv = getInvocable("npc/" + filename + ".js", c);
            NPCScriptManager npcsm = NPCScriptManager.getInstance();

            if (iv == null || NPCScriptManager.getInstance() == null) {
                cm.dispose();
                return;
            }
            if (iv == null || npcsm == null) {
                cm.dispose();
                return;
            }
            engine.put("cm", cm);
            NPCScript ns = iv.getInterface(NPCScript.class);
            scripts.put(c, ns);
	    ns.start(chrs);
            c.setClickedNPC();
           }  else {
                c.announce(MaplePacketCreator.enableActions());
            }
          } catch (Exception e) {
            FilePrinter.printError(FilePrinter.NPC + npc + ".txt", e);
            dispose(c);
            cms.remove(c);
        }		
}
  

       public void start(MapleClient c, int npc, String filename, MapleCharacter chr) {
        try {
            NPCConversationManager cm = new NPCConversationManager(c, npc);
            if (cms.containsKey(c)) {
                return;
            }
            if (c.canClickNPC()) { 
            cms.put(c, cm);
            Invocable iv = null;
            String path = "";
            if (filename != null) {
                path = "npc/" + filename + ".js";
                iv = getInvocable("npc/" + filename + ".js", c);
            }
            if (iv == null) {
                path = "npc/" + npc + ".js";
                iv = getInvocable("npc/" + npc + ".js", c);
            }
            if (iv == null || NPCScriptManager.getInstance() == null) {
                dispose(c);
                return;
            }
            engine.put("cm", cm);
            NPCScript ns = iv.getInterface(NPCScript.class);
            scripts.put(c, ns);
            c.setScriptDebug(new ScriptDebug(c, path, cm));
            c.setClickedNPC();
            if (chr == null) {
                ns.start();
            } else {
                ns.start(chr);
            }
            } else {
                c.announce(MaplePacketCreator.enableActions());
            }
            } catch (UndeclaredThrowableException ute) {
            FilePrinter.printError(FilePrinter.NPC + npc + ".txt", ute);
            dispose(c);
            cms.remove(c);
            notice(c, npc);
        } catch (Exception e) {
            FilePrinter.printError(FilePrinter.NPC + npc + ".txt", e);
            dispose(c);
            cms.remove(c);
            notice(c, npc);
        }
    }

    public void action(MapleClient c, byte mode, byte type, int selection) {
        NPCScript ns = scripts.get(c);
        if (ns != null) {
            try {
                c.setClickedNPC();
                ns.action(mode, type, selection);
            } catch (Exception e) {
                FilePrinter.printError(FilePrinter.NPC + getCM(c).getNpc() + ".txt", e);
                notice(c, getCM(c).getNpc());
                dispose(c);
            }
        }
    }

    public void dispose(NPCConversationManager cm) {
        cms.remove(cm.getC());
        scripts.remove(cm.getC());
        resetContext("npc/" + cm.getNpc() + ".js", cm.getC());
    }

     public void dispose(MapleClient c) {
        if (cms.get(c) != null) {
            dispose(cms.get(c));
        }
    }
     
        private void notice(MapleClient c, int id) {
        if (c != null) {
            c.getPlayer().dropMessage(1, "Ocorreu um erro durante a execu��o deste NPC, reporte aos administradores. (ID: " + id + ")");
        }
    }

    public NPCConversationManager getCM(MapleClient c) {
        return cms.get(c);
    }
}
