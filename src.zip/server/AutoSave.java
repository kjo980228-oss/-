/* 
 * To change this template, choose Tools | Templates 
 * and open the template in the editor. 
 */ 

package server; 

import client.MapleCharacter;
import net.channel.ChannelServer;
import tools.FilePrinter;

/** 
 * 
 * @author JS-Maple
 */ 
public class AutoSave { 
    private static AutoSave instance; 

    public AutoSave() { 
        super(); 
    } 

    public static void main(String[] args) { 
        if (instance == null) return; 
          instance.run(); 
     } 

    public static void run() { 
        for (int i = 0; i < ChannelServer.getAllInstances().size(); i++) { 
            for (MapleCharacter character : ChannelServer.getInstance(i).getPlayerStorage().getAllCharacters()) { 
                if (character == null) continue; 
                try { 
                    character.saveToDB(true, true); 
                } catch (Exception e) { 
                    FilePrinter.printError("Error_SaveAll.txt", e);
                } 
            } 
        } 
    } 

    public static void createInstance(AutoSave inst) { 
        instance = inst; 
    } 

    public static AutoSave getInstance() { 
        return instance; 
    } 
}