/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server;

import java.sql.SQLException;

import database.DatabaseConnection;
import net.channel.ChannelServer;
import server.MapleTimer.AntiCheatTimer;
import server.MapleTimer.CharacterTimer;
import server.MapleTimer.ClientTimer;
import server.MapleTimer.EventTimer;
import server.MapleTimer.ItemTimer;
import server.MapleTimer.MapTimer;
import server.MapleTimer.MiscTimer;
import server.MapleTimer.MonsterTimer;
import server.MapleTimer.MountTimer;
import server.MapleTimer.NPCTimer;
import server.MapleTimer.SkillTimer;
import server.MapleTimer.WLCTimer;

/**
 *
 * @author Frz
 */

public class ShutdownServer implements Runnable {

    private int channel;

    public ShutdownServer(int channel) {
	this.channel = channel;
    }
    
   @Override
  public void run() {
	try {
	    ChannelServer.getInstance(channel).shutdown();
	} catch (Throwable t) {
	    System.err.println("SHUTDOWN ERROR" + t);
	}

        while (ChannelServer.getInstance(channel).getConnectedClients() > 0) {   
	    try {
		Thread.sleep(1000);
	    } catch (InterruptedException e) {
		System.err.println("ERROR" + e);
	    }
	}

	System.out.println("Canal (" + channel + "), cancelamento de registro de canal");

	try {
	    ChannelServer.getWorldRegistry().deregisterChannelServer(channel);
	} catch (Exception e) {
	    // we are shutting down
	}

	System.out.println("Canal (" + channel + "), desvinculando portas...");

	boolean error = true;
	while (error) {
	    try {
		ChannelServer.getInstance(channel).unbind();
		error = false;
	    } catch (Exception e) {
		error = true;
	    }
	}

	System.out.println("Canal (" + channel + "), encerrado...");

	for (ChannelServer cserv : ChannelServer.getAllInstances()) {
	    while (!cserv.hasFinishedShutdown()) {
		try {
		    Thread.sleep(1000);
		} catch (InterruptedException e) {
		    System.err.println("ERROR" + e);
		}
	    }
	}
        
        
	WLCTimer.getInstance().stop();
        MiscTimer.getInstance().stop();   
        ClientTimer.getInstance().stop();   
        MountTimer.getInstance().stop();           
        MonsterTimer.getInstance().stop();    
        ItemTimer.getInstance().stop();   
        MapTimer.getInstance().stop();   
        EventTimer.getInstance().stop();   
        AntiCheatTimer.getInstance().stop();   
        NPCTimer.getInstance().stop();   
        CharacterTimer.getInstance().stop();   
        SkillTimer.getInstance().stop();      
	try {
	    DatabaseConnection.getConnection().close();
	} catch (SQLException e) {
	    System.err.println("THROW" + e);
	}
	System.exit(0);
    }
}
