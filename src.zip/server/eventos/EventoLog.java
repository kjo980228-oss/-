/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventos;

import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * @author JavaScriptz
 * Registro de Eventos
 */
public class EventoLog {
    
    
    public static void setEventLog(int idchar, String eventtype, String name, int timed) {
        Connection con1 = DatabaseConnection.getConnection();
        try {
            PreparedStatement ps;
            ps = con1.prepareStatement("INSERT INTO eventoslog (accountid, eventtype, name, timed) values (?,?,?,?)");
            ps.setInt(1, idchar);
            ps.setString(2, eventtype);
            ps.setString(3, name);
            ps.setInt(4, timed);
            ps.executeUpdate();
            ps.close();
        } catch (Exception Ex) {
        }
    }

}




