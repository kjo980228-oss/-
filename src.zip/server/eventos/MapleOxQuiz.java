/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventos;

import client.ExpTable;
import client.MapleCharacter;
import database.DatabaseConnection;
import java.awt.Point;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import server.MapleTimer.MapTimer;
import server.maps.MapleMap;
import tools.MaplePacketCreator;
import tools.Randomizer;

/**
 * @author JavaScriptz
 */
public class MapleOxQuiz { 
    private static final ArrayList<MapleOxQuizQuestion> allQuestions = new ArrayList<MapleOxQuizQuestion>(); 
    private ArrayList<MapleOxQuizQuestion> availableQuestions = new ArrayList<MapleOxQuizQuestion>(); 
    private MapleMap map; 
    private MapleOxQuizQuestion currentQuestion; 
    private int number; 

    static { 
        loadQuestions(); 
    } 

    public MapleOxQuiz(MapleMap map) { 
        this.map = map; 
        this.availableQuestions = allQuestions; 
        // set first question 
        setQuestion(); 
    } 

    public static void loadQuestions() { 
        allQuestions.clear(); 
        try { 
            PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement("SELECT question, answer, time FROM ox_questions"); 
            ResultSet rs = ps.executeQuery(); 
            while (rs.next()) { 
                allQuestions.add(new MapleOxQuizQuestion(rs.getString("question"), rs.getByte("time"), rs.getBoolean("answer"))); 
            } 
            rs.close(); 
            ps.close(); 
        } catch (SQLException sql) { 
            System.out.println("Failed to load OX question sets"); 
        } 
    } 

    public void sendQuestion() { 
        map.startMapEffect(number + ". " + currentQuestion.question, 5120002, 35000);
        map.broadcastMessage(MaplePacketCreator.getClock(currentQuestion.time));
        map.broadcastMessage(MaplePacketCreator.serverNotice(6, number + ". " + currentQuestion.question)); 
        MapTimer.getInstance().schedule(new Runnable() { 
            @Override 
            public void run() { 
                for (MapleCharacter mc : map.getPlayers()) { 
                    if (mc == null) { 
                        continue; 
                    } 
                    if (!mc.isGM() && !isOnCorrectSide(mc)) { 
                        mc.changeMap(mc.getMap().getReturnMap()); 
                    } 
                } 
                setQuestion();               
                int nonGM = 0; 
                for (MapleCharacter mc : map.getPlayers()) { 
                    if (!mc.isGM()) { 
                        nonGM++; 
                        if (nonGM > 1) { 
                            sendQuestion(); 
                            return; 
                        } 
                    } 
                } 
                map.broadcastMessage(MaplePacketCreator.serverNotice(6, "O evento terminou.")); 
                map.setOx(null);
                map.setOxQuiz(false);
                for (MapleCharacter mc : map.getPlayers()) { 
                    if (!mc.isGM()) { 
                         /* Ganha Exp */
                         int gainFirst = ExpTable.getExpNeededForLevel(mc.getLevel());
                         double realgain = gainFirst * 0.10;
                         mc.gainExp((int) realgain, true, true, false);
                         /* Cash */
                         mc.modifyCSPoints(1, mc.getLevel() * 250);
                         mc.dropMessage("[LeaderMS Quiz] Voc� ganhou " + mc.getLevel() * 250 + " de Cash.");
                         /* Presentes */
                         int chancepresente= (int) (Math.random() * 100);
                         if(chancepresente <= 25) {
                             mc.gainItem(4031442, (short) 1, false, true);
                         } if(chancepresente <= 35) {
                             mc.gainItem(4031440, (short) 1, false, true);
                         }
                    }
                }
                
            } 
        }, currentQuestion.time * 1000); 
    } 

    private boolean isOnCorrectSide(MapleCharacter mc) { 
        Point pos = mc.getPosition(); 
        if (currentQuestion.answer) { 
            return (pos.x >= -142 && mc.getMap().getFootholds().findBelow(mc.getPosition()).getId() != 166 && pos.y > -206); 
        } 
        return (pos.x <= -308 && mc.getMap().getFootholds().findBelow(mc.getPosition()).getId() != 173 && pos.y > -206); 
    } 

    private void setQuestion() { 
        int index = Randomizer.getInstance().nextInt(availableQuestions.size()); 
        currentQuestion = availableQuestions.get(index); 
        availableQuestions.remove(index); 
        number++; 
    } 

    private static class MapleOxQuizQuestion { 
        private final String question; 
        private final int time; 
        private final boolean answer; // is O 

        private MapleOxQuizQuestion(String question, int time, boolean answer) { 
            this.question = question; 
            this.time = time; 
            this.answer = answer; 
        } 
    } 
} 