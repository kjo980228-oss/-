/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventos;

import client.MapleCharacter;
import java.util.Calendar;
import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer;
import server.PropertiesTable;
import server.maps.MapleMap;
import server.maps.MapleMapObject;
import tools.FilePrinter;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 * RoletaRussa Evento
 * LeaderMS 2016
 * @Amoria
 */
public class RoletaRussa {

public static PropertiesTable propriedades;
public ScheduledFuture<?> Tarefa;
private int tempo = 2 * (60 * 1000);
private int aleatorio = 0;
private int leaderpoints = 3;
private boolean existeVencedor = false;
private MapleMap mapaevento;
private int plataforma1 = 0, plataforma2 = 0, plataforma3 = 0, plataforma4 = 0, plataforma5 = 0, plataforma6 = 0, plataforma7 = 0, plataforma8 = 0, plataforma9 = 0;


    public RoletaRussa () {  
        /* Carrega tabela de propriedades */
        RoletaRussa.propriedades = new PropertiesTable();
        /* Seta mapa da Roleta */
        for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            propriedades.setProperty("eventoaberto", Boolean.TRUE);
            mapaevento = cserv.getMapFactory().getMap(670010400);
          //  cserv.broadcastPacket(MaplePacketCreator.serverNotice(6, "[Roleta Russa | Evento] Fale com o Jean (NPC) no canal (" + canal.getChannel() + "), o evento fecha em 2 minutos."));   
        } 
        /* Registra as tarefas */
        Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                          propriedades.setProperty("eventoaberto", Boolean.FALSE);
                          PlataformaAleatoria();
                          GeraNumeroPlataforma();
                        }
            }, tempo);  
           mapaevento.addMapTimer(120);   
    }
    
    public final void PlataformaAleatoria() {
        mapaevento.broadcastMessage(MaplePacketCreator.getClock(15));
        mapaevento.broadcastMessage(MaplePacketCreator.serverNotice(6, "[Roleta Russa | Evento] Escolha uma plataforma antes do tempo acabar."));
        Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() { 
                        mapaevento.broadcastMessage(MaplePacketCreator.serverNotice(6, "[Roleta Russa | Evento] A pr�xima rodada vai come�ar em 15 segundos. Prepare-se!")); 
                        ChecaPlataformaAleatoria();
                     }
        }, 15000);  
    } 
    
    public void GeraNumeroPlataforma() {
         aleatorio = (int) (Math.floor(Math.random() * 9));
         if(aleatorio == 0) aleatorio = 1;
    }
    
    public void LimpaPlataforma() {
        if(plataforma1 > 0) this.plataforma1 = 0;
        if(plataforma2 > 0) this.plataforma2 = 0;
        if(plataforma3 > 0) this.plataforma3 = 0;
        if(plataforma4 > 0) this.plataforma4 = 0;
        if(plataforma5 > 0) this.plataforma5 = 0;
        if(plataforma6 > 0) this.plataforma6 = 0;
        if(plataforma7 > 0) this.plataforma7 = 0;
        if(plataforma8 > 0) this.plataforma8 = 0;
        if(plataforma9 > 0) this.plataforma9 = 0;
        if(existeVencedor == true) this.existeVencedor = false;
     } 
    
    public final void ChecaPlataformaAleatoria() { 
        for (final MapleMapObject o : mapaevento.getAllPlayer()) {
        final double x = ((MapleCharacter)o).getPosition().getX();
        final double y = ((MapleCharacter)o).getPosition().getY();
        boolean randomok = false, estanobox = false;
        
        if (x > 1428 && x < 1501 && y == 49) { // plataforma 1
               this.plataforma1++;
               estanobox =  true;
              if(aleatorio == 1) {
                  randomok = true;
                  this.plataforma1--;
              }
          } if (x > 1600 &&  x < 1680 && y == 49) { // plataforma 2
                this.plataforma2++;
                estanobox =  true;
               if(aleatorio == 2) {
                  randomok = true;  
                  this.plataforma2--;
              }
          } if (x > 1759 && x < 1830 && y == 49) { // plataforma 3
               this.plataforma3++;
               estanobox =  true;
              if(aleatorio == 3) {
                  randomok = true;
                  this.plataforma3--;  
              }
          } if (x > 1910 && x < 1990 && y == 49) { // plataforma 4
              this.plataforma4++;
              estanobox =  true;
              if(aleatorio == 4) {
                  randomok = true;
                  this.plataforma4--;
              }
          } if (x > 1340 && x < 1415 && y == 201) { // plataforma 5
               this.plataforma5++;
               estanobox =  true;
              if(aleatorio == 5) {
                  randomok = true;
                  this.plataforma5--;
              }
          } if (x > 1570 && x < 1581 && y == 201) { // plataforma 6
               this.plataforma6++;
               estanobox =  true;
              if(aleatorio == 6) {
                 randomok = true;  
                 this.plataforma6--;
              }
          } if (x > 1669 && x < 1743 && y == 201) { // plataforma 7
               this.plataforma7++;
               estanobox =  true;
              if(aleatorio == 7) {
                 randomok = true;
                 this.plataforma7--;
              }
          } if (x > 1800 && x < 1910 && y == 201) { // plataforma 8
               this.plataforma8++;
               estanobox =  true;
              if(aleatorio == 8) {
                 randomok = true;
                 this.plataforma8--;
              }
          } if (x > 1990 && x < 2075 && y == 201) { // plataforma 9
               this.plataforma9++;
               estanobox =  true;
              if(aleatorio == 9) {
                 randomok = true;
                 this.plataforma9--;
            }
        }
        if(!estanobox || randomok) {
          ((MapleCharacter)o).kill(); 
           Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {  
             @Override
                public void run() { 
                    ((MapleCharacter)o).changeMap(((MapleCharacter)o).getMap().getReturnMap());
                }
           }, 2000); 
        } 
     }
    Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {  
     @Override
       public void run() {      
         ChecaVencedor(); 
         }
     }, 4000);
   }  
     
    public final void ChecaVencedor() {
        for (final MapleMapObject o : mapaevento.getAllPlayer()) {
        final double x = ((MapleCharacter)o).getPosition().getX();
        final double y = ((MapleCharacter)o).getPosition().getY(); 
        boolean vencedor = false;
        
        if(plataforma1 >= 1 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) {   
         if(x > 1428 && x < 1501 && y == 49 && ((MapleCharacter)o).isAlive()) {
                vencedor = true;
                existeVencedor = true;
            }
         if(mapaevento.getCharactersSize() != plataforma1) {
             vencedor = false;
             existeVencedor = false;
           } 
         } if(plataforma1 == 0 && plataforma2 >= 1 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) { 
             if(x > 1600 && x < 1680 && y == 49 && ((MapleCharacter)o).isAlive()) {
                vencedor = true;
                existeVencedor = true;
             }
            if(mapaevento.getCharactersSize() != plataforma2) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 >= 1 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) {
             if(x > 1759 && x < 1830 && y == 49 && ((MapleCharacter)o).isAlive()) {     
               vencedor = true;
               existeVencedor = true;
            }
            if(mapaevento.getCharactersSize() != plataforma3) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 >= 1 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) {
             if(x > 1910 && x < 1990 && y == 49 && ((MapleCharacter)o).isAlive()) {  
                vencedor = true;
                existeVencedor = true;
             }
            if(mapaevento.getCharactersSize() != plataforma4) {
                vencedor = false;
                existeVencedor = false;
             }                       
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 >= 1 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) {
             if(x > 1340 && x < 1415 && y == 201 && ((MapleCharacter)o).isAlive()) {
                vencedor = true;
                existeVencedor = true;
             }
            if(mapaevento.getCharactersSize() != plataforma5) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 >= 1 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 == 0) { 
              if(x > 1570 && x < 1581 && y == 201 && ((MapleCharacter)o).isAlive()) {
                 vencedor = true;
                 existeVencedor = true;
           }
            if(mapaevento.getCharactersSize() != plataforma6) {
                vencedor = false;
                existeVencedor = false;
             }               
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 >= 1 && plataforma8 == 0 && plataforma9 == 0) {
             if(x > 1669 && x < 1743 && y == 201 && ((MapleCharacter)o).isAlive()) {  
                vencedor = true;
                existeVencedor = true;
           }
            if(mapaevento.getCharactersSize() != plataforma7) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 >= 1 && plataforma9 == 0) {
             if(x > 1800 && x < 1910 && y == 201 && ((MapleCharacter)o).isAlive()) { 
                vencedor = true;
                existeVencedor = true;
             }
            if(mapaevento.getCharactersSize() != plataforma8) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if(plataforma1 == 0 && plataforma2 == 0 && plataforma3 == 0 && plataforma4 == 0 && plataforma5 == 0 && plataforma6 == 0 && plataforma7 == 0 && plataforma8 == 0 && plataforma9 >= 1) { 
             if(x > 1990 && x < 2075 && y == 201 && ((MapleCharacter)o).isAlive()) { 
                vencedor = true;
                existeVencedor = true;
             }
            if(mapaevento.getCharactersSize() != plataforma9) {
                vencedor = false;
                existeVencedor = false;
             }              
         } if (vencedor) {
                  FilePrinter.print("RoletaRussa.txt", "Ganhador: " + ((MapleCharacter)o).getName() + " | Level: " + ((MapleCharacter)o).getLevel() + ".");
                  ((MapleCharacter)o).dropMessage("[Roleta Russa | Evento] Parab�ns, voc� foi um vencedor.");
                  ((MapleCharacter)o).dropMessage("[Roleta Russa | Evento] Voc� recebeu " + leaderpoints + " LeaderPoints pelo feito!");
                  ((MapleCharacter)o).modifyCSPoints(2, leaderpoints);
                  ((MapleCharacter)o).saveToDB(true, true);
                  ((MapleCharacter)o).changeMap(((MapleCharacter)o).getMap().getReturnMap());
                   EventoLog.setEventLog(((MapleCharacter)o).getAccountID(), "Roleta Russa", ((MapleCharacter)o).getName(), 1225);
          } 
        }
      if(!existeVencedor && mapaevento.getCharactersSize() > 0) {
                mapaevento.broadcastMessage(MaplePacketCreator.getClock(15)); 
                mapaevento.broadcastMessage(MaplePacketCreator.serverNotice(6, "[Roleta Russa | Evento] Escolha a pr�xima plataforma antes do tempo acabar."));
                Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() { 
                  @Override
                   public void run() {
                           LimpaPlataforma();
                           GeraNumeroPlataforma();
                           ChecaPlataformaAleatoria(); 
                     }
            }, 15000);     
        } if(existeVencedor) {
           Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() { 
                  @Override
                   public void run() {
                           LimpaPlataforma();
                           new RoletaRussa();
                     }
            }, 1 * 1000 * 60 * 60 * 24);
        }   
    }
    
    public static PropertiesTable getProperties() {
          return RoletaRussa.propriedades;
    }
        
    public static boolean RoletaDisponivel () {
         return getProperties().getProperty("eventoaberto").equals(Boolean.TRUE);
    }    
}




