/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventos;

import client.MapleCharacter;
import client.MapleClient;
import config.configuracoes.mensagens.Mensagens;
import server.MapleTimer.MapTimer;
import server.maps.MapleMap;
import server.maps.MapleMapObject;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 */
public class VerdadeiroFalso {
    
    public static MapleMap map; 
    public static String pergunta;
    public static String resposta;
    public static boolean answer;
    public static int expGain = 400;
    
    public static void EnviaPergunta(final MapleClient client, final int resposta, final String pgnt) {
       try {
       client.getPlayer().getMap().startMapEffect("[Pergunta]: " + pgnt, 5120002, 35000);
       client.getPlayer().getMap().broadcastMessage(MaplePacketCreator.getClock(15));
       client.getPlayer().getMap().broadcastMessage(MaplePacketCreator.serverNotice(5, "[Pergunta]: " + pgnt));
       MapTimer tMan =  MapTimer.getInstance();
            tMan.schedule(new Runnable() {
                @Override
                public void run() {
                    checkRespostas(client, resposta); 
               }
            }, 15000);
       } catch(Exception e) {
           System.out.println("Erro: " + e);
       }
   }
    
    public static void checkRespostas(MapleClient c, int resposta) {
        for (MapleMapObject o : c.getPlayer().getMap().getAllPlayer()) {
            double x = ((MapleCharacter)o).getPosition().getX();
            double y = ((MapleCharacter)o).getPosition().getY();
            boolean correct = false;
            if (!((MapleCharacter)o).isGM()) {
            if (x > -234 && y > -26) {
                if (resposta == 0) {
                    ((MapleCharacter)o).dropMessage("[" + Mensagens.Nome_Server + " Quiz] Correto!");
                    correct = true;
                } else {
                    ((MapleCharacter)o).dropMessage("[" + Mensagens.Nome_Server + " Quiz] Incorreto!");
                }
            } else if (x < -234 && y > -26) {
                if (resposta == 1) {
                    ((MapleCharacter)o).dropMessage("[" + Mensagens.Nome_Server + " Quiz] Correto!");
                    correct = true;
                } else {
                    ((MapleCharacter)o).dropMessage("[" + Mensagens.Nome_Server + " Quiz] Incorreto!");
                }
            }
            if (correct) {
                ((MapleCharacter)o).gainExp(expGain * ((MapleCharacter)o).getClient().getChannelServer().getExpRate(), true, false);
            } else {
                 ((MapleCharacter)o).changeMap(((MapleCharacter)o).getMap().getReturnMap());
            }
          }
       }
    }  
}  