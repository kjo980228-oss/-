/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventsnotscript;

import config.configuracoes.mensagens.Mensagens;
import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer.MapTimer;

/**
 * @author JavaScriptz
 * Auto-Mensagem
 * Removido AutoMsg.js
 */
public class AutoMensagem {
    
    private ScheduledFuture<?> Tarefa;
    
    public AutoMensagem () {
        NovoRegistro();
    }
    
    public final void NovoRegistro () {
        Tarefa = MapTimer.getInstance().schedule(new Runnable() {
              @Override
                public void run() {
                        Comecar();
                }
        }, 20 * 60000 + (int) (Math.random() * 10000));
    }
    
    public void cancelarRegistro () {
        Tarefa.cancel(true);
    }

    public void Comecar () {
       NovoRegistro();
       double chance = Math.random();
       String[] Message = 
           {"Bem vindo ao " + Mensagens.Nome_Server + "!",
           "Por favor, n�o use linguagem impr�pria.",
           "N�O ser�o toleradas ofensas, verbais ou n�o. Quem ofender ser� bloqueado do jogo.",
           "Reporte qualquer erro em nossa comunidade!",
           "Use @comandos para ver a lista de comandos dispon�veis!",
           "NUNCA abra um arquivo anexo desconhecido de uma janela de mensagem instant�nea ou de e-mail.",
           "Este � um jogo on-line, e a intera��o on-line envolve a comunica��o com estranhos. NUNCA forne�a informa��es pessoais como seu nome, idade, telefone e endere�o para NINGU�M que voc� n�o conhe�a. Proteja sua identidade!",
           "Usu�rios que abusarem dos Termos de Servi�o ser�o bloqueados do jogo.",
           "Quem usar, vender, trocar ou promover hackers ou ferramentas de hackers ser� bloqueado do jogo.",
           "Voc� pode usar as \"Op��es de Sistema\" no menu para alterar suas configura��es? sons, gr�ficos, etc.",
           "Use as 'Op��es de Jogo' no menu para alterar configura��es de bate-papo, trocas, sussurros, etc.",
           "Itens de Doador podem ser comprados na Loja de Itens, usando \"LeaderPoints\" comprado em nosso site."};      
       for (ChannelServer cserv_ : ChannelServer.getAllInstances()) {
       cserv_.yellowWorldMessage("[Dicas " + Mensagens.Nome_Server + "] " + Message[(int) (chance * Message.length)]); 
       }
    }  
}  