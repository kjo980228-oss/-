/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventsnotscript;

import java.awt.Point;
import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer;
import server.PropertiesTable;
import server.life.MapleLifeFactory;
import server.maps.MapleMap;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 * Barcos
 * Removido Boats.js
 */
public class Barcos {

public static PropertiesTable propriedades;  
private ScheduledFuture<?> Tarefa;
public long closeTime = 50 * 1000, beginTime = 60 * 1000, rideTime = 120 * 1000, invasionTime = 30 * 1000; 
public MapleMap Orbis_btf, Boat_to_Orbis, Orbis_Boat_Cabin, Orbis_docked, Boat_to_Ellinia, Ellinia_btf, Ellinia_Boat_Cabin, Ellinia_docked, Orbis_Station;

        public Barcos () {
            /* Carrega tabela de propriedades */
            Barcos.propriedades = new PropertiesTable();
            /* Seta mapas dos barcos */
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            Orbis_btf = cserv.getMapFactory().getMap(200000112);
            Ellinia_btf = cserv.getMapFactory().getMap(101000301);
            Boat_to_Orbis = cserv.getMapFactory().getMap(200090010);
            Boat_to_Ellinia = cserv.getMapFactory().getMap(200090000);
            Orbis_Boat_Cabin = cserv.getMapFactory().getMap(200090011);
            Ellinia_Boat_Cabin = cserv.getMapFactory().getMap(200090001);
            Ellinia_docked = cserv.getMapFactory().getMap(101000300);
            Orbis_Station = cserv.getMapFactory().getMap(200000100);
            Orbis_docked = cserv.getMapFactory().getMap(200000111);
            /* Registra as tarefas */
            BarcoOrbisConfig();
            BarcoElliniaConfig();
            NovoRegistro();
            }
        }

        public final void NovoRegistro() {
            Ellinia_docked.setDocked(true);
            Orbis_docked.setDocked(true);
            Ellinia_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
            propriedades.setProperty("ancorado", Boolean.TRUE);
            propriedades.setProperty("entrada", Boolean.TRUE);
            propriedades.setProperty("PossuiBalrog", Boolean.FALSE);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               PararEntrada();
                        }
                }, closeTime);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                              Decolar();
                        }
                }, beginTime);
        }

        public void PararEntrada() {
            propriedades.setProperty("entrada", Boolean.FALSE);
            Orbis_Boat_Cabin.resetReactors();
            Ellinia_Boat_Cabin.resetReactors();
        }



        public void Decolar() {
            propriedades.setProperty("ancorado", Boolean.FALSE);
            Orbis_btf.warpEveryone(Boat_to_Ellinia.getId());
            Ellinia_btf.warpEveryone(Boat_to_Orbis.getId());
            Ellinia_docked.setDocked(false);
            Orbis_docked.setDocked(false);
            Ellinia_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                              @Override
                                public void run() {
                                       Invasao();
                                }
                        }, invasionTime);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                          @Override
                            public void run() {
                                 Chegou();
                            }
                    }, rideTime); 
        }

        public void Chegou() {
            Boat_to_Orbis.warpEveryone(Orbis_Station.getId());
            Orbis_Boat_Cabin.warpEveryone(Orbis_Station.getId());
            Boat_to_Ellinia.warpEveryone(Ellinia_docked.getId());
            Ellinia_Boat_Cabin.warpEveryone(Ellinia_docked.getId());
            Boat_to_Orbis.killAllMonsters();
            Boat_to_Ellinia.killAllMonsters();
            NovoRegistro();
        }


        public void Invasao() {
            int numerospawn = 2;
            if(numerospawn > 0) {
                for(int i=0; i < numerospawn; i++) {
                    Boat_to_Orbis.spawnMonsterOnGroudBelow(MapleLifeFactory.getMonster(8150000), new Point(485, -221));
                    Boat_to_Ellinia.spawnMonsterOnGroudBelow(MapleLifeFactory.getMonster(8150000), new Point(-590, -221));
                }
                Boat_to_Orbis.setDocked(true);
                Boat_to_Ellinia.setDocked(true);
                Boat_to_Orbis.broadcastMessage(MaplePacketCreator.boatPacket(true));
                Boat_to_Ellinia.broadcastMessage(MaplePacketCreator.boatPacket(true));
                Boat_to_Orbis.broadcastMessage(MaplePacketCreator.musicChange("Bgm04/ArabPirate"));
                Boat_to_Ellinia.broadcastMessage(MaplePacketCreator.musicChange("Bgm04/ArabPirate"));
                propriedades.setProperty("PossuiBalrog", Boolean.TRUE);
            }
        }

        public final void BarcoOrbisConfig() {
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            cserv.getMapFactory().getMap(200090011).getPortal("out00").setScriptName("OBoat1");
            cserv.getMapFactory().getMap(200090011).getPortal("out01").setScriptName("OBoat2");
            }
        }
        
        public static PropertiesTable getProperties() {
          return Barcos.propriedades;
        }
        
        public static boolean BarcoDisponivel () {
         return getProperties().getProperty("entrada").equals(Boolean.TRUE);
        }
        
        public static boolean PossuiBalrog () {
         return getProperties().getProperty("PossuiBalrog").equals(Boolean.TRUE);
        }

        public final void BarcoElliniaConfig() {
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            cserv.getMapFactory().getMap(200090001).getPortal("out00").setScriptName("EBoat1");
            cserv.getMapFactory().getMap(200090001).getPortal("out01").setScriptName("EBoat2");
            }
      }
}  