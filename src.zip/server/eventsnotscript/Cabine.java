/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventsnotscript;

import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer;
import server.PropertiesTable;
import server.maps.MapleMap;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 * Cabine
 * Removido Cabin.js
 */


public class Cabine {

public static PropertiesTable propriedades; 
private ScheduledFuture<?> Tarefa;
public long closeTime = 60 * 1000, beginTime = 60 * 1000, rideTime = 60 * 1000;
public MapleMap Orbis_btf, Leafre_btf, Cabin_to_Orbis, Cabin_to_Leafre, Orbis_docked, Leafre_docked, Orbis_Station, Leafre_Station;

        public Cabine () {
            /* Carrega tabela de propriedades */
            Cabine.propriedades = new PropertiesTable();
            /* Seta mapas da Cabine */
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            Orbis_btf = cserv.getMapFactory().getMap(200000132);
            Leafre_btf = cserv.getMapFactory().getMap(240000111);
            Cabin_to_Orbis = cserv.getMapFactory().getMap(200090210);
            Cabin_to_Leafre = cserv.getMapFactory().getMap(200090200);
            Orbis_docked = cserv.getMapFactory().getMap(200000131);
            Leafre_docked = cserv.getMapFactory().getMap(240000110);
            Orbis_Station = cserv.getMapFactory().getMap(200000100);
            Leafre_Station = cserv.getMapFactory().getMap(240000100);
            /* Registra as tarefas */
            NovoRegistro();
            }
        }
        
        public final void NovoRegistro() {
            Leafre_docked.setDocked(true);
            Orbis_docked.setDocked(true);
            Leafre_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
            propriedades.setProperty("ancorado", Boolean.TRUE);
            propriedades.setProperty("entrada", Boolean.TRUE);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               stopEntry();
                        }
                }, closeTime);
             Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               takeoff();
                        }
                }, beginTime);
        }
        
        public void stopEntry() {
            propriedades.setProperty("entrada", Boolean.FALSE);
        }



        public void takeoff() {
            Leafre_docked.setDocked(false);
            Orbis_docked.setDocked(false);
            Leafre_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            propriedades.setProperty("ancorado", Boolean.FALSE);
            Orbis_btf.warpEveryone(Cabin_to_Leafre.getId());
            Leafre_btf.warpEveryone(Cabin_to_Orbis.getId());
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               arrived();
                        }
             }, rideTime);
        }

        public void arrived() {
                Cabin_to_Orbis.warpEveryone(Orbis_Station.getId());
                Cabin_to_Leafre.warpEveryone(Leafre_Station.getId());
                NovoRegistro();
        }
        
        public static PropertiesTable getProperties() {
          return Cabine.propriedades;
        }
        
        public static boolean CabineDisponivel () {
         return getProperties().getProperty("entrada").equals(Boolean.TRUE);
        }

        public void cancelSchedule() {
            this.Tarefa.cancel(true);
        }
          
}  