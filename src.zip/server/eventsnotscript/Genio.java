/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventsnotscript;

import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer;
import server.PropertiesTable;
import server.maps.MapleMap;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 * Barcos
 * Removido Boats.js
 */
public class Genio {

public static PropertiesTable propriedades;  
private ScheduledFuture<?> Tarefa;    
public long closeTime = 60 * 1000, beginTime = 60 * 1000, rideTime = 60 * 1000; 
public MapleMap Orbis_btf, Genie_to_Orbis, Orbis_docked, Ariant_btf, Genie_to_Ariant, Ariant_docked, Orbis_Station;    
    
        public Genio () {
            /* Carrega tabela de propriedades */
            this.propriedades = new PropertiesTable();
            /* Seta mapas do Genio */
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
                Orbis_btf = cserv.getMapFactory().getMap(200000152);
                Ariant_btf = cserv.getMapFactory().getMap(260000110);
                Genie_to_Orbis = cserv.getMapFactory().getMap(200090410);
                Genie_to_Ariant = cserv.getMapFactory().getMap(200090400);
                Orbis_docked = cserv.getMapFactory().getMap(200000151);
                Ariant_docked = cserv.getMapFactory().getMap(260000100);
                Orbis_Station = cserv.getMapFactory().getMap(200000100);
            }
            scheduleNew();
        }
        
        public final void scheduleNew() {
            Ariant_docked.setDocked(true);
            Orbis_docked.setDocked(true);
            Ariant_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));    
            propriedades.setProperty("docked", Boolean.TRUE);
            propriedades.setProperty("entry", Boolean.TRUE);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               stopEntry();
                        }
             }, closeTime);
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               takeoff();
                        }
             }, beginTime);
        }

        public void stopEntry() {
            propriedades.setProperty("entry", Boolean.FALSE);
        }

        public void takeoff() {
            propriedades.setProperty("docked", Boolean.FALSE);
            Ariant_docked.setDocked(false);
            Orbis_docked.setDocked(false);
            Ariant_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Orbis_btf.warpEveryone(Genie_to_Ariant.getId());
            Ariant_btf.warpEveryone(Genie_to_Orbis.getId());
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               arrived();
                        }
             }, rideTime);
        }
        
        public static PropertiesTable getProperties() {
          return Genio.propriedades;
        }
        
        public static boolean GenioDisponivel () {
         return getProperties().getProperty("entry").equals(Boolean.TRUE);
        }

        public void arrived() {
                Genie_to_Orbis.warpEveryone(Orbis_Station.getId());
                Genie_to_Ariant.warpEveryone(Ariant_docked.getId());
                scheduleNew();
        }

        public void cancelSchedule() {
        }
}  