/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.eventsnotscript;

import java.util.concurrent.ScheduledFuture;
import net.channel.ChannelServer;
import server.MapleTimer;
import server.PropertiesTable;
import server.maps.MapleMap;
import tools.MaplePacketCreator;

/**
 * @author JavaScriptz
 * Barcos
 * Removido Boats.js
 */
public class Trens {

private static PropertiesTable propriedades;  
private ScheduledFuture<?> Tarefa;
public long closeTime = 60 * 1000, beginTime = 60 * 1000, rideTime = 60 * 1000;
public MapleMap Orbis_btf, Train_to_Orbis, Orbis_docked, Ludibrium_btf, Train_to_Ludibrium, Ludibrium_docked, Orbis_Station, Ludibrium_Station;    

        public Trens () {
            /* Carrega tabela de propriedades */
            this.propriedades = new PropertiesTable();
            /* Seta mapas dos barcos */
            for (ChannelServer cserv : ChannelServer.getAllInstances()) {
            Orbis_btf = cserv.getMapFactory().getMap(200000122);
            Ludibrium_btf = cserv.getMapFactory().getMap(220000111);
            Train_to_Orbis = cserv.getMapFactory().getMap(200090110);
            Train_to_Ludibrium = cserv.getMapFactory().getMap(200090100);
            Orbis_docked = cserv.getMapFactory().getMap(200000121);
            Ludibrium_docked = cserv.getMapFactory().getMap(220000110);
            Orbis_Station = cserv.getMapFactory().getMap(200000100);
            Ludibrium_Station = cserv.getMapFactory().getMap(220000100);
            }
            scheduleNew(); 
      }

      public final void scheduleNew() {
        Ludibrium_docked.setDocked(true);
        Orbis_docked.setDocked(true);
        Ludibrium_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
        Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(true));
        propriedades.setProperty("docked", Boolean.TRUE);
        propriedades.setProperty("entry", Boolean.TRUE);
        Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               stopEntry();
                        }
        }, closeTime);
        Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               takeoff();
                        }
        }, beginTime);
      }

      public void stopEntry() {
            propriedades.setProperty("entry", Boolean.FALSE);
      }

      public void takeoff() {
            Ludibrium_docked.setDocked(false);
            Orbis_docked.setDocked(false);
            Ludibrium_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            Orbis_docked.broadcastMessage(MaplePacketCreator.boatPacketFree(false));
            propriedades.setProperty("docked", Boolean.FALSE);
            Orbis_btf.warpEveryone(Train_to_Ludibrium.getId());
            Ludibrium_btf.warpEveryone(Train_to_Orbis.getId());
            Tarefa = MapleTimer.MapTimer.getInstance().schedule(new Runnable() {
                      @Override
                        public void run() {
                               arrived();
                        }
            }, rideTime);
        }

       public void arrived() {
                Train_to_Orbis.warpEveryone(Orbis_Station.getId());
                Train_to_Ludibrium.warpEveryone(Ludibrium_Station.getId());
                scheduleNew();
        }
       
       public static PropertiesTable getProperties() {
          return Trens.propriedades;
        }
        
       public static boolean TrensDisponivel () {
         return getProperties().getProperty("entry").equals(Boolean.TRUE);
        }

        public void cancelSchedule() {
        }     
}  