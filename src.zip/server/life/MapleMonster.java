/*
	This file is part of the OdinMS Maple Story Server
    Copyright (C) 2008 Patrick Huy <patrick.huy@frz.cc> 
                       Matthias Butz <matze@odinms.de>
                       Jan Christian Meyer <vimes@odinms.de>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License version 3
    as published by the Free Software Foundation. You may not use, modify
    or distribute this program under any other version of the
    GNU Affero General Public License.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

package server.life;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import java.util.concurrent.ScheduledFuture;

import client.IItem;
import client.Item;
import client.MapleBuffStat;
import client.MapleCharacter;
import client.MapleClient;
import client.MapleJob;
import client.MapleQuestStatus;
import client.SkillFactory;
import client.status.MonsterStatus;
import client.status.MonsterStatusEffect;
import config.configuracoes.mensagens.Mensagens;
import java.util.concurrent.locks.ReentrantLock;
import net.MaplePacket;
import net.channel.ChannelServer;
import server.quest.MapleQuest;
import net.world.MapleParty;
import net.world.MaplePartyCharacter;
import scripting.event.EventInstanceManager;
import server.MapleTimer.MonsterTimer;
import server.life.MapleMonsterInformationProvider.DropEntry;
import server.life.MapleMonsterQuestInformationProvider.QuestDropEntry;
import server.maps.MapleMap;
import server.maps.MapleMapObject;
import server.maps.MapleMapObjectType;
import tools.ArrayMap;
import tools.MaplePacketCreator;
import tools.Pair;


public class MapleMonster extends AbstractLoadedMapleLife {
	private MapleMonsterStats stats;
	private MapleMonsterStats overrideStats;
	private int hp;
	private int mp;
	private WeakReference<MapleCharacter> controller = new WeakReference<MapleCharacter>(null);
	private boolean controllerHasAggro, controllerKnowsAboutAggro;
	private Collection<AttackerEntry> attackers = new LinkedList<AttackerEntry>();
	private EventInstanceManager eventInstance = null;
	private Collection<MonsterListener> listeners = new LinkedList<MonsterListener>();
	private MapleCharacter highestDamageChar;
	private Map<MonsterStatus, MonsterStatusEffect> stati = new LinkedHashMap<MonsterStatus, MonsterStatusEffect>();
	private List<MonsterStatusEffect> activeEffects = new ArrayList<MonsterStatusEffect>();
	private MapleMap map;
        private boolean canDamage = true;
        private int dropItemPeriod;
        private boolean shouldDrop = true;
        private int droppedCount = 0;
        private boolean justSpawned = true;
	private int VenomMultiplier = 0;
	private boolean fake = false;
	private boolean dropsDisabled = false;
	private List<Pair<Integer, Integer>> usedSkills = new ArrayList<Pair<Integer, Integer>>();
	private Map<Pair<Integer, Integer>, Integer> skillsUsed = new HashMap<Pair<Integer, Integer>, Integer>();
	private List<MonsterStatus> monsterBuffs = new ArrayList<MonsterStatus>();
	private int team = -1; //-1 means no team
	private boolean random = false;
	private MapleCharacter target = null;
	private boolean hypnotized = false;
	private MapleCharacter hypnotizer = null;
        private boolean taunted = false;
        private MapleCharacter taunter = null;
        
        public ReentrantLock monsterLock = new ReentrantLock();

	public MapleMonster(final int id, final MapleMonsterStats stats) {
		super(id);
		initWithStats(stats);
	}
	
	public MapleMonster(final MapleMonster monster) {
		super(monster);
		initWithStats(monster.stats);
	}
	
	private final void initWithStats (final MapleMonsterStats stats) {
		setStance(5);
		this.stats = stats;
		hp = stats.getHp();
		mp = stats.getMp();
	}
	
	public final boolean hasPublicReward() {
		return stats.hasPublicReward();
	}

	public final boolean isHypnotized() {
		return hypnotized;
	}

	public final void setHypnotized(boolean hypnotized) {
		this.hypnotized = hypnotized;
	}
        
        public final MapleMonsterStats getStats() {
                return stats;
        } 

	public final MapleCharacter getHypnotizer() {
		return hypnotizer;
	}

	public final void setHypnotizer(final MapleCharacter hypnotizer) {
		this.hypnotizer = hypnotizer;
	}
	
	public final void hypnotize(final MapleCharacter chr, final long time) {
		this.hypnotized = true;
		this.hypnotizer = chr;
		MonsterTimer.getInstance().schedule(new Runnable() {
			public void run() {
				if (MapleMonster.this.isAlive()) {
					setHypnotized(false);
					setHypnotizer(null);
				}
			}
		}, time);
		hypnotizeDamage();
	}
	
	private final void hypnotizeDamage() {
		if (this.isHypnotized()) {
			MonsterTimer.getInstance().schedule(new Runnable() {
				public void run() {
					if (MapleMonster.this.isAlive() && isHypnotized()) {
						if (getHypnotizer() == null) {
							return;
						}
						int damage = hypnotizer.getLevel() * 10 + (int) (Math.random() * 300);
						damage(hypnotizer, damage, true);
						getMap().broadcastMessage(MaplePacketCreator.damageMonster(getObjectId(), damage));
						if (isAlive()) {
							hypnotizeDamage();
						} else {
							getMap().killMonster(MapleMonster.this, hypnotizer, true);
						}
					}
				}
			}, 5000);			
		}
	}
        
        public boolean isTaunted() {
        return taunted;
        }
            
        public void setTaunted(boolean taunted) {
            this.taunted = taunted;
        }
        public MapleCharacter getTaunter() {
            return taunter;
        }
        public void setTaunter(MapleCharacter taunter) {
            this.taunter = taunter;
        }

	public final boolean isRandom() {
		return random;
	}

	public final void setRandom(boolean random) {
		this.random = random;
	}

	public final MapleCharacter getTarget() {
		return target;
	}

	public final void setTarget(final MapleCharacter target) {
		this.target = target;
	}
	
	public final void destroyRandomEventMob() {
		if (!this.isRandom()) return;
		if (target != null) {
			this.getMap().killMonster(this, target, false);
			target.getClient().getSession().write(MaplePacketCreator.serverNotice(5, "[Random Event] Monster got bored and left."));
		} else {
			this.getMap().killMonster(this, null, false);
		}
	}

	public final int getTeam() {
		return team;
	}

	public final void setTeam(int team) {
		this.team = team;
	}
        
        public boolean isExplosive() {
          return stats.isExplosive();
        } 
	
	public final void disableDrops() {
		this.dropsDisabled = true;
	}
	
	public final boolean dropsDisabled() {
		return dropsDisabled;
	}
	
	public final void setMap(MapleMap map) {
		this.map = map;
	}
        
	public boolean hasDrop() {
        MapleMonsterInformationProvider mi = MapleMonsterInformationProvider.getInstance();
        MapleMonsterQuestInformationProvider mi1 = MapleMonsterQuestInformationProvider.getInstance();
        List<QuestDropEntry> dl = mi1.retrieveDropChances(getId());
        List<DropEntry> dl1 = mi.retrieveDropChances(getId());
        return (dl.size() > 0 || dl1.size() > 0);
    }

    public int getDrop() {
        MapleMonsterInformationProvider mi = MapleMonsterInformationProvider.getInstance();
        int lastAssigned = -1;
        int minChance = 1;
        List<DropEntry> dl = mi.retrieveDropChances(getId());
        for (DropEntry d : dl) {
            if (d.chance > minChance) {
                minChance = d.chance;
            }
        }
        for (DropEntry d : dl) {
            d.assignedRangeStart = lastAssigned + 1;
            d.assignedRangeLength = (int) Math.ceil(((double) 1 / (double) d.chance) * minChance);
            lastAssigned += d.assignedRangeLength;
        }
        // now produce the randomness o.o
        Random r = new Random();
        int c = r.nextInt(minChance);
        for (DropEntry d : dl) {
            if (c >= d.assignedRangeStart && c < (d.assignedRangeStart + d.assignedRangeLength)) {
                return d.itemId;
            }
        }
        return -1;
    }

    public int getQuestDrop(MapleCharacter chr) {
                MapleMonsterQuestInformationProvider mi = MapleMonsterQuestInformationProvider.getInstance();
                int lastAssigned = -1;
                int minChance = 1;
                List<QuestDropEntry> dl = mi.retrieveDropChances(getId());
                for (QuestDropEntry d : dl) {
                        if (d.chance > minChance)
                                minChance = d.chance;
                }
                for (QuestDropEntry d : dl) {
                        d.assignedRangeStart = lastAssigned + 1;
                        d.assignedRangeLength = (int) Math.ceil(((double) 1 / (double) d.chance) * minChance);
                        lastAssigned += d.assignedRangeLength;
                }
                // now produce the randomness o.o
                Random r = new Random();
                int c = r.nextInt(minChance);
                for (QuestDropEntry d : dl) {
                        if (c >= d.assignedRangeStart && c < (d.assignedRangeStart + d.assignedRangeLength) && chr.getQuest(MapleQuest.getInstance(d.questid)).getStatus() == MapleQuestStatus.Status.STARTED)
                                return d.itemId;
                }
                return 1;
        }


	public final int getHp() {
		return hp;
	}

        public final boolean canDamage() {
        return this.canDamage;
    }

    public final void setCanDamage(final boolean shit) {
        this.canDamage = shit;
    }

    public final int getDropItemPeriod() {
        return dropItemPeriod;
    }

    public final void setDropItemPeriod(final int se) {
        dropItemPeriod = se;
    }

    public final void scheduleCanDamage(final long time) {
        final MonsterTimer tMan = MonsterTimer.getInstance();
        tMan.schedule(new timeDamage(this), time);
    }

    public final void scheduleCanDrop(final long time) {
        final MonsterTimer tMan = MonsterTimer.getInstance();
        tMan.schedule(new pauseDrop(this), time);
    }

    public final void scheduleDrop(final int time, final int itemid) {
        final MonsterTimer timerManager = MonsterTimer.getInstance();
        final MapleMonster mob = this;
        final int itemidX = itemid;
        final Runnable s = new Runnable() {
            @Override
            public void run() {
                synchronized (this) {
                    if (mob.getShouldDrop() == false) {
                        return;
                    }
                    IItem t = new Item(itemidX, (byte)0, (short)1);
                    mob.getMap().spawnItemDrop(mob, mob.getEventInstance().getPlayers().get(0), t, mob.getPosition(), mob.isBoss(), true);
                    if (mob.getId() == 9300061) {
                        int d = mob.getDropped() + 1;
                        mob.setDropped(d);
                        mob.getMap().broadcastMessage(MaplePacketCreator.serverNotice(6, "[Sactualize] O coelhinho da Lua fez número bolo de arroz " + d + "."));
                    }
                    mob.setShouldDrop(true);
                    mob.scheduleDrop(6000, itemidX);
                }
            }
        };
        timerManager.schedule(s, 6000);
    }

    public final MaplePacket makeHPBarPacket(final MapleMonster w) {
        byte tagcolor = 01;
        byte tagbgcolor = 05;
		return MaplePacketCreator.showBossHP(9400711, w.getHp(), w.getMaxHp(), tagcolor, tagbgcolor);
    }

    public final void setHp(final int hp) {
		this.hp = hp;
	}
    
     public void gainHp(int hp){
       this.hp += hp;
    }
    

    public final boolean getJustSpawned() {
        return justSpawned;
    }

    public final void setJustSpawned(final boolean f) {
        justSpawned = f;
    }

	public final int getMaxHp() {
		if (overrideStats != null) {
			return overrideStats.getHp();
		}
		return stats.getHp();
	}

	public final int getMp() {
		return mp;
	}

	public final void setMp(int mp) {
		if (mp < 0) {
			mp = 0;
		}
		this.mp = mp;
	}

	public final int getMaxMp() {
		if (overrideStats != null) {
			return overrideStats.getMp();
		}
		return stats.getMp();
	}

	public final int getExp() {
		if (overrideStats != null) {
			return overrideStats.getExp();
		}
		return stats.getExp();
	}

	public final int getLevel() {
		return stats.getLevel();
	}

	public final int getRemoveAfter() {
		return stats.getRemoveAfter();
	}

	public final int getVenomMulti() {
		return this.VenomMultiplier;
	}

	public final void setVenomMulti(final int multiplier) {
		this.VenomMultiplier = multiplier;
	}

	public final boolean isBoss() {
		return stats.isBoss() || getId() == 8810018;
	}
	
	public final boolean isFfaLoot() {
		return stats.isFfaLoot();
	}
	
	public final int getAnimationTime(final String name) {
		return stats.getAnimationTime(name);
	}
	
	public final List<Integer> getRevives() {
		return stats.getRevives();
	}

	public final void setOverrideStats(final MapleMonsterStats overrideStats) {
		this.overrideStats = overrideStats;
	}
	
	public final byte getTagColor() {
		return stats.getTagColor();
	}
	
	public final byte getTagBgColor() {
		return stats.getTagBgColor();
	}
    
    public final void setShouldDrop(final boolean t) {
        shouldDrop = t;
    }

    public final boolean getShouldDrop() {
        return shouldDrop;
    }

    public final void setDropped(final int dr) {
        this.droppedCount = dr;
    }

    public final int getDropped() {
        return droppedCount;
    }

    public final boolean getUndead(){
        return stats.getUndead();
 	}
	
	public final MaplePacket makeHPBarPacket00(final Object retard) {
		byte tagcolor = 01;
		byte tagbgcolor = 05;
		return MaplePacketCreator.showBossHP(9400711, getHp(), getMaxHp(), tagcolor, tagbgcolor);
	}

	/**
	 * 
	 * @param from the player that dealt the damage
	 * @param damage
	 */
	public void damage(final MapleCharacter from, final int damage, final boolean updateAttackTime) {
        AttackerEntry attacker = null;
        if (from.getParty() != null) {
            attacker = new PartyAttackerEntry(from.getParty().getId(), from.getClient().getChannelServer());
        } else {
            attacker = new SingleAttackerEntry(from, from.getClient().getChannelServer());
        }
        boolean replaced = false;
        for (final AttackerEntry aentry : attackers) {
            if (aentry.equals(attacker)) {
                attacker = aentry;
                replaced = true;
                break;
            }
        }
        if (!replaced) {
            attackers.add(attacker);
        }
		int rDamage = Math.max(0, Math.min(damage, this.hp));
		attacker.addDamage(from, rDamage, updateAttackTime);
		this.hp -= rDamage;
		int remhppercentage = (int) Math.ceil((this.hp * 100.0) / getMaxHp());
		if (remhppercentage < 1) {
			remhppercentage = 1;
		}
		long okTime = System.currentTimeMillis() - 4000;
		if (hasBossHPBar()) {
			from.getMap().broadcastMessage(makeBossHPBarPacket(), getPosition());
		} else if (!isBoss()) {
			for (final AttackerEntry mattacker : attackers) {
				for (final AttackingMapleCharacter cattacker : mattacker.getAttackers()) {
					// current attacker is on the map of the monster
					if (cattacker.getAttacker().getMap() == from.getMap()) {
						if (cattacker.getLastAttackTime() >= okTime) {
							cattacker.getAttacker().getClient().getSession().write(MaplePacketCreator.showMonsterHP(getObjectId(), remhppercentage));
						}
					}
				}
			}
		}
        if (this.hp < 1 && this.getId() == 9300061 || this.hp < 1 && this.getId() == 9300102) {
            this.getMap().broadcastMessage(MaplePacketCreator.serverNotice(5, "[Not�cia] Voc� falhou na miss�o."));
            this.getMap().killAllMonsters(false);
            this.getEventInstance().disbandParty();
        } if (this.hp < 1 && this.getId() == 9300093) {
            this.getMap().broadcastMessage(MaplePacketCreator.serverNotice(5, "[Not�cia] Voc� falhou na miss�o."));
            this.getMap().killAllMonsters(false);
            this.getMap().quitEPQ();
        } if (this.hp < 1 && this.getId() > 9400321 && this.getId() < 9400337) {
            this.getMap().broadcastMessage(MaplePacketCreator.serverNotice(5, "[Not�cia] Voc� falhou na miss�o."));
            this.getMap().killAllMonsters(false);
            this.getEventInstance().disbandParty();
        }
}
        
 public final void heal(final int hp, final int mp) {
	final int TotalHP = getHp() + hp;
	final int TotalMP = getMp() + mp;

	if (TotalHP >= getMaxHp()) {
	    setHp(getMaxHp());
	} else {
	    setHp(TotalHP);
	}
	if (TotalMP >= getMp()) {
	    setMp(getMp());
	} else {
	    setMp(TotalMP);
	}
	map.broadcastMessage(MaplePacketCreator.healMonster(getObjectId(), hp));
    }
 

	
	public final boolean isAttackedBy(final MapleCharacter chr) {
		for (final AttackerEntry aentry : attackers) {
			if (aentry.contains(chr)) {
				return true;
			}
		}
		return false;
	}
        
     public void giveExpToCharacter(MapleCharacter attacker, int exp, boolean highestDamage, int numExpSharers) {
        if (highestDamage) {
            if (eventInstance != null) {
                eventInstance.monsterKilled(attacker, this);
            }
            highestDamageChar = attacker;
        }
        if (attacker.getHp() > 0) {
            int personalExp = exp;
            if (exp > 0) {
                Integer holySymbol = attacker.getBuffedValue(MapleBuffStat.HOLY_SYMBOL);
                if (holySymbol != null) {
                    if (numExpSharers == 1) {
                        personalExp *= 1.0 + (holySymbol.doubleValue() / 500.0);
                    } else {
                        personalExp *= 1.0 + (holySymbol.doubleValue() / 100.0);
                    }
                }
            }
            if (exp < 0) {
                personalExp = Integer.MAX_VALUE;
            }
            if (isTaunted()) {
                if (attacker.getJob().getId() == 412) {
                    personalExp *= (((taunter.getSkillLevel(SkillFactory.getSkill(4121003)) +10)+100.0)/100.0);
                } else if (attacker.getJob().getId() == 422) {
                    personalExp *= (((taunter.getSkillLevel(SkillFactory.getSkill(4221003)) +10)+100.0)/100.0);   
                }
            }
            attacker.gainExp(personalExp, true, false, highestDamage);
            attacker.mobKilled(this.getId());
   }
 }



      public final MapleCharacter killBy(final MapleCharacter killer) {
        long totalBaseExpL = this.getExp() * ChannelServer.getInstance(killer.getClient().getChannel()).getExpRate() * killer.hasEXPCard();
        int totalBaseExp = (int) (Math.min(Integer.MAX_VALUE, totalBaseExpL)); 
        AttackerEntry highest = null;
        int highdamage = 0;
        for (final AttackerEntry attackEntry : attackers) {
            if (attackEntry.getDamage() > highdamage) {
                highest = attackEntry;
                highdamage = attackEntry.getDamage();
            }
        }
        for (final AttackerEntry attackEntry : attackers) {
            attackEntry.killedMob(killer.getMap(), (int) Math.ceil(totalBaseExp * ((double) attackEntry.getDamage() / getMaxHp())), attackEntry == highest);
        }
        if (this.getController() != null) { // this can/should only happen when a hidden gm attacks the monster
            getController().getClient().getSession().write(MaplePacketCreator.stopControllingMonster(this.getObjectId()));
            getController().stopControllingMonster(this);
        }
        final List<Integer> toSpawn = this.getRevives();
        if (toSpawn != null) {
            final MapleMap reviveMap = killer.getMap();
            MonsterTimer.getInstance().schedule(new Runnable() {
                @Override
		public void run() {
                    for(Integer mid : toSpawn) {
			MapleMonster mob = MapleLifeFactory.getMonster(mid);
                        if (eventInstance != null) {
                            eventInstance.registerMonster(mob);
			}
			mob.setPosition(getPosition());
			if (dropsDisabled()) {
                            mob.disableDrops();
			}
			reviveMap.spawnRevives(mob);
                    }
		}
            }, this.getAnimationTime("die1"));
	}
        if(eventInstance != null) {
            eventInstance.unregisterMonster(this);
         }
        for (MonsterListener listener : listeners.toArray(new MonsterListener[listeners.size()])) {
            listener.monsterKilled(this, highestDamageChar);
        }
        final MapleCharacter ret = highestDamageChar;
        highestDamageChar = null; // may not keep hard references to chars outside of PlayerStorage or MapleMap
        return ret;
    }
      
      
	public final boolean isAlive() {
		return this.hp > 0;
	}

	public final MapleCharacter getController() {
        return controller.get();
    }
        
    public final void setController(final MapleCharacter controller) {
        this.controller = new WeakReference<MapleCharacter>(controller);
    }
	
    public final void switchController(final MapleCharacter newController, final boolean immediateAggro) {
        final MapleCharacter controllers = getController();
        if (controllers == newController) {
            return;
        }
        if (controllers != null) {
            controllers.stopControllingMonster(this);
            controllers.getClient().getSession().write(MaplePacketCreator.stopControllingMonster(getObjectId()));
        }
        newController.controlMonster(this, immediateAggro);
        setController(newController);
        if (immediateAggro) {
            setControllerHasAggro(true);
        }
        setControllerKnowsAboutAggro(false);
    }
	
	public final void addListener (final MonsterListener listener) {
		listeners.add(listener);
	}
	
	public final void removeListener (final MonsterListener listener) {
		listeners.remove(listener);
	}

	public final boolean isControllerHasAggro() {
		if (fake) {
			return false;
		}
		return controllerHasAggro;
	}

	public final void setControllerHasAggro(final boolean controllerHasAggro) {
		if (fake) {
			return;
		}
		this.controllerHasAggro = controllerHasAggro;
	}

	public final boolean isControllerKnowsAboutAggro() {
		if (fake) {
			return false;
		}
		return controllerKnowsAboutAggro;
	}

	public final void setControllerKnowsAboutAggro(final boolean controllerKnowsAboutAggro) {
		if (fake) {
			return;
		}
		this.controllerKnowsAboutAggro = controllerKnowsAboutAggro;
	}

	public final MaplePacket makeBossHPBarPacket() {
		return MaplePacketCreator.showBossHP(getId(), getHp(), getMaxHp(), getTagColor(), getTagBgColor());
	}
	
	public final boolean hasBossHPBar() {
		return (isBoss() && getTagColor() > 0) || isHT();
	}
	
	public final boolean isHT() {
		return this.getId() == 8810018;
	}
	
	@Override
	public final void sendSpawnData(final MapleClient client) {
		if (!isAlive()) {
			return;
		}
		if (team == 0 || team == 1) {
			if (client.getPlayer().getParty() != null) {
				if (team == client.getPlayer().getTeam()) {
					client.getSession().write(MaplePacketCreator.spawnFakeMonster(this, 0));
				} else {
					if (isFake())
						client.getSession().write(MaplePacketCreator.spawnFakeMonster(this, 0));
					else
						client.getSession().write(MaplePacketCreator.spawnMonster(this, false));
				}
			} else {
				client.getSession().write(MaplePacketCreator.spawnMonster(this, false));	
			}
		} else {
			if (isFake())
				client.announce(MaplePacketCreator.spawnFakeMonster(this, 0));
			else
				client.announce(MaplePacketCreator.spawnMonster(this, false));	
		} if (stati.size() > 0) {
                 for (final MonsterStatusEffect mse : this.stati.values()) {
                 client.announce(MaplePacketCreator.applyMonsterStatus(getObjectId(), mse, null));
                   }
                 }
                
		if (hasBossHPBar()) {
			client.getSession().write(makeBossHPBarPacket());
		}
	}

	@Override
	public final void sendDestroyData(final MapleClient client) {
		client.getSession().write(MaplePacketCreator.killMonster(getObjectId(), false));
	}

	@Override
	public final String toString() {
		return getName() + "(" + getId() + ") at " + getPosition().x + "/" + getPosition().y + " with " + getHp() + "/" + getMaxHp() +
			"hp, " + getMp() + "/" + getMaxMp() + " mp (alive: " + isAlive() + " oid: " + getObjectId() + ")";
	}

	@Override
	public final MapleMapObjectType getType() {
		return 	MapleMapObjectType.MONSTER;
	}

	public final EventInstanceManager getEventInstance() {
		return eventInstance;
	}

	public final void setEventInstance(final EventInstanceManager eventInstance) {
		this.eventInstance = eventInstance;
	}

	public final boolean isMobile() {
		return stats.isMobile();
	}

	public final ElementalEffectiveness getEffectiveness (final Element e) {
		if (activeEffects.size() > 0 && stati.get(MonsterStatus.DOOM) != null) {
			return ElementalEffectiveness.NORMAL; // like blue snails
		}
		return stats.getEffectiveness(e);
	}
	
	public final boolean applyStatus (final MapleCharacter from, final MonsterStatusEffect status, final boolean poison, final long duration) {
		return applyStatus(from, status, poison, duration, false);
	}

	public final boolean applyStatus(final MapleCharacter from, final MonsterStatusEffect status, final boolean poison, final long duration, final boolean venom) {
        switch (stats.getEffectiveness(status.getSkill().getElement())) {
            case IMMUNE:
            case STRONG:
                return false;
            case NORMAL:
            case WEAK:
                break;
            default:
                throw new RuntimeException("Unknown elemental effectiveness: " + stats.getEffectiveness(status.getSkill().getElement()));
        }
        ElementalEffectiveness effectiveness = null;
        switch (status.getSkill().getId()) {
            case 2111006:
                effectiveness = stats.getEffectiveness(Element.POISON);
                if (effectiveness == ElementalEffectiveness.IMMUNE || effectiveness == ElementalEffectiveness.STRONG) {
                    return false;
                }
                break;
            case 2211006:
                effectiveness = stats.getEffectiveness(Element.ICE);
                if (effectiveness == ElementalEffectiveness.IMMUNE || effectiveness == ElementalEffectiveness.STRONG) {
                    return false;
                }
                break;
            case 4120005:
            case 4220005:
                effectiveness = stats.getEffectiveness(Element.POISON);
                if (effectiveness == ElementalEffectiveness.WEAK) {
                    return false;
                }
                break;
        }
        if (poison && getHp() <= 1) {
            return false;
        }
        if (isBoss() && !(status.getStati().containsKey(MonsterStatus.SPEED))) {
            return false;
        }
        for (MonsterStatus stat : status.getStati().keySet()) {
            MonsterStatusEffect oldEffect = stati.get(stat);
            if (oldEffect != null) {
                oldEffect.removeActiveStatus(stat);
                if (oldEffect.getStati().size() == 0) {
                    oldEffect.getCancelTask().cancel(false);
                    oldEffect.cancelPoisonSchedule();
                    activeEffects.remove(oldEffect);
                }
            }
        }
        final MonsterTimer timerManager = MonsterTimer.getInstance();
        final Runnable cancelTask = new Runnable() {
            @Override
            public void run() {
                if (isAlive()) {
                    MaplePacket packet = MaplePacketCreator.cancelMonsterStatus(getObjectId(), status.getStati());
                    map.broadcastMessage(packet, getPosition());
                    if (getController() != null && !getController().isMapObjectVisible(MapleMonster.this)) {
                        getController().getClient().getSession().write(packet);
                    }
                }
                activeEffects.remove(status);
                for (final MonsterStatus stat : status.getStati().keySet()) {
                    stati.remove(stat);
                }
                setVenomMulti(0);
                status.cancelPoisonSchedule();
            }
        };
        if (poison) {
            final int poisonLevel = from.getSkillLevel(status.getSkill());
            final int poisonDamage = Math.min(Short.MAX_VALUE, (int) (getMaxHp() / (70.0 - poisonLevel) + 0.999));
            status.setValue(MonsterStatus.POISON, Integer.valueOf(poisonDamage));
            status.setPoisonSchedule(timerManager.register(new PoisonTask(poisonDamage, from, status, cancelTask, false), 1000, 1000));
        } else if (venom) {
            if (from.getJob() == MapleJob.NIGHTLORD || from.getJob() == MapleJob.SHADOWER) {
                int poisonLevel = 0;
                int matk = 0;
                if (from.getJob() == MapleJob.NIGHTLORD) {
                    poisonLevel = from.getSkillLevel(SkillFactory.getSkill(4120005));
                    if (poisonLevel <= 0) {
                        return false;
                    }
                    matk = SkillFactory.getSkill(4120005).getEffect(poisonLevel).getMatk();
                } else if (from.getJob() == MapleJob.SHADOWER) {
                    poisonLevel = from.getSkillLevel(SkillFactory.getSkill(4220005));
                    if (poisonLevel <= 0) {
                        return false;
                    }
                    matk = SkillFactory.getSkill(4220005).getEffect(poisonLevel).getMatk();
                } else {
                    return false;
                }
                Random r = new Random();
                final int luk = from.getLuk();
                final int maxDmg = (int) Math.ceil(Math.min(Short.MAX_VALUE, 0.2 * luk * matk));
                final int minDmg = (int) Math.ceil(Math.min(Short.MAX_VALUE, 0.1 * luk * matk));
                int gap = maxDmg - minDmg;
                if (gap == 0) {
                    gap = 1;
                }
                int poisonDamage = 0;
                for (int i = 0; i < getVenomMulti(); i++) {
                    poisonDamage = poisonDamage + (r.nextInt(gap) + minDmg);
                }
                poisonDamage = Math.min(Short.MAX_VALUE, poisonDamage);
                status.setValue(MonsterStatus.POISON, Integer.valueOf(poisonDamage));
                status.setPoisonSchedule(timerManager.register(new PoisonTask(poisonDamage, from, status, cancelTask, false), 1000, 1000));
            } else {
                return false;
            }
        } else if (status.getSkill().getId() == 4111003) {
            int webDamage = (int) (getMaxHp() / 50.0 + 0.999);
            status.setPoisonSchedule(timerManager.schedule(new PoisonTask(webDamage, from, status, cancelTask, true), 3500));
        }
        for (final MonsterStatus stat : status.getStati().keySet()) {
            stati.put(stat, status);
        }
        activeEffects.add(status);
        int animationTime = status.getSkill().getAnimationTime();
        MaplePacket packet = MaplePacketCreator.applyMonsterStatus(getObjectId(), status.getStati(), status.getSkill().getId(), false, 0);
        map.broadcastMessage(packet, getPosition());
        if (getController() != null && !getController().isMapObjectVisible(this)) {
            getController().getClient().getSession().write(packet);
        }
        ScheduledFuture<?> schedule = timerManager.schedule(cancelTask, duration + animationTime);
        status.setCancelTask(schedule);
        return true;
    }
	
	public final void applyMonsterBuff(final MonsterStatus status, final int x, final int skillId, final long duration, final MobSkill skill) {
		MonsterTimer timerManager = MonsterTimer.getInstance();
		final Runnable cancelTask = new Runnable() {
			@Override
			public void run() {
				if (isAlive()) {
					MaplePacket packet = MaplePacketCreator.cancelMonsterStatus(getObjectId(), Collections.singletonMap(status, Integer.valueOf(x)));
					map.broadcastMessage(packet, getPosition());
					if (getController() != null && !getController().isMapObjectVisible(MapleMonster.this)) {
						getController().getClient().getSession().write(packet);
					}
					removeMonsterBuff(status);
				}
			}
		};
		MaplePacket packet = MaplePacketCreator.applyMonsterStatus(getObjectId(), Collections.singletonMap(status, x), skillId, true, 0, skill);
		map.broadcastMessage(packet, getPosition());
		if (getController() != null && !getController().isMapObjectVisible(this)) {
			getController().getClient().getSession().write(packet);
		}
		timerManager.schedule(cancelTask, duration);
		addMonsterBuff(status);
		
	}
	
	public final void addMonsterBuff(final MonsterStatus status) {
		this.monsterBuffs.add(status);
	}
	
	public final void removeMonsterBuff(final MonsterStatus status) {
		this.monsterBuffs.remove(status);
	}
	
	public final void cancelMonsterBuff(final MonsterStatus status) {
		if (isAlive()) {
			MaplePacket packet = MaplePacketCreator.cancelMonsterStatus(getObjectId(), Collections.singletonMap(status, Integer.valueOf(1)));
			map.broadcastMessage(packet, getPosition());
			if (getController() != null && !getController().isMapObjectVisible(MapleMonster.this)) {
				getController().getClient().getSession().write(packet);
			}
			removeMonsterBuff(status);
		}
	}
	
	public final void dispel() {
		if (isAlive()) {
			MonsterStatus[] remove = {MonsterStatus.ACC, MonsterStatus.AVOID, MonsterStatus.MAGIC_ATTACK_UP, MonsterStatus.MAGIC_DEFENSE_UP, MonsterStatus.MATK, MonsterStatus.MDEF, MonsterStatus.WATK, MonsterStatus.WDEF, MonsterStatus.WEAPON_ATTACK_UP, MonsterStatus.WEAPON_DEFENSE_UP, MonsterStatus.WEAPON_IMMUNITY, MonsterStatus.MAGIC_IMMUNITY, MonsterStatus.SPEED};
			for (int i = 0; i < remove.length; i++) {
				if (monsterBuffs.contains(remove[i])) {
					removeMonsterBuff(remove[i]);
					MaplePacket packet = MaplePacketCreator.cancelMonsterStatus(getObjectId(), Collections.singletonMap(remove[i], Integer.valueOf(1)));
					map.broadcastMessage(packet, getPosition());
					if (getController() != null && !getController().isMapObjectVisible(MapleMonster.this)) {
						getController().getClient().getSession().write(packet);
					}
				}
			}
		}
	}
	
	public final boolean isBuffed(final MonsterStatus status) {
		return this.monsterBuffs.contains(status);
	}
	
	public final void setFake(final boolean fake) {
		this.fake = fake;
	}
	
	public final boolean isFake() {
		return fake;
	}
	
	public final MapleMap getMap() {
		return map;
	}
	
	public final List<Pair<Integer, Integer>> getSkills() {
		return this.stats.getSkills();
	}
	
	public final boolean hasSkill(final int skillId, final int level) {
		return stats.hasSkill(skillId, level);
	}
	
	public final boolean canUseSkill(final MobSkill toUse) {
		if (toUse == null) {
			return false;
		}
		for (Pair<Integer, Integer> skill : usedSkills) {
			if (skill.getLeft() == toUse.getSkillId() && skill.getRight() == toUse.getSkillLevel()) {
				return false;
			}
		}
		if (toUse.getLimit() > 0) {
			if (this.skillsUsed.containsKey(new Pair<Integer, Integer>(toUse.getSkillId(), toUse.getSkillLevel()))) {
				int times = this.skillsUsed.get(new Pair<Integer, Integer>(toUse.getSkillId(), toUse.getSkillLevel()));
				if (times >= toUse.getLimit()) {
					return false;
				}
			}
		}
		if (toUse.getSkillId() == 200) {
			Collection<MapleMapObject> mmo = getMap().getMapObjects();
			int i = 0;
			for (MapleMapObject mo : mmo) {
				if (mo.getType() == MapleMapObjectType.MONSTER) {
					i++;
				}
			}
			if (i > 100) {
				return false;
			}
		}
		return true;
	}
	
	public final void usedSkill(final int skillId, final int level, final long cooltime) {
		this.usedSkills.add(new Pair<Integer, Integer>(skillId, level));
		
		if (this.skillsUsed.containsKey(new Pair<Integer, Integer>(skillId, level))) {
			int times = this.skillsUsed.get(new Pair<Integer, Integer>(skillId, level)) + 1;
			this.skillsUsed.remove(new Pair<Integer, Integer>(skillId, level));
			this.skillsUsed.put(new Pair<Integer, Integer>(skillId, level), times);
		} else {
			this.skillsUsed.put(new Pair<Integer, Integer>(skillId, level), 1);
		}
		
		final MapleMonster mons = this;
		final MonsterTimer tMan = MonsterTimer.getInstance();
		tMan.schedule(
			new Runnable() {
				@Override
				public void run() {
					mons.clearSkill(skillId, level);
				}
			}, cooltime);
	}
	
	public final void clearSkill(final int skillId, final int level) {
		int index = -1;
		for (Pair<Integer, Integer> skill : usedSkills) {
			if (skill.getLeft() == skillId && skill.getRight() == level) {
				index = usedSkills.indexOf(skill);
				break;
			}
		}
		if (index != -1) {
			usedSkills.remove(index);
		}
	}
	
	public final int getNoSkills() {
		return this.stats.getNoSkills();
	}
	
	public final boolean isFirstAttack() {
		return this.stats.isFirstAttack();
	}
	
	public final int getBuffToGive() {
		return this.stats.getBuffToGive();
	}
	
	public final int getCP() {
		return this.stats.getCp();
	}

	public final List<MonsterStatus> getMonsterBuffs() {
		return monsterBuffs;
	}

     public final int getPADamage() {
        return stats.getPADamage();
    }

        public final int getDropPeriodTime() {
        return stats.getDropPeriod();
    }

    public void debuffMob(int skillid) {
        //skillid is not going to be used for now until I get warrior debuff working
        MonsterStatus[] stats = {MonsterStatus.WEAPON_ATTACK_UP, MonsterStatus.WEAPON_DEFENSE_UP, MonsterStatus.MAGIC_ATTACK_UP, MonsterStatus.MAGIC_DEFENSE_UP};
        for (int i = 0; i < stats.length; i++) {
            if (isBuffed(stats[i])) {
                final MonsterStatusEffect oldEffect = stati.get(stats[i]);
                MaplePacket packet = MaplePacketCreator.cancelMonsterStatus(getObjectId(), oldEffect.getStati());
                map.broadcastMessage(packet, getPosition());
                if (getController() != null && !getController().isMapObjectVisible(MapleMonster.this)) {
                    getController().getClient().announce(packet);
                }
                stati.remove(stats);
            }
        }
    }


	private final class PoisonTask implements Runnable {
		private final int poisonDamage;
		private final MapleCharacter chr;
		private final MonsterStatusEffect status;
		private final Runnable cancelTask;
		private final boolean shadowWeb;
		private final MapleMap map; 
		
		private PoisonTask(final int poisonDamage, final MapleCharacter chr, final MonsterStatusEffect status, final Runnable cancelTask, final boolean shadowWeb) {
			this.poisonDamage = poisonDamage;
			this.chr = chr;
			this.status = status;
			this.cancelTask = cancelTask;
			this.shadowWeb = shadowWeb;
			this.map = chr.getMap();
		}
		
		@Override
		public void run() {
			int damage = poisonDamage;
			if (damage >= hp) {
				damage = hp - 1;
				if (!shadowWeb) {
					cancelTask.run();
					status.getCancelTask().cancel(false);
				}
			}
			if (hp > 1 && damage > 0) {
				damage(chr, damage, false);
				if (shadowWeb) {
					map.broadcastMessage(MaplePacketCreator.damageMonster(getObjectId(), damage), getPosition());
				}
			}
		}
	}
	
	public String getName() {
		return stats.getName();
	}

	private class AttackingMapleCharacter {
		private MapleCharacter attacker;
		private long lastAttackTime;
				
		public AttackingMapleCharacter(final MapleCharacter attacker, final long lastAttackTime) {
			super();
			this.attacker = attacker;
			this.lastAttackTime = lastAttackTime;
		}

		public final long getLastAttackTime() {
			return lastAttackTime;
		}

		public final void setLastAttackTime(final long lastAttackTime) {
			this.lastAttackTime = lastAttackTime;
		}

		public final MapleCharacter getAttacker() {
			return attacker;
		}
	}
	
	private interface AttackerEntry {
		List<AttackingMapleCharacter> getAttackers();

		public void addDamage(MapleCharacter from, int damage, boolean updateAttackTime);

		public int getDamage();

		public boolean contains(MapleCharacter chr);

		public void killedMob(MapleMap map, int baseExp, boolean mostDamage);
	}

	private final class SingleAttackerEntry implements AttackerEntry {
		private int damage;
		private int chrid;
		private long lastAttackTime;
		private ChannelServer cserv;

		public SingleAttackerEntry(final MapleCharacter from, final ChannelServer cserv) {
			this.chrid = from.getId();
			this.cserv = cserv;
		}

		@Override
		public void addDamage(final MapleCharacter from, final int damage, final boolean updateAttackTime) {
			if (chrid == from.getId()) {
				this.damage += damage;
			} else {
				throw new IllegalArgumentException("Not the attacker of this entry");
			}
			if (updateAttackTime) {
				lastAttackTime = System.currentTimeMillis();
			}
		}

		@Override
		public final List<AttackingMapleCharacter> getAttackers() {
			MapleCharacter chr = cserv.getPlayerStorage().getCharacterById(chrid);
			if (chr != null) {
				return Collections.singletonList(new AttackingMapleCharacter(chr, lastAttackTime));
			} else {
				return Collections.emptyList();
			}
		}

		@Override
		public boolean contains(final MapleCharacter chr) {
			return chrid == chr.getId();
		}

		@Override
		public int getDamage() {
			return damage;
		}

		@Override
		public void killedMob(final MapleMap map, final int baseExp, final boolean mostDamage) {
                final MapleCharacter chr = cserv.getPlayerStorage().getCharacterById(chrid);
                if (chr != null && chr.getMap() == map) {
                giveExpToCharacter(chr, baseExp, mostDamage, 1);
            }
        }

		@Override
		public int hashCode() {
			return chrid;
		}

		@Override
		public final boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final SingleAttackerEntry other = (SingleAttackerEntry) obj;
			return chrid == other.chrid;
		}
	}

	private static final class OnePartyAttacker {
		public MapleParty lastKnownParty;
		public int damage;
		public long lastAttackTime;
		
		public OnePartyAttacker(final MapleParty lastKnownParty, final int damage) {
			super();
			this.lastKnownParty = lastKnownParty;
			this.damage = damage;
			this.lastAttackTime = System.currentTimeMillis();
		}
	}
	
	private class PartyAttackerEntry implements AttackerEntry {
		private int totDamage;
		private final Map<Integer, OnePartyAttacker> attackers = new HashMap<Integer, OnePartyAttacker>(6);
		private int partyid;
		private ChannelServer cserv;

		public PartyAttackerEntry(final int partyid, final ChannelServer cserv) {
			this.partyid = partyid;
			this.cserv = cserv;
		}

		public List<AttackingMapleCharacter> getAttackers() {
			final List<AttackingMapleCharacter> ret = new ArrayList<AttackingMapleCharacter>(attackers.size());
			for (final Entry<Integer, OnePartyAttacker> entry : attackers.entrySet()) {
				final MapleCharacter chr = cserv.getPlayerStorage().getCharacterById(entry.getKey());
				if (chr != null) {
					ret.add(new AttackingMapleCharacter(chr, entry.getValue().lastAttackTime));
				}
			}
			return ret;
		}

		private final Map<MapleCharacter, OnePartyAttacker> resolveAttackers() {
			final Map<MapleCharacter, OnePartyAttacker> ret = new HashMap<MapleCharacter, OnePartyAttacker>(attackers.size());
			for (final Entry<Integer, OnePartyAttacker> aentry : attackers.entrySet()) {
				final MapleCharacter chr = cserv.getPlayerStorage().getCharacterById(aentry.getKey());
				if (chr != null) {
					ret.put(chr, aentry.getValue());
				}
			}
			return ret;
		}

		@Override
		public final boolean contains(final MapleCharacter chr) {
			return attackers.containsKey(chr.getId());
		}

		@Override
		public final int getDamage() {
			return totDamage;
		}

	 public void addDamage(final MapleCharacter from, final int damage, final boolean updateAttackTime) {
            final OnePartyAttacker oldPartyAttacker = attackers.get(from.getId());
            if (oldPartyAttacker != null) {
                oldPartyAttacker.damage += damage;
                oldPartyAttacker.lastKnownParty = from.getParty();
                if (updateAttackTime) {
                    oldPartyAttacker.lastAttackTime = System.currentTimeMillis();
                }
            } else {
                // TODO actually this causes wrong behaviour when the party changes between attacks
                // only the last setup will get exp - but otherwise we'd have to store the full party
                // constellation for every attack/everytime it changes, might be wanted/needed in the
                // future but not now
                final OnePartyAttacker onePartyAttacker = new OnePartyAttacker(from.getParty(), damage);
                attackers.put(from.getId(), onePartyAttacker);
                if (!updateAttackTime) {
                    onePartyAttacker.lastAttackTime = 0;
                }
            }
            totDamage += damage;
        }

		@Override
		public final void killedMob(final MapleMap map, final int baseExp, final boolean mostDamage) {
			final Map<MapleCharacter, OnePartyAttacker> attackers_ = resolveAttackers();

			MapleCharacter highest = null;
			int highestDamage = 0;

			final Map<MapleCharacter, Integer> expMap = new ArrayMap<MapleCharacter, Integer>(6);
			for (final Entry<MapleCharacter, OnePartyAttacker> attacker : attackers_.entrySet()) {
				MapleParty party = attacker.getValue().lastKnownParty;
				double averagePartyLevel = 0;

				final List<MapleCharacter> expApplicable = new ArrayList<MapleCharacter>();
				for (final MaplePartyCharacter partychar : party.getMembers()) {
					if (attacker.getKey().getLevel() - partychar.getLevel() <= 5 ||
						getLevel() - partychar.getLevel() <= 5) {
						MapleCharacter pchr = cserv.getPlayerStorage().getCharacterByName(partychar.getName());
						if (pchr != null) {
							if (pchr.isAlive() && pchr.getMap() == map) {
								expApplicable.add(pchr);
								averagePartyLevel += pchr.getLevel();
							}
						}
					}
				}
				double expBonus = 1.0;
				if (expApplicable.size() > 1) {
					expBonus = 1.10 + 0.05 * expApplicable.size();
					averagePartyLevel /= expApplicable.size();
				}

				int iDamage = attacker.getValue().damage;
				if (iDamage > highestDamage) {
					highest = attacker.getKey();
					highestDamage = iDamage;
				}
				double innerBaseExp = baseExp * ((double) iDamage / totDamage);
				double expFraction = (innerBaseExp * expBonus) / (expApplicable.size() + 1);

				for (final MapleCharacter expReceiver : expApplicable) {
					Integer oexp = expMap.get(expReceiver);
					int iexp;
					if (oexp == null) {
						iexp = 0;
					} else {
						iexp = oexp.intValue();
					}
					double expWeight = (expReceiver == attacker.getKey() ? 2.0 : 1.0);
					double levelMod = expReceiver.getLevel() / averagePartyLevel;
					if (levelMod > 1.0 || this.attackers.containsKey(expReceiver.getId())) {
						levelMod = 1.0;
					}
					iexp += (int) Math.round(expFraction * expWeight * levelMod);
                                        if (isTaunted()) {
                                            if (taunter.getJob().getId() == 412) {
                                                iexp *= (((taunter.getSkillLevel(SkillFactory.getSkill(4121003)) +10)+100.0)/100.0);
                                                } else if (taunter.getJob().getId() == 422) {
                                                iexp *= (((taunter.getSkillLevel(SkillFactory.getSkill(4221003)) +10)+100.0)/100.0);   
                                                }
                                        }
					expMap.put(expReceiver, Integer.valueOf(iexp));
				}
			}
			// FUCK we are done -.-
			for (final Entry<MapleCharacter, Integer> expReceiver : expMap.entrySet()) {
				boolean white = mostDamage ? expReceiver.getKey() == highest : false;
				giveExpToCharacter(expReceiver.getKey(), expReceiver.getValue(), white, expMap.size());
			}
		}

		@Override
		public final int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + partyid;
			return result;
		}

		@Override
		public final boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final PartyAttackerEntry other = (PartyAttackerEntry) obj;
			if (partyid != other.partyid)
				return false;
			return true;
		}
	}
}
final class timeDamage implements Runnable {
        private MapleMonster cc;

        public timeDamage(MapleMonster ccc) {
                this.cc = ccc;
        }

        @Override
        public void run() {
            synchronized (cc) {
                cc.setCanDamage(true);
            }
        }
}

final class pauseDrop implements Runnable {
        private MapleMonster cc;

        public pauseDrop(MapleMonster ccc) {
                this.cc = ccc;
        }

        @Override
        public void run() {
            synchronized (cc) {
                cc.setShouldDrop(true);
            }
        }
}
