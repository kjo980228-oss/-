/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server.partyquest;

import java.util.concurrent.ScheduledFuture;
import client.MapleCharacter;
import net.world.MapleParty;
import net.channel.ChannelServer;
import net.world.MaplePartyCharacter;
import server.maps.MapleMap;
import config.configuracoes.mensagens.Mensagens;
import server.MapleTimer.MonsterTimer;
import tools.FilePrinter;
import tools.MaplePacketCreator;

/**
 *
 * @author David
 * @reditor JavaScritpz
 * 2015 JS-Maple
 */
public class MonsterCarnival {
	public static int D = 3;
	public static int C = 2;
	public static int B = 1;
	public static int A = 0;
	
	private MapleParty p1, p2;
	private MapleMap map;
	private ScheduledFuture<?> timer, effectTimer;
	private long startTime = 0;
        private int summons = 7;
	private MapleCharacter leader1, leader2;
	private int redCP, blueCP, redTotalCP, blueTotalCP;
        
	
	public MonsterCarnival(MapleParty p1, MapleParty p2, int mapid) {
		this.p1 = p1;
		this.p2 = p2;
		int chnl = p1.getLeader().getChannel();
		int chnl1 = p2.getLeader().getChannel();
		if (chnl != chnl1) throw new RuntimeException("[CPQ " + Mensagens.Nome_Server + "] Os l�deres est�o em canais diferentes.");
		ChannelServer cs = ChannelServer.getInstance(chnl);
		p1.setEnemy(p2);
		p2.setEnemy(p1);
	        cs.getMapFactory().disposeMap(mapid);
		map = cs.getMapFactory().getMap(mapid);
		int redPortal = 0;
		int bluePortal = 0;
		if (map.isPurpleCPQMap()) {
			redPortal = 2;
			bluePortal = 1;
		}
                
                if (cs.getMapFactory().getMap(mapid - 1).getCharacters().size() != p1.getMembers().size() + p2.getMembers().size()) return;
                
		for (MaplePartyCharacter mpc : p1.getMembers()) {
			MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) {   
                        if (mc.getMapId() == mapid - 1) {        
				mc.setMonsterCarnival(this);
				mc.changeMap(map, map.getPortal(redPortal));
				mc.setTeam(0);
                                mc.setFestivalPoints(0);
                                mc.dropMessage(6, "Voc� pode selecionar \"Invocar Monstros\", \"Habilidade\", ou \"Protetor\" como sua t�tica durante o Carnaval dos Monstros. Use Tab e F1~F12 para acesso r�pido!");
                                mc.dropMessage(5, "A F�lia dos Monstros esta a caminho!!");
				if (p1.getLeader().getId() == mc.getId()) {
					leader1 = mc;
				}
			  } else {
                        mc.dropMessage(6, "O Festival n�o foi iniciado!");
                      }
		    } 
                  }
		for (MaplePartyCharacter mpc : p2.getMembers()) {
			MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) { 
                        if (mc.getMapId() == mapid - 1) { 
				mc.setMonsterCarnival(this);
				mc.changeMap(map, map.getPortal(bluePortal));
				mc.setTeam(1);
                                mc.setFestivalPoints(0);
                                mc.dropMessage(6, "Voc� pode selecionar \"Invocar Monstros\", \"Habilidade\", ou \"Protetor\" como sua t�tica durante o Carnaval dos Monstros. Use Tab e F1~F12 para acesso r�pido!");
                                mc.dropMessage(5, "A F�lia dos Monstros est� a caminho!!");
				if (p2.getLeader().getId() == mc.getId()) {
					leader2 = mc;
				}
                           } else {
                           mc.dropMessage(6, "O Festival n�o foi iniciado!");
                     } 
                   }
                }
		startTime = System.currentTimeMillis() + 60 * 10000;
		timer = MonsterTimer.getInstance().schedule(new Runnable() {
                        @Override
			public void run() {
				timeUp();
			}
		}, 10 * 60 * 1000);
		effectTimer = MonsterTimer.getInstance().schedule(new Runnable() {
                        @Override
			public void run() {
				complete();
			}
		}, 10 * 60 * 1000 - 10 * 1000);
		MonsterTimer.getInstance().schedule(new Runnable() {
                        @Override
			public void run() {
				map.addClock(60 * 10);
			}
		}, 2000);             
	}
	
	public void playerDisconnected(int charid) {
		if (leader1.getId() == charid || leader2.getId() == charid) {
			earlyFinish();
			int team = -1;
			for (MaplePartyCharacter mpc : leader1.getParty().getMembers()) {
				if (mpc.getId() == charid) {
					team = 0;
				}
			}
			for (MaplePartyCharacter mpc : leader2.getParty().getMembers()) {
				if (mpc.getId() == charid) {
					team = 1;
				}
			}
			if (team == -1) team = 1;
			String teamS = "Indefinido";
			switch (team) {
				case 0:
					teamS = "Vermelho";
					break;
				case 1:
					teamS = "Azul";
					break;
			}
			map.broadcastMessage(MaplePacketCreator.serverNotice(5, "Maple " + teamS + " deixou o Carnaval de Monstros."));
			return;
		} else {
                        int canal = p1.getLeader().getChannel();
                        ChannelServer cs = ChannelServer.getInstance(canal);
                        MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(ChannelServer.getInstance(1).getMarket().getCharacterName(charid));
			map.broadcastMessage(MaplePacketCreator.serverNotice(5, "" + ChannelServer.getInstance(1).getMarket().getCharacterName(charid) + " saiu do Carnaval de Monstros."));
                        disposePersonagem(mc, true);
		}
	}
	
	public void earlyFinish() {
		dispose(true);
	}
	
	public void leftParty(int charid) {
		playerDisconnected(charid);
	}
	
	protected int getRankByCP(int cp) {
		if (cp < 50) {
			return D; 
		} else if (cp > 50 && cp < 100) {
			return C;
		} else if (cp > 100 && cp < 300) {
			return B;
		} else if (cp > 300) {
			return A;
		}
		return D;
	}
	
	protected void dispose() {
		dispose(false);
	}
        
        
        protected void disposePersonagem(MapleCharacter player, boolean warpout) {
                int canal = p1.getLeader().getChannel();
                ChannelServer cs = ChannelServer.getInstance(canal);
		MapleMap out = cs.getMapFactory().getMap(980000000);
		if (player != null) {
		if (warpout) {
                player.dropMessage("Voc� foi levado para Lobby!");  
                player.setTeam(-1);
                player.setFestivalPoints(0);
                player.setMonsterCarnival(null);
		player.changeMap(out, out.getPortal(0));
		}
	    }
        }
        
      public void summon() {
        this.summons--;
      }

      public boolean canSummon() {
        return this.summons > 0;
      }
        
        
        protected void dispose(boolean warpout) {
                int chnl = p1.getLeader().getChannel();
                ChannelServer cs = ChannelServer.getInstance(chnl);
		MapleMap out = cs.getMapFactory().getMap(980000000);
		for (MaplePartyCharacter mpc : leader1.getParty().getMembers()) {
			MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) {
				mc.resetCP();
                                mc.setTeam(-1);
                                mc.setMonsterCarnival(null);
				if (warpout) {
					mc.changeMap(out, out.getPortal(0));
				}
			}
		}
		for (MaplePartyCharacter mpc : leader2.getParty().getMembers()) {
			 MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) {
				mc.resetCP();
                                mc.setTeam(-1);
                                mc.setMonsterCarnival(null);
				if (warpout) {
					mc.changeMap(out, out.getPortal(0));
				}
			}
		}
                if (this.timer != null) {
                    this.timer.cancel(true);
                    this.timer = null;
                }
                if (this.effectTimer != null) {
                    this.effectTimer.cancel(true);
                    this.effectTimer = null;
                }
		redTotalCP = 0;
		blueTotalCP = 0;
		leader1.getParty().setEnemy(null);
		leader2.getParty().setEnemy(null);
	
        }
	
	public void exit() {
		dispose();
	}
	
	public ScheduledFuture<?> getTimer() {
		return this.timer;
	}

	public void finish(int winningTeam) {
                try {
		int chnl = leader1.getClient().getChannel();
		int chnl1 = leader2.getClient().getChannel();
		if (chnl != chnl1) throw new RuntimeException("[CPQ " + Mensagens.Nome_Server + "] Os l�deres est�o em canais diferentes.");
		ChannelServer cs = ChannelServer.getInstance(chnl);
		if (winningTeam == 0) {
			for (MaplePartyCharacter mpc : leader1.getParty().getMembers()) {
				MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
				if (mc != null) {
					mc.setCpqRanking(getRankByCP(this.redTotalCP));
                                        mc.gainFestivalPoints(this.redTotalCP); // Corre��o sa�da de Exp.
					mc.changeMap(cs.getMapFactory().getMap(map.getId() + 2), cs.getMapFactory().getMap(map.getId() + 2).getPortal(0));
					mc.setTeam(-1);
				}
			}
			for (MaplePartyCharacter mpc : leader2.getParty().getMembers()) {
			        MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
				if (mc != null) {
					mc.setCpqRanking(getRankByCP(this.blueTotalCP));
                                        mc.gainFestivalPoints(this.blueTotalCP); // Corre��o sa�da de Exp.
					mc.changeMap(cs.getMapFactory().getMap(map.getId() + 3), cs.getMapFactory().getMap(map.getId() + 3).getPortal(0));
					mc.setTeam(-1);
				}
			}			
		} else if (winningTeam == 1) {
			for (MaplePartyCharacter mpc : leader2.getParty().getMembers()) {
				 MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
				if (mc != null) {
					mc.changeMap(cs.getMapFactory().getMap(map.getId() + 2), cs.getMapFactory().getMap(map.getId() + 2).getPortal(0));
					mc.setTeam(-1);
				}
			}
			for (MaplePartyCharacter mpc : leader1.getParty().getMembers()) {
				 MapleCharacter mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
				if (mc != null) {
					mc.changeMap(cs.getMapFactory().getMap(map.getId() + 3), cs.getMapFactory().getMap(map.getId() + 3).getPortal(0));
					mc.setTeam(-1);
				}
			}
		}
		dispose();
              } catch (Exception e) {
                FilePrinter.printCPQ("Erro_Finish.txt", e);
           }
	}
	
	public void timeUp() {
		int cp1 = this.redTotalCP;
		int cp2 = this.blueTotalCP;
		if (cp1 == cp2) {
			extendTime();
			return;
		}
		if (cp1 > cp2) {
			finish(0);
		} else {
			finish(1);
		}
	}
	
	public long getTimeLeft() {
		return (startTime - System.currentTimeMillis());
	}
	
	public int getTimeLeftSeconds() {
		return (int) (getTimeLeft() / 1000);
	}
	
	public void extendTime() {
		map.broadcastMessage(MaplePacketCreator.serverNotice(5, "O tempo foi estendido."));
		startTime = System.currentTimeMillis() + 3 * 1000;
		map.addClock(3 * 60);		
		timer = MonsterTimer.getInstance().schedule(new Runnable() {
                        @Override
			public void run() {
				timeUp();
			}
		}, 3 * 60 * 1000);
		effectTimer = MonsterTimer.getInstance().schedule(new Runnable() {
                        @Override
			public void run() {
				complete();
			}
		}, 3 * 60 * 1000 - 10);
	}
	
	public void complete() {
		int cp1 = this.redTotalCP;
		int cp2 = this.blueTotalCP;
		if (cp1 == cp2) {
			return;
		}
		boolean redWin = cp1 > cp2;
		int chnl = leader1.getClient().getChannel();
		int chnl1 = leader2.getClient().getChannel();
		if (chnl != chnl1) throw new RuntimeException("Os l�deres est�o em canais diferentes.");
		ChannelServer cs = ChannelServer.getInstance(chnl);
		map.killAllMonsters(false);
		for (MaplePartyCharacter mpc : leader1.getParty().getMembers()) {
			MapleCharacter mc;
			mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) {
				if (redWin) {
					mc.getClient().announce(MaplePacketCreator.showEffect("quest/carnival/win"));
					mc.getClient().announce(MaplePacketCreator.playSound("MobCarnival/Win"));
                                        mc.getClient().announce(MaplePacketCreator.serverNotice(5, "Voc� venceu a F�lia dos Monstros.Por favor, espere equanto voc� e teletransportado."));
				} else {
					mc.getClient().announce(MaplePacketCreator.showEffect("quest/carnival/lose"));
					mc.getClient().announce(MaplePacketCreator.playSound("MobCarnival/Lose"));
                                        mc.getClient().announce(MaplePacketCreator.serverNotice(5, "Voc� perdeu a F�lia dos Monstros.Por favor, espere equanto voc� e teletransportado."));
				}
			}
		}
		for (MaplePartyCharacter mpc : leader2.getParty().getMembers()) {
			MapleCharacter mc;
			mc = cs.getPlayerStorage().getCharacterByName(mpc.getName());
			if (mc != null) {
				if (!redWin) {
					mc.getClient().announce(MaplePacketCreator.showEffect("quest/carnival/win"));
					mc.getClient().announce(MaplePacketCreator.playSound("MobCarnival/Win"));
                                        mc.getClient().announce(MaplePacketCreator.serverNotice(5, "Voc� venceu a F�lia dos Monstros.Por favor, espere equanto voc� e teletransportado."));
				} else {
					mc.getClient().announce(MaplePacketCreator.showEffect("quest/carnival/lose"));
					mc.getClient().announce(MaplePacketCreator.playSound("MobCarnival/Lose"));
                                        mc.getClient().announce(MaplePacketCreator.serverNotice(5, "Voc� perdeu a F�lia dos Monstros.Por favor, espere equanto voc� e teletransportado."));
				}
			}
		}
	}

	public MapleParty getRed() {
		return p1;
	}

	public void setRed(MapleParty p1) {
		this.p1 = p1;
	}

	public MapleParty getBlue() {
		return p2;
	}

	public void setBlue(MapleParty p2) {
		this.p2 = p2;
	}

	public MapleCharacter getLeader1() {
		return leader1;
	}

	public void setLeader1(MapleCharacter leader1) {
		this.leader1 = leader1;
	}

	public MapleCharacter getLeader2() {
		return leader2;
	}

	public void setLeader2(MapleCharacter leader2) {
		this.leader2 = leader2;
	}
	
	public MapleCharacter getEnemyLeader(int team) {
		switch (team) {
			case 0:
				return leader2;
			case 1:
				return leader1;
		}
		return null;
	}

	public int getBlueCP() {
		return blueCP;
	}

	public void setBlueCP(int blueCP) {
		this.blueCP = blueCP;
	}

	public int getBlueTotalCP() {
		return blueTotalCP;
	}

	public void setBlueTotalCP(int blueTotalCP) {
		this.blueTotalCP = blueTotalCP;
	}

	public int getRedCP() {
		return redCP;
	}

	public void setRedCP(int redCP) {
		this.redCP = redCP;
	}

	public int getRedTotalCP() {
		return redTotalCP;
	}

	public void setRedTotalCP(int redTotalCP) {
		this.redTotalCP = redTotalCP;
	}
	
	public int getTotalCP(int team) {
		if (team == 0) {
			return redTotalCP;
                } else if (team == 1) {
			return blueTotalCP;
                } else {
			throw new RuntimeException("Equipe desconhecida");
                }
	}

	public void setTotalCP(int totalCP, int team) {
		if (team == 0) {
			this.redTotalCP = totalCP;
             } else if (team == 1) {
			this.blueTotalCP = totalCP;
             }
	}	
	
	public int getCP(int team) {
		if (team == 0) {
			return redCP;
                } else if (team == 1) {
			return blueCP;
                } else {
			throw new RuntimeException("Equipe desconhecida");
              }
	}

	public void setCP(int CP, int team) {
		if (team == 0)
			this.redCP = CP;
		else if (team == 1)
			this.blueCP = CP;
	}		
}
